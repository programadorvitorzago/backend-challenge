import json
import os
import uuid
from datetime import datetime as DateTime, timedelta as TimeDelta
import localUtil
import AWSMock

snsStore = [];

class TopicMock:
    def __init__(self, name, local_path):
        self.topic_name = name
        self.localPath = local_path
        self.creationTime = DateTime.utcnow().isoformat() + "Z"

def createTopic(name, localPath):
    if not name or not localPath:
        raise Exception("Topic name and local path are required")
    new_topic = TopicMock(name, localPath)
    snsStore.append(new_topic)
    print(f"Topic created: {name} at {localPath}")
    return new_topic

def createTopicMessage(topic, messageBody, originIdentify, dateTimeProducer):
    return {
        "Topic-name": topic.topic_name,
        "Creator-origin": originIdentify,
        "producer-time": dateTimeProducer.strftime('%Y-%m-%dT%H:%M:%S.%f'),
        "body": messageBody,
        "Deliveries": None,
        "MessageId": str(uuid.uuid4()),
    }

# def createMessageHandler(messageId, handlerId):
#     return {
#         "handlerId": handlerId,
#         "requestTimeStamp": DateTime.now()
#     }

def getTopic(queueName):
    for topic in snsStore:
        if topic.topic_name == queueName:
            return topic
    raise Exception(f"Topic not found '{queueName}'")

def publish_message_response(topicName, messageBody, originIdentify, response):
    topic = getTopic(topicName)

    dateTimeProducer = DateTime.now()
    publishDict = createTopicMessage(topic, messageBody, originIdentify, dateTimeProducer)
    messageFilePath = os.path.join(topic.localPath, f"{dateTimeProducer.strftime('P%Y-%m-%dT%H-%M-%S-%f')}.json")
    
    with open(messageFilePath, 'x') as file:
        file.write(json.dumps(publishDict, indent=4))
    
    AWSMock.preencher_base_response_sns(response)
    
    response_body_dict = {
        "PublishResult": {
            "MessageId": publishDict["MessageId"]
        },
        "ResponseMetadata": {
            "RequestId": response.headers.get("X-amz-request-id")
        }
    }

    AWSMock.insert_response_body(response,
            localUtil.create_response_xml_body("PublishResponse", response_body_dict).encode('utf-8'))
    return response

# def nextMessage(queue):
#     for root, _, files in os.walk(queue.localPath):
#         for file in files:
#             if file.endswith(".json"):
#                 messageFilePath = os.path.join(queue.localPath, file)
#                 with open(messageFilePath, 'r') as file:
#                     queueMessage = json.load(file)
                
#                 if queueMessage["messageId"] in queue.requestControl:
#                     if (queue.requestControl[queueMessage["messageId"]]["requestTimeStamp"] +  
#                             TimeDelta(seconds=queue.visibilityTimeout)) > DateTime.now():
#                         continue
                
#                 return queueMessage
#         break # Only check the top directory
#     return None

# def receive_message_response(queueName, response):
#     queue = getQueue(queueName)
    
#     queueMessage = nextMessage(queue)

#     if queueMessage:
        
#         messageId = queueMessage["messageId"]
#         requestInf = createMessageHandler(messageId, messageId)
#         queue.requestControl[messageId] = requestInf

#         AWSMock.preencher_base_response_json(response)
#         response.headers["Connection"] = "close"
        
#         response_body_dict = {
#             "MessageId": messageId,
#             "MD5OfMessageBody": queueMessage["MD5OfMessageBody"],
#             "Body": queueMessage["body"],
#             "ReceiptHandle": messageId,
#         }
        
#         response.body = json.dumps({"Messages": [response_body_dict]}).encode('utf-8')
        
#         return response
#     else:
#         AWSMock.preencher_base_response_json(response)
#         response.headers["Connection"] = "close"
#         response.body = json.dumps({}).encode('utf-8')
#         return response
    
# def delete_message_response(queueName, receiptHandle, response):
#     queue = getQueue(queueName)
    
#     encontradoMensagemPorReceiptHandle = False
#     for messageId in queue.requestControl:
#         if queue.requestControl[messageId]["handlerId"] == receiptHandle:
#             messageFilePath = os.path.join(queue.localPath, f"{messageId}.json")
#             if os.path.exists(messageFilePath):
#                 os.remove(messageFilePath)
#             encontradoMensagemPorReceiptHandle = True
    
#     if encontradoMensagemPorReceiptHandle:
#         del queue.requestControl[messageId]
#         AWSMock.preencher_base_response_json(response)
#         response.headers["Connection"] = "close"
#         response.body = json.dumps({}).encode('utf-8')
#         return response
    
#     else:
#         AWSMock.preencher_base_response_json(response, 400)
#         response.headers["Connection"] = "close"
#         response.headers["X-amzn-errortype"] = "ReceiptHandleIsInvalid"
#         response.body = json.dumps({}).encode('utf-8')

#         response_body_dict = {
#             "__type": "ReceiptHandleIsInvalid",
#             "message":f"The input receipt handle \"{receiptHandle}\" is not a valid receipt handle.",
#         }
#         response.body = json.dumps(response_body_dict).encode('utf-8')
        
#         return response

# def purge_queue_response(queueName, response):
#     queue = getQueue(queueName)
    
#     for root, _, files in os.walk(queue.localPath):
#         for file in files:
#             if file.endswith(".json"):
#                 messageFilePath = os.path.join(queue.localPath, file)
#                 if os.path.exists(messageFilePath):
#                     os.remove(messageFilePath)
#         break 
    
#     queue.requestControl.clear()
    
#     AWSMock.preencher_base_response_json(response)
#     response.headers["Connection"] = "close"
#     response.body = json.dumps({}).encode('utf-8')
#     return response

    