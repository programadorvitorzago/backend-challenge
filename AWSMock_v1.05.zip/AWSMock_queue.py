import json
import os
import uuid
from datetime import datetime as DateTime, timedelta as TimeDelta
import localUtil
import AWSMock

sqsStore = [];

class QueueMock:
    def __init__(self, queue_name, local_path):
        self.queue_name = queue_name
        self.localPath = local_path
        self.creationTime = DateTime.utcnow().isoformat() + "Z"
        self.requestControl = {}
        self.visibilityTimeout = 30

def createQueue(queueName, localPath):
    if not queueName or not localPath:
        raise Exception("Queue name and local path are required")
    new_queue = QueueMock(queueName, localPath)
    sqsStore.append(new_queue)
    print(f"Queue created: {queueName} at {localPath}")
    return new_queue

def createQueueMessage(messageId, messageBody):
    return {
        "messageId": messageId,
        "body": messageBody,
        "MD5OfMessageBody": localUtil.md5_hash(messageBody),
        "criationTime": DateTime.utcnow().isoformat() + "Z"
    }

def createMessageHandler(messageId, handlerId):
    return {
        "handlerId": handlerId,
        "requestTimeStamp": DateTime.now()
    }

def getQueue(queueName):
    for queue in sqsStore:
        if queue.queue_name == queueName:
            return queue
    raise Exception("Queue not found")

def send_message_response(queueName, messageBody, response):
    queue = getQueue(queueName)
    
    queueMessage = createQueueMessage(str(uuid.uuid4()), messageBody)
    messageFilePath = os.path.join(queue.localPath, f"{queueMessage['messageId']}.json")
    
    with open(messageFilePath, 'x') as file:
        file.write(json.dumps(queueMessage))
    
    AWSMock.preencher_base_response_json(response)
    response.headers["Connection"] = "close"
    
    response_body_dict = {
        "MessageId": queueMessage["messageId"],
        "MD5OfMessageBody": queueMessage["MD5OfMessageBody"]
    }
    
    response.body = json.dumps(response_body_dict).encode('utf-8')
    
    return response

def nextMessage(queue):
    for root, _, files in os.walk(queue.localPath):
        for file in files:
            if file.endswith(".json"):
                messageFilePath = os.path.join(queue.localPath, file)
                with open(messageFilePath, 'r') as file:
                    queueMessage = json.load(file)
                
                if queueMessage["messageId"] in queue.requestControl:
                    if (queue.requestControl[queueMessage["messageId"]]["requestTimeStamp"] +  
                            TimeDelta(seconds=queue.visibilityTimeout)) > DateTime.now():
                        continue
                
                return queueMessage
        break # Only check the top directory
    return None

def receive_message_response(queueName, response):
    queue = getQueue(queueName)
    
    queueMessage = nextMessage(queue)

    if queueMessage:
        
        messageId = queueMessage["messageId"]
        requestInf = createMessageHandler(messageId, messageId)
        queue.requestControl[messageId] = requestInf

        AWSMock.preencher_base_response_json(response)
        response.headers["Connection"] = "close"
        
        response_body_dict = {
            "MessageId": messageId,
            "MD5OfMessageBody": queueMessage["MD5OfMessageBody"],
            "Body": queueMessage["body"],
            "ReceiptHandle": messageId,
        }
        
        response.body = json.dumps({"Messages": [response_body_dict]}).encode('utf-8')
        
        return response
    else:
        AWSMock.preencher_base_response_json(response)
        response.headers["Connection"] = "close"
        response.body = json.dumps({}).encode('utf-8')
        return response
    
def delete_message_response(queueName, receiptHandle, response):
    queue = getQueue(queueName)
    
    encontradoMensagemPorReceiptHandle = False
    for messageId in queue.requestControl:
        if queue.requestControl[messageId]["handlerId"] == receiptHandle:
            messageFilePath = os.path.join(queue.localPath, f"{messageId}.json")
            if os.path.exists(messageFilePath):
                os.remove(messageFilePath)
            encontradoMensagemPorReceiptHandle = True
    
    if encontradoMensagemPorReceiptHandle:
        del queue.requestControl[messageId]
        AWSMock.preencher_base_response_json(response)
        response.headers["Connection"] = "close"
        response.body = json.dumps({}).encode('utf-8')
        return response
    
    else:
        AWSMock.preencher_base_response_json(response, 400)
        response.headers["Connection"] = "close"
        response.headers["X-amzn-errortype"] = "ReceiptHandleIsInvalid"
        response.body = json.dumps({}).encode('utf-8')

        response_body_dict = {
            "__type": "ReceiptHandleIsInvalid",
            "message":f"The input receipt handle \"{receiptHandle}\" is not a valid receipt handle.",
        }
        response.body = json.dumps(response_body_dict).encode('utf-8')
        
        return response

def purge_queue_response(queueName, response):
    queue = getQueue(queueName)
    
    for root, _, files in os.walk(queue.localPath):
        for file in files:
            if file.endswith(".json"):
                messageFilePath = os.path.join(queue.localPath, file)
                if os.path.exists(messageFilePath):
                    os.remove(messageFilePath)
        break 
    
    queue.requestControl.clear()
    
    AWSMock.preencher_base_response_json(response)
    response.headers["Connection"] = "close"
    response.body = json.dumps({}).encode('utf-8')
    return response

    