
import uuid
from datetime import datetime as DateTime
import localUtil
import json

def preencher_base_response(response, status_code = 200):
    response.status_code = status_code
    response.headers["X-amz-id-2"] = "s9lzHYrFp76ZVxRcpX9+5cjAnEH2ROuNkd2BHfIa6UkFVdtjf5mKR3/eTPFvsiP/XV/VLi31234="
    response.headers["X-amz-request-id"] = str(uuid.uuid4())
    response.headers["X-awsmock"] = "true"
    return response

def preencher_base_response_json(response, status_code = 200):
    preencher_base_response(response, status_code)
    response.headers["Content-Type"] = "application/x-amz-json-1.0"
    return response

def preencher_base_response_sns(response, status_code = 200):
    preencher_base_response(response, status_code)
    response.headers["Content-Type"] = "text/xml"
    response.headers["Connection"] = "close"
    return response

def insert_response_body(response, bodyValue):
    if isinstance(bodyValue, str):
        response.body = bodyValue.encode('utf-8')
    elif isinstance(bodyValue, bytes):
        response.body = bodyValue
    else:
        response.body = json.dumps(bodyValue).encode('utf-8')
    response.headers["Content-Length"] = str(len(response.body))
    return response

def convert_body_form_urlencoded_to_dict(bodyBytes):
    """ 
        Converte o body de x-www-form-urlencoded para um dicionário 
    """
    formBody = bodyBytes.decode('utf-8')
    formBodyParts = formBody.split("&")
    formBodyDict = {}
    for part in formBodyParts:
        keyValue = part.split("=")
        if len(keyValue) == 2:
            formBodyDict[keyValue[0]] = localUtil.urlDecode(keyValue[1])
    return formBodyDict

def get_authorization_identify(authorizationHeader):
    parts = authorizationHeader.split(" ")
    if len(parts) > 1:
        return parts[1]
    elif len(parts) == 1:
        return parts[0]
    return "unknown"
    
def get_amz_date():
    return DateTime.utcnow().strftime('%Y%m%dT%H%M%SZ')

