
import os
import uuid
from datetime import datetime as DateTime
import localUtil
import json5
import json

AWSMOCK_VERSION = "1.086"
ITEM_DEFAULT_EXTENSION = "ami"
SERVER_PORT:int = 9958 # Valor Padrão
CREATE_DIR:bool = False # Criar diretórios locais para rescursos se não forem caminhos absolutos
RECURSO_LIST:list = []
ESTILIZAR_ICONES_BETA:bool = False

def load_config_file(configFile):
    if os.path.exists(configFile):
        try:
            config = json5.loads(open(configFile, "r").read())
            global SERVER_PORT
            SERVER_PORT = config.get("port", 9958)

            global CREATE_DIR
            CREATE_DIR = config.get("createRelativeDirectory", False)

            global ESTILIZAR_ICONES_BETA
            ESTILIZAR_ICONES_BETA = config.get("styleIconsBeta", False)

            global RECURSO_LIST
            RECURSO_LIST = config.get("resourceList", [])
            
        except Exception as e:
            print(f"Erro ao carregar aquivo de configuração '{configFile}': {e}")
            exit(1)
    else:
        print(f"AVISO: Arquivo de configuração '{configFile}' não encontrado. Iniciando sem recursos.")

def preencher_base_response(response, status_code = 200):
    response.status_code = status_code
    response.headers["X-amz-id-2"] = "s9lzHYrFp76ZVxRcpX9+5cjAnEH2ROuNkd2BHfIa6UkFVdtjf5mKR3/eTPFvsiP/XV/VLi31234="
    response.headers["X-amz-request-id"] = str(uuid.uuid4())
    response.headers["X-awsmock"] = "true"
    return response

def preencher_base_response_bucket(response, status_code = 200):
    response.status_code = status_code
    response.headers["Content-Type"] = "application/xml"
    response.headers["Connection"] = "close"
    response.headers["X-amz-id-2"] = "s9lzHYrFp76ZVxRcpX9+5cjAnEH2ROuNkd2BHfIa6UkFVdtjf5mKR3/eTPFvsiP/XV/VLi31234="
    response.headers["X-amz-request-id"] = str(uuid.uuid4())
    response.headers["X-awsmock"] = "true"
    return response

def preencher_base_response_json(response, status_code = 200, *, response_body = None):
    preencher_base_response(response, status_code)
    response.headers["Content-Type"] = "application/x-amz-json-1.0"
    
    if response_body:
        set_response_body_from_dict(response, response_body)
    
    return response

def preencher_base_response_sns(response, status_code = 200):
    preencher_base_response(response, status_code)
    response.headers["Content-Type"] = "text/xml"
    response.headers["Connection"] = "close"
    return response

def set_response_body_from_dict(response, bodyValue:dict):
    response.body = json.dumps(bodyValue).encode('utf-8')
    response.headers["Content-Length"] = str(len(response.body))
    return response

def insert_response_body(response, bodyValue):
    if isinstance(bodyValue, str):
        response.body = bodyValue.encode('utf-8')
    elif isinstance(bodyValue, bytes):
        response.body = bodyValue
    else:
        response.body = json.dumps(bodyValue).encode('utf-8')
    response.headers["Content-Length"] = str(len(response.body))
    return response

def convert_body_form_urlencoded_to_dict(bodyBytes):
    """ 
        Converte o body de x-www-form-urlencoded para um dicionário 
    """
    formBody = bodyBytes.decode('utf-8')
    formBodyParts = formBody.split("&")
    formBodyDict = {}
    for part in formBodyParts:
        keyValue = part.split("=")
        if len(keyValue) == 2:
            formBodyDict[keyValue[0]] = localUtil.urlDecode(keyValue[1])
    return formBodyDict

def get_authorization_identify(authorizationHeader):
    parts = authorizationHeader.split(" ")
    if len(parts) > 1:
        return parts[1]
    elif len(parts) == 1:
        return parts[0]
    return "unknown"
    
def get_amz_date():
    return DateTime.utcnow().strftime('%Y%m%dT%H%M%SZ')

def print_for_internal_controler(msg):
    print(f"[AWSMock_Internal] Exception: {msg}")

class ElementNotFoundError(Exception):
    
    def __init__(self, elementType, elementName):
        super().__init__(f"{elementType} '{elementName}' not found")
        self.resourceType = elementType
        self.resourceName = elementName