from datetime import datetime as DateTime, timedelta as TimeDelta
import json
import os
from AWSMock import AWSMock_queue
import AWSMock.AWSMock_Global as AWSMock_Global
import localUtil

apiListenerStore = [];

class ApiListenerMock:
    def __init__(self, apiName, local_path, **propDict):
        self.api_name = apiName
        self.localPath = local_path
        self.creationTime = DateTime.now()
        
        self.tryPretty = bool(propDict.get("tryPretty", False))
        self.rootPath = propDict.get("rootPath", "/awsmock")

def createApiListener(apiName, localPath, propDict):
    if not apiName or not localPath:
        raise Exception("ApiName and local path are required")
    
    if not localUtil.verifyIfResourcePathExistOrCresteIt(localPath, 'apiListener'):
        print(f"AVISO: Rescurso 'apiListener' ignorado: Caminho do recurso deve existir: {localPath}")
        return None
    
    new_apiListener = ApiListenerMock(apiName, localPath, **propDict)
    
    apiListenerStore.append(new_apiListener)
    print(f"ApiListener created: {apiName} at {localPath}")
    return new_apiListener

def getApiListener(apiName):
    for item in apiListenerStore:
        if item.api_name == apiName:
            return item
    raise Exception(f"ApiListener not found: {apiName}")

def write_file_item(apiListener:ApiListenerMock, messageFilePath, logDict, apiRequest, apiResponse):
    with open(messageFilePath, 'x', encoding="utf-8") as file:
        file.write("[API_LISTENER_RECEIVED_REQUEST]\n")
        for mProperty in logDict:
            propValue = logDict.get(mProperty, "")
            if propValue:
                file.write(f"{mProperty}={logDict[mProperty]}\n")
        file.write("\n")

        shieldComplement = ""
        if(apiListener.tryPretty): 
            (bodyContent, typeMatched) = localUtil.tryPrettyOrDefault(apiRequest)
            if  typeMatched:
                shieldComplement = f"**{typeMatched} Formated**"
        else:
            bodyContent = apiRequest

        file.write(f"[REQUEST_BODY] {shieldComplement}\n")
        file.write(bodyContent)
        file.write("\n\n")
        
        file.write("[RESPONSE]\n")
        file.write(apiResponse)

def getApiByRequestPath(requestPath):
    for api in apiListenerStore:
        if requestPath.startswith(api.rootPath):
            return api
    return None

def log_and_get_default_response(apiObj, request, response, bodyContent: bytes):
    dateTimeReceived = DateTime.now()
    
    logDict = {}
    logDict["API_NAME"] = apiObj.api_name
    logDict["REQUEST_TIME"] = dateTimeReceived.strftime("%Y-%m-%d %H:%M:%S")
    logDict["REQUEST_PATH"] = request.url.path
    logDict["REQUEST_METHOD"] = request.method
    logDict["REQUEST_PARAMS"] = json.dumps(dict(request.query_params))
    logDict["REQUEST_HEADERS"] = json.dumps(dict(request.headers))
    
    try:
        requestData = bodyContent.decode("utf-8")
    except Exception as e:
        logDict["REQUEST_DATA_ERROR"] = str(e)
        requestData = ""
       
    default_response = json.dumps({
        "statusCode": 200,
        "headers": {
            "Content-Type": "application/json"
        },
        "body": json.dumps({"message": "Default response"}),
        "isBase64Encoded": False
    })
    
    messageFilePath = os.path.join(apiObj.localPath, f"API_{dateTimeReceived.strftime('%Y-%m-%dT%H''h''%M''m''%S.%f''s''')}.{AWSMock_Global.ITEM_DEFAULT_EXTENSION}")
    write_file_item(apiObj, messageFilePath, logDict, requestData, default_response)

    AWSMock_Global.preencher_base_response_json(response)
    response.headers["Connection"] = "close"
    
    bodyBytes = json.dumps({"message": "defaultResponse"}).encode("utf-8")
    response.headers["Content-length"] = str(len(bodyBytes))
    response.body = bodyBytes

    return response
    
