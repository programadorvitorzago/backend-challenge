
# Espeficiação de arquivo de texto posicional

## {{ARQUIVO_TEXTO_POSICIONAL_SPECIFICATION}}
```[jsonc]
{
    // Lista de TIPOS de ARQUIVOS de texto posicional
    "tipoArquivoTextoPosicionalList": [
        TIPO_ARQUIVO_TEXTO_POSICIONAL, ... 
    ],
}
```

## {{TIPO_ARQUIVO_TEXTO_POSICIONAL}}
```[jsonc]
{
    "id": "CNAB240",
    "nome": "Extrao 240",
    "descricao": "",
    "mathExtensao": [""],

    "linhaTipoList": [
        {   
            "id": "CAB_EXEMPLO",
            "nome": "Cabeçalho de Arquivo",
            "tamanho": 240,
            "identificacao": [
                {
                    "ini": 8,
                    "fim": 8,
                    "valor": "0"
                }
            ],
            "campoList": [
                { "id": 1, "nome": "CÓDIGO DO BANCO", "descricao": "", "descricaoDetalhada": "", "posicional": { "ini": 1, "fim": 3 }, "classe": "campo02", "destaque": { "color": "#EAFDF0", "border": "" } }
            ],
            "destaque": {
                "border": "0px 0px 4px 0px solid black"
            }
        }
    ],

    "blocoTipoList": [
        {   "id": "BLOCO_LOTE",
            "nome": "Bloco de Conta Corrente",
            "idLinhaIni": "CAB_LOTE",
            "idLinhaFim": "ROD_LOTE",
            "destaque": {
                "border": "2px solid blue"
            }
        }
    ]
}
```