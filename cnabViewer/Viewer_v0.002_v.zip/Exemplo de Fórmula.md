# Use essa fórmula desde QUE:
## Coluna A = Posição Numérica do Campo (conforme Book)
## Coluna B = Nome MNEMONICO
## Coluna C = Descrição do campo
## Coluna E = Posição numérica coluna inicial do campo
## Coluna F = Posição numérica coluna Final do Campo
## Coluna H = Cor HTML
Ex:
#EAFDF0
#FFF0C9
#E7FDFF
#E6F6FF
#E6FFF2

=",{ id: " & A3 & ", nome: '" & B3 & "', descricao: '" &  C3 & "', descricaoDetalhada: '', posicional: { ini: " & E3 & ", fim: " & F3 & ", }, classe: 'campo02', destaque: { color: '" & H3 & "', border: ''} }"