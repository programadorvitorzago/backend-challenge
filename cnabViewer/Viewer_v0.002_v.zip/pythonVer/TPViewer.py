from datetime import datetime
import os
import sys
import subprocess
import platform
import json
from string import Template
import tempfile
import datetime

def open_file_with_default_program(filename):
    """Opens a file using its default system program."""
    if platform.system() == "Windows":
        os.startfile(filename)
    elif platform.system() == "Darwin": # macOS
        subprocess.Popen(["open", filename])
    else: # Linux/Unix
        try:
            subprocess.Popen(["xdg-open", filename])
        except OSError:
            print(f"Cannot open {filename} on this platform without xdg-utils.")

def get_valor_campo(linha, identificacao):
    # identificacao: dict com chaves 'ini' e 'fim' (1-based, inclusive)
    ini = identificacao["ini"]
    fim = identificacao["fim"]
    return linha[ini - 1:fim]

def get_dica_campo(campo):
    identificacao = campo["posicional"]
    ini = identificacao["ini"]
    fim = identificacao["fim"]

    # if "descricaoDetalhada" in campo and campo["descricaoDetalhada"]:
    #     return campo["descricaoDetalhada"]
    # if "descricao" in campo and campo["descricao"]:
    #     return campo["descricao"]
    # return campo.get("nome", "")
    return f"{campo.get('nome', '')} (pos {ini}-{fim})"

def get_string_destaque(destaque):
    if not destaque:
        return ""
    parts = []

    # Legado: 'color' vira background-color
    if "color" in destaque:
        parts.append(f"background-color: {destaque['color']};")

    for chave, valor in destaque.items():
        if chave == "color":
            continue
        css_prop = chave.replace("_", "-")
        parts.append(f"{css_prop}: {valor};")

    return "".join(parts)

def get_linha_tipo(linha, cnab_spec, bloco_spec):
    for linha_tipo in cnab_spec["linhaTipoList"]:
        match = True

        for criterio in linha_tipo["identificacao"]:
            if "ini" in criterio:
                valor_campo_criterio = get_valor_campo(linha, criterio)
                result = (valor_campo_criterio == criterio["valor"])
                match = match and result
            elif "bloco" in criterio and bloco_spec is not None:
                result = (criterio["bloco"] == bloco_spec["id"])
                match = match and result
            else:
                match = False

        if match:
            return linha_tipo

    return None

def montagem(texto_cnab, cnab_spec):
    """
    Retorna uma string HTML equivalente à montagem feita no JS.
    """
    lines = texto_cnab.split('\n')

    bloco_spec = None
    bloco_init = False

    html_parts = []
    tam_linha_default = 240

    for raw_line in lines:
        line = raw_line.replace('\r', '')  # remove carriage return

        div_classes = ["cnabLine"]
        div_style = ""
        inner_spans = []

        linha_tipo = get_linha_tipo(line, cnab_spec, bloco_spec)
        tam_linha = tam_linha_default

        if linha_tipo is not None:
            tam_linha = linha_tipo["tamanho"]

            if len(line) < tam_linha:
                # completa com espaços à direita
                line = line.ljust(tam_linha, ' ')

            # classes e estilo do div da linha
            div_classes.append(linha_tipo["id"])
            div_style = get_string_destaque(linha_tipo.get("destaque"))

            # iterar campos
            index_fim = 0
            for campo in linha_tipo["campoList"]:
                posicional = campo["posicional"]
                valor_campo = get_valor_campo(line, posicional)

                span_class = campo.get("classe", "")
                span_style = get_string_destaque(campo.get("destaque"))
                span_title = get_dica_campo(campo)

                span_html = (
                    f'<span class="{span_class}" '
                    f'style="{span_style}" '
                    f'title="{span_title}">'
                    f'{valor_campo}</span>'
                )
                inner_spans.append(span_html)
                index_fim = posicional["fim"]

            # restante da linha
            if index_fim < tam_linha:
                restante = line[index_fim:tam_linha]
                span_html = (
                    f'<span class="restante">{restante}</span>'
                )
                inner_spans.append(span_html)
        else:
            # Tipo de linha não identificado
            span_html = (
                f'<span class="semIdentificacao">{line}</span>'
            )
            inner_spans.append(span_html)

        div_html = (
            f'<div class="{" ".join(div_classes)}" '
            f'style="{div_style}">'
            f'{"".join(inner_spans)}'
            f'</div>'
        )

        # Controle de blocos (equivalente ao blocoInit / blocoSpec)
        closing_block_now = False

        if bloco_init:
            # verificar se tem que fechar
            if linha_tipo and bloco_spec and bloco_spec["idLinhaFim"] == linha_tipo["id"]:
                closing_block_now = True
            # enquanto o bloco estiver aberto, as linhas vão dentro do bloco
            html_parts.append(div_html)
        else:
            # Encontrar especificação de bloco baseado na linha atual
            for bloco_to_test in cnab_spec["blocoTipoList"]:
                if linha_tipo and bloco_to_test["idLinhaIni"] == linha_tipo["id"]:
                    bloco_spec = bloco_to_test
                    break
            else:
                bloco_spec = None

            # verificar se tem que abrir bloco
            if bloco_spec and linha_tipo and bloco_spec["idLinhaIni"] == linha_tipo["id"]:
                bloco_init = True
                bloco_style = get_string_destaque(bloco_spec.get("destaque"))
                html_parts.append(
                    f'<div class="cnabBloco" style="{bloco_style}">'
                )
                html_parts.append(div_html)
            else:
                # linha fora de bloco
                html_parts.append(div_html)

        # se o bloco finalizou nesta linha, fecha a div do bloco
        if closing_block_now:
            bloco_init = False
            bloco_spec = None
            html_parts.append('</div>')  # fecha cnabBloco

    return "".join(html_parts)

if __name__ == "__main__":

    globalParam = {
        "cnabSpecPath": os.path.join(os.path.dirname(__file__), "tpViewerSpec.json"),
        "templatePath": os.path.join(os.path.dirname(__file__), "html.template")
    }

    if len(sys.argv) < 2:
        print("Uso: python TPViewer.py <caminho_arquivo_cnab>")
        sys.exit(1)

    caminho_arquivo_cnab = sys.argv[1]
    caminho_arquivo_spec = globalParam["cnabSpecPath"]
    template_path = globalParam["templatePath"]
    with open(template_path, 'r', encoding='utf-8') as f:
        template_html_text = f.read()

    template_base = Template(template_html_text)

    with open(caminho_arquivo_spec, 'r', encoding='utf-8') as f:
        cnab_spec = json.load(f)

    with open(caminho_arquivo_cnab, 'r', encoding='utf-8') as f:
        texto_cnab = f.read()

    tipo_identificado =  cnab_spec.get("tipoArquivoTextoPosicionalList", [])[0]
    dict_template = {
        "fileName": os.path.basename(caminho_arquivo_cnab),
        "templateType": tipo_identificado.get("nome", ""),
        "templateResult": montagem(texto_cnab, tipo_identificado)
    }
     
    html_resultante = template_base.substitute(dict_template)

    output_html_path = os.path.join(tempfile.gettempdir(), f"tpViewerOutput_{datetime.datetime.now().strftime('%f')}.html")
    with open(output_html_path, 'w', encoding='utf-8') as f:
        f.write(html_resultante)
    
    print(f"Abrindo o HTML em: {output_html_path}")
    open_file_with_default_program(output_html_path)