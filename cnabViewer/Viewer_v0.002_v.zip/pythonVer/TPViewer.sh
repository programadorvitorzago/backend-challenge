#!/bin/bash
python /home/zagovit/workspace/ClientePirelli/testeViewer/TPViewer.py "$@"