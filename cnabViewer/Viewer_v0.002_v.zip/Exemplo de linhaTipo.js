{   id: "CAB_ARQ",
                        nome: 'Cabeçalho de Arquivo',
                        tamanho: 240,
                        identificacao: [
                            {
                                ini: 8,
                                fim: 8,
                                valor: '0'
                            }
                        ],
                        campoList: [
 { id: 1, nome: 'CÓDIGO DO BANCO', descricao: '', descricaoDetalhada: '', posicional: { ini: 1, fim: 3, }, classe: 'campo02', destaque: { color: '#EAFDF0', border: ''} }
,{ id: 2, nome: 'CÓDIGO DO LOTE', descricao: '', descricaoDetalhada: '', posicional: { ini: 4, fim: 7, }, classe: 'campo03', destaque: { color: '#FFF0C9', border: ''} }
,{ id: 3, nome: 'TIPO DE REGISTRO', descricao: '', descricaoDetalhada: '', posicional: { ini: 8, fim: 8, }, classe: 'campo04', destaque: { color: '#E7FDFF', border: ''} }
,{ id: 4, nome: 'BRANCOS', descricao: '', descricaoDetalhada: '', posicional: { ini: 9, fim: 17, }, classe: 'campo05', destaque: { color: '', border: ''} }
,{ id: 5, nome: 'TIPO DE INSCRIÇÃO', descricao: 'TIPO DE INSCRIÇÃO  1=CPF e 2=CNPJ', descricaoDetalhada: '', posicional: { ini: 18, fim: 18, }, classe: 'campo06', destaque: { color: '#FFF5E8', border: ''} }
,{ id: 6, nome: 'NÚMERO DE INSCRIÇÃO', descricao: '', descricaoDetalhada: '', posicional: { ini: 19, fim: 32, }, classe: 'campo07', destaque: { color: '#F8DCE6', border: ''} }
,{ id: 7, nome: 'BRANCOS', descricao: '', descricaoDetalhada: '', posicional: { ini: 33, fim: 47, }, classe: 'campo08', destaque: { color: '', border: ''} }
,{ id: 8, nome: 'CONVÊNIO', descricao: '', descricaoDetalhada: '', posicional: { ini: 48, fim: 52, }, classe: 'campo09', destaque: { color: '#E6F6FF', border: ''} }
,{ id: 9, nome: 'ZEROS', descricao: '', descricaoDetalhada: '', posicional: { ini: 53, fim: 53, }, classe: 'campo10', destaque: { color: '#FFEFF7', border: ''} }
,{ id: 10, nome: 'AGENCIA', descricao: '', descricaoDetalhada: '', posicional: { ini: 54, fim: 57, }, classe: 'campo11', destaque: { color: '#E9FFEA', border: ''} }
,{ id: 11, nome: 'DAC DA AGÊNCIA', descricao: '', descricaoDetalhada: '', posicional: { ini: 58, fim: 58, }, classe: 'campo12', destaque: { color: '#F7E7F9', border: ''} }
,{ id: 12, nome: 'ZEROS', descricao: '', descricaoDetalhada: '', posicional: { ini: 59, fim: 65, }, classe: 'campo13', destaque: { color: '#FAD6E8', border: ''} }
,{ id: 13, nome: 'CONTA', descricao: '', descricaoDetalhada: '', posicional: { ini: 66, fim: 70, }, classe: 'campo14', destaque: { color: '#E6FFF7', border: ''} }
,{ id: 14, nome: 'BRANCOS', descricao: '', descricaoDetalhada: '', posicional: { ini: 71, fim: 71, }, classe: 'campo15', destaque: { color: '#FFF4D9', border: ''} }
,{ id: 15, nome: 'DAC AG / CTA', descricao: '', descricaoDetalhada: '', posicional: { ini: 72, fim: 72, }, classe: 'campo16', destaque: { color: '#F2FFF3', border: ''} }
,{ id: 16, nome: 'NOME CLIENTE', descricao: '', descricaoDetalhada: '', posicional: { ini: 73, fim: 102, }, classe: 'campo17', destaque: { color: '#E6FFF2', border: ''} }
,{ id: 17, nome: 'NOME BANCO', descricao: '', descricaoDetalhada: '', posicional: { ini: 103, fim: 132, }, classe: 'campo18', destaque: { color: '#FFF0C9', border: ''} }
,{ id: 18, nome: 'BRANCOS', descricao: '', descricaoDetalhada: '', posicional: { ini: 133, fim: 142, }, classe: 'campo19', destaque: { color: '', border: ''} }
,{ id: 19, nome: 'CÓDIGO RETORNO', descricao: '', descricaoDetalhada: '', posicional: { ini: 143, fim: 143, }, classe: 'campo20', destaque: { color: '#FFF2EA', border: ''} }
,{ id: 20, nome: 'DATA DA GERAÇÃO', descricao: '', descricaoDetalhada: '', posicional: { ini: 144, fim: 151, }, classe: 'campo21', destaque: { color: '#FDEEE0', border: ''} }
,{ id: 21, nome: 'HORA DA GERAÇÃO', descricao: '', descricaoDetalhada: '', posicional: { ini: 152, fim: 157, }, classe: 'campo22', destaque: { color: '#F8F0FF', border: ''} }
,{ id: 22, nome: 'SEQUÊNCIA ARQUIVO', descricao: '', descricaoDetalhada: '', posicional: { ini: 158, fim: 163, }, classe: 'campo23', destaque: { color: '#F0FFF6', border: ''} }
,{ id: 23, nome: 'LAYOUT', descricao: '', descricaoDetalhada: '', posicional: { ini: 164, fim: 166, }, classe: 'campo24', destaque: { color: '#F6F7D8', border: ''} }
,{ id: 24, nome: 'ZEROS', descricao: '', descricaoDetalhada: '', posicional: { ini: 167, fim: 171, }, classe: 'campo25', destaque: { color: '', border: ''} }
,{ id: 25, nome: 'RESERVADO DO BANCO', descricao: '', descricaoDetalhada: '', posicional: { ini: 172, fim: 191, }, classe: 'campo26', destaque: { color: '#E6F6FF', border: ''} }
,{ id: 26, nome: 'BRANCOS', descricao: '', descricaoDetalhada: '', posicional: { ini: 192, fim: 240, }, classe: 'campo27', destaque: { color: '', border: ''} }
                       ],
                        destaque: {
                            border: "0px 0px 4px 0px solid black"
                        }
                    }