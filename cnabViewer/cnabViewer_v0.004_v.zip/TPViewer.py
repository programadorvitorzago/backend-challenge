from datetime import datetime
import os
import sys
import subprocess
import platform
import json
from string import Template
import tempfile
import datetime

VERSAO_APLICATIVO = "1.05"

def open_file_with_default_program(filename):
    """Opens a file using its default system program."""
    if platform.system() == "Windows":
        if isinstance(filename, list):
            subprocess.Popen(filename)
        else:
            os.startfile(filename)
    elif platform.system() == "Darwin": # macOS
        subprocess.Popen(["open", filename])
    else: # Linux/Unix
        try:
            subprocess.Popen(["xdg-open", filename])
        except OSError:
            print(f"Cannot open {filename} on this platform without xdg-utils.")

def get_valor_campo(linha, posicional):
    # identificacao: dict com chaves 'ini' e 'fim' (1-based, inclusive)
    ini = posicional["ini"]
    fim = posicional["fim"]
    return linha[ini - 1:fim]

def get_dica_campo(campo, valor_campo = None):
    posicional = campo["posicional"]
    ini = posicional["ini"]
    fim = posicional["fim"]
    
    linhaDicaList = [f"{campo.get('nome', '')} (pos {ini}-{fim})"]

    formatacao = campo.get("formatacao")
    if formatacao and valor_campo:
        if formatacao.get("tipo") == "valorV2":
            try:
                parsedValue = int(valor_campo)
                valor_formatado = f"{parsedValue / 100:.2f}"
                linhaDicaList.append(f"Valor: {valor_formatado}")
            except ValueError as e:
                print(f"Error: {e}")
            
    return "\n".join(linhaDicaList)

def get_string_destaque(destaque):
    if not destaque:
        return ""
    parts = []

    # Legado: 'color' vira background-color
    if "color" in destaque:
        parts.append(f"background-color: {destaque['color']};")

    for chave, valor in destaque.items():
        if chave == "color":
            continue
        css_prop = chave.replace("_", "-")
        parts.append(f"{css_prop}: {valor};")

    return "".join(parts)

def get_linha_tipo(linha, cnab_spec, bloco_spec):
    for linha_tipo in cnab_spec["linhaTipoList"]:
        match = True

        for criterio in linha_tipo["identificacao"]:
            if "ini" in criterio:
                valor_campo_criterio = get_valor_campo(linha, criterio)
                result = (valor_campo_criterio == criterio["valor"])
                match = match and result
            elif "bloco" in criterio and bloco_spec is not None:
                result = (criterio["bloco"] == bloco_spec["id"])
                match = match and result
            else:
                match = False

        if match:
            return linha_tipo

    return None

def montagem(texto_cnab, cnab_spec):
    """
    Retorna uma string HTML equivalente à montagem feita no JS.
    """
    lineArray = texto_cnab.split('\n')

    bloco_spec = None
    bloco_init = False

    html_parts = []
    tam_linha_default = 240

    for raw_line in lineArray:
        line = raw_line.replace('\r', '')  # remove carriage return

        div_classes = ["cnabLine"]
        div_style = ""
        inner_spans = []

        linha_tipo = get_linha_tipo(line, cnab_spec, bloco_spec)
        tam_linha = tam_linha_default

        if linha_tipo is not None:
            tam_linha = linha_tipo["tamanho"]

            if len(line) < tam_linha:
                # completa com espaços à direita
                line = line.ljust(tam_linha, ' ')

            # classes e estilo do div da linha
            div_classes.append(linha_tipo["id"])
            div_style = get_string_destaque(linha_tipo.get("destaque"))

            # iterar campos
            index_fim = 0
            for campo in linha_tipo["campoList"]:
                posicional = campo["posicional"]
                valor_campo = get_valor_campo(line, posicional)

                span_class = campo.get("classe", "")
                span_style = get_string_destaque(campo.get("destaque"))
                span_title = get_dica_campo(campo, valor_campo)

                span_html = (
                    f'<span class="{span_class}" '
                    f'style="{span_style}" '
                    f'title="{span_title}">'
                    f'{valor_campo}</span>'
                )
                inner_spans.append(span_html)
                index_fim = posicional["fim"]

            # restante da linha
            if index_fim < tam_linha:
                restante = line[index_fim:tam_linha]
                span_html = (
                    f'<span class="restante">{restante}</span>'
                )
                inner_spans.append(span_html)
        else:
            # Tipo de linha não identificado
            span_html = (
                f'<span class="semIdentificacao">{line or " "}'
                '</span>'
            )
            inner_spans.append(span_html)

        div_html = (
            f'<div class="{" ".join(div_classes)}" '
            f'style="{div_style}">'
            f'{"".join(inner_spans)}'
            f'</div>'
        )

        # Controle de blocos (equivalente ao blocoInit / blocoSpec)
        closing_block_now = False

        if bloco_init:
            # verificar se tem que fechar
            if linha_tipo and bloco_spec and bloco_spec["idLinhaFim"] == linha_tipo["id"]:
                closing_block_now = True
            # enquanto o bloco estiver aberto, as linhas vão dentro do bloco
            html_parts.append(div_html)
        else:
            # Encontrar especificação de bloco baseado na linha atual
            for bloco_to_test in cnab_spec["blocoTipoList"]:
                if linha_tipo and bloco_to_test["idLinhaIni"] == linha_tipo["id"]:
                    bloco_spec = bloco_to_test
                    break
            else:
                bloco_spec = None

            # verificar se tem que abrir bloco
            if bloco_spec and linha_tipo and bloco_spec["idLinhaIni"] == linha_tipo["id"]:
                bloco_init = True
                bloco_style = get_string_destaque(bloco_spec.get("destaque"))
                html_parts.append(
                    f'<div class="cnabBloco" style="{bloco_style}">'
                )
                html_parts.append(div_html)
            else:
                # linha fora de bloco
                html_parts.append(div_html)

        # se o bloco finalizou nesta linha, fecha a div do bloco
        if closing_block_now:
            bloco_init = False
            bloco_spec = None
            html_parts.append('</div>')  # fecha cnabBloco

    return "".join(html_parts)

def getLinhaCabecalhoPosicional(cnab_tipo):
    tamanho = None
    for linha_tipo in cnab_tipo.get("linhaTipoList", []):
        tamanho = linha_tipo.get("tamanho", None)
        if tamanho is not None:
            break

    if tamanho is not None:
        cabecalho = ""
        for pos in range(1, tamanho + 1):
            if pos % 5 == 0:
                cabecalho += "+"
            else:
                cabecalho += "-"
        for pos in range(1, tamanho + 1):
            if pos % 10 == 0:
                strPos = f"{pos // 10}"
                cabecalho = cabecalho[:pos-len(strPos)] + strPos + cabecalho[pos:]

        return f"<div class='cnabLIne'>{cabecalho}</div>"
    return ""

def getIdentificadorTipoArquivoTextoPosicional(associacaoList, fullPath = "", fileName = ""):
    for associacao in associacaoList:
        tipo_id = associacao["tipoArquivoTextoPosicionalId"]
        criterioArray = associacao.get("criterio", None)
        # Legado
        if criterioArray is not None:
            if isinstance(criterioArray, str):
                criterioArray = [criterioArray]
            if isinstance(criterioArray, list) and all(isinstance(c, str) for c in criterioArray):
                criterioArray = {"tipo": "fileNameRegexAnyMatch", "valor": criterioArray}
            if isinstance(criterioArray, dict):
                criterioArray = [criterioArray]
        # Fim legado
            
            for criterio in criterioArray:
                criterio_tipo = criterio.get("tipo")
                if criterio_tipo == "fileNameRegexAnyMatch":
                    import re
                    for valorCriterio in criterio.get("valor", []):
                        pattern = valorCriterio
                        if re.search(pattern, fileName):
                            return tipo_id

if __name__ == "__main__":

    globalParam = {
        "cnabSpecPath": os.path.join(os.path.dirname(__file__), "tpViewerSpec.json"),
        "templatePath": os.path.join(os.path.dirname(__file__), "html.template")
    }

    if len(sys.argv) < 2:
        print("Uso: python TPViewer.py <caminho_arquivo_cnab>")
        sys.exit(1)

    caminho_arquivo_cnab = sys.argv[1]
    caminho_arquivo_spec = globalParam["cnabSpecPath"]
    template_path = globalParam["templatePath"]

    with open(template_path, 'r', encoding='utf-8') as f:
        template_html_text = f.read()
    template_base = Template(template_html_text)

    with open(caminho_arquivo_spec, 'r', encoding='utf-8') as f:
        tp_spec = json.load(f)

    with open(caminho_arquivo_cnab, 'r', encoding='utf-8') as f:
        texto_cnab = f.read()

    tipo_identificado = None
    fileName = os.path.basename(caminho_arquivo_cnab)
    id_tipo_identificado = getIdentificadorTipoArquivoTextoPosicional(tp_spec.get("associacaoTipoArquivoTextoPosicionalList", []), caminho_arquivo_cnab, fileName)
    if id_tipo_identificado:
        tipo_identificado = next(filter(lambda t : t["id"] == id_tipo_identificado
                                        , tp_spec.get("tipoArquivoTextoPosicionalList", [])), None)
                                                      
    if tipo_identificado:
        print(f"Identificado Layout: {tipo_identificado['nome']}")    

        dict_template = {
            "versao": VERSAO_APLICATIVO,
            "fileName": fileName,
            "templateType": tipo_identificado.get("nome", ""),
            "cabecalhoPosicionamento": getLinhaCabecalhoPosicional(tipo_identificado),
            "templateResult": montagem(texto_cnab, tipo_identificado)
        }
        
        html_resultante = template_base.substitute(dict_template)

        output_html_path = os.path.join(tempfile.gettempdir(), f"tpViewerOutput/{dict_template['fileName']}.html")
        os.makedirs(os.path.dirname(output_html_path), exist_ok=True)
        with open(output_html_path, 'w', encoding='utf-8') as f:
            f.write(html_resultante)
        
        print(f"Abrindo o HTML em: {output_html_path}")
        open_file_with_default_program(output_html_path)
    else:
        print(f"Não identificado Layout para Texto Posicional: {fileName}")
        open_file_with_default_program([tp_spec["aplicativoTextoPlanoPadrao"], caminho_arquivo_cnab])