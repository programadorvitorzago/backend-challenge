import os

class BucketMock:
    def __init__(self, bucket_name, local_path):
        self.bucket_name = bucket_name
        self.localPath = local_path

bucketStore = [];

def createBucket(bucketName, localPath):
    if not bucketName or not localPath:
        raise Exception("Bucket name and local path are required")
    new_bucket = BucketMock(bucketName, localPath)
    bucketStore.append(new_bucket)
    return new_bucket

def getBucket(bucketName):
    for bucket in bucketStore:
        if bucket.bucket_name == bucketName:
            return bucket
    raise Exception("Bucket not found")

def writeFile(localPath, objectKey, fileContent):
    fullPath = f"{localPath}/{objectKey}"
    with open(fullPath, 'x') as file:
        file.write(fileContent)

def downloadFile(bucketName, objectKey):
    bucket = getBucket(bucketName)
    fullPath = f"{bucket.localPath}/{objectKey}"
    with open(fullPath, 'r') as file:
        return file.read()

def uploadFile(bucketName, filePath, fileContent):
    bucket = getBucket(bucketName)
    writeFile(bucket.localPath, filePath, fileContent)

    