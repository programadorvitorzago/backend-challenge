from datetime import datetime as DateTime
from fastapi import FastAPI, Request, Response
import uvicorn
import AWSMock_bucket
import json

app = FastAPI()

@app.get("/{anyPath:path}")
async def read_get(request: Request, response: Response):
    urn = request.url.path
    print(f"Received request GET for: {urn}")
    urnPartList = urn.split("/")
    filteredUrlPartList = list(filter(lambda x: x > "", urnPartList))

    hederUserAgent = request.headers.get("User-Agent")
    print(f"User-Agent: {hederUserAgent}")

    bucketName = filteredUrlPartList[0]
    itemKey = "/".join(filteredUrlPartList[1:])
    
    print(f"DOWNLOAD")
    print(f"bucketName: {bucketName}")
    print(f"itemKey: {itemKey}")
    
    fileContent = AWSMock_bucket.downloadFile(bucketName, itemKey)
    
    response.status_code = 200
    response.body = fileContent.encode('utf-8') 
    response.headers["Accept-ranges"] = "bytes"
    response.headers["Connection"] = "close"
    response.headers["Content-Length"] = str(len(response.body))
    response.headers["Content-Type"] = "application/octet-stream"
    response.headers["Date"] = DateTime.utcnow().strftime("%a, %d %b %Y %H:%M:%S GMT")
    response.headers["Etag"] = "vitorZago" # "5eff03c49d5ff0e6775d201e4e833f72"
    response.headers["Last-modified"] = "Mon, 18 Aug 2025 01:59:14 GMT"
    response.headers["Server"] = "AwsMockServer/1.0"
    
    return response

@app.put("/{anyPath:path}")
async def read_put(request: Request, response: Response):
    urn = request.url.path
    print(f"Received request PUT for: {urn}")
    urnPartList = urn.split("/")
    filteredUrlPartList = list(filter(lambda x: x > "", urnPartList))

    hederUserAgent = request.headers.get("User-Agent")
    print(f"User-Agent: {hederUserAgent}")

    bucketName = filteredUrlPartList[0]
    itemKey = "/".join(filteredUrlPartList[1:])
    
    print(f"UPLOAD")
    print(f"bucketName: {bucketName}")
    print(f"itemKey: {itemKey}")
    
    AWSMock_bucket.uploadFile(bucketName, itemKey, str(await request.body(), encoding='utf-8'))
    
    response.status_code = 200
    response.headers["Connection"] = "close"
    response.headers["Date"] = DateTime.utcnow().strftime("%a, %d %b %Y %H:%M:%S GMT")
    response.headers["Etag"] = "vitorZago" # "5eff03c49d5ff0e6775d201e4e833f72"
    response.headers["Last-modified"] = "Mon, 18 Aug 2025 01:59:14 GMT"
    response.headers["server"] = "AwsMockServer/1.0"
    
    return response

@app.head("/{anyPath:path}")
async def read_put(request: Request, response: Response):
    urn = request.url.path
    print(f"Received request HEAD for: {urn}")
    urnPartList = urn.split("/")
    filteredUrlPartList = list(filter(lambda x: x > "", urnPartList))

    hederUserAgent = request.headers.get("User-Agent")
    print(f"User-Agent: {hederUserAgent}")

    bucketName = filteredUrlPartList[0]
    itemKey = "/".join(filteredUrlPartList[1:])
    
    print(f"HEAD")
    print(f"bucketName: {bucketName}")
    print(f"itemKey: {itemKey}")
    
    fileContent = AWSMock_bucket.downloadFile(bucketName, itemKey)

    response.status_code = 200
    response.headers["Connection"] = "close"
    response.headers["Content-Length"] = str(len(fileContent))
    response.headers["Content-Type"] = "application/octet-stream"
    response.headers["Date"] = DateTime.utcnow().strftime("%a, %d %b %Y %H:%M:%S GMT")
    response.headers["Etag"] = "vitorZago" # "5eff03c49d5ff0e6775d201e4e833f72"
    response.headers["Last-modified"] = "Mon, 18 Aug 2025 01:59:14 GMT"
    response.headers["Server"] = "AwsMockServer/1.0"
    
    return response


resources = json.loads(open('awsmock.json').read())

if resources.get("resourceList"):
    for resouce in resources.get("resourceList"):
        if resouce.get("resourceType") == "bucket":
            print(f"Creating resource {resouce.get('resourceType')} -> {resouce.get('resourceName')}")
        AWSMock_bucket.createBucket(resouce.get('resourceName'), resouce.get('localPath'))

if __name__ == "__main__":
    uvicorn.run("main:app", port=8080, log_level="info", reload=True)

