import os
import uuid
from datetime import datetime as DateTime, timedelta as TimeDelta
import localUtil
import AWSMock.AWSMock_Global as AWSMock_Global

snsStore = [];

class TopicMessage:
    P_TOPIC_NAME = "topic-name"
    P_CREATOR_ORIGIN = "creator-origin"
    P_PRODUCER_TIME = "producer-time"
    P_BODY = "body"
    P_DELIVERY_LIST = "delivery-list"
    P_MESSAGE_ID = "message-id"

class TopicMock:
    def __init__(self, name, local_path, **propDict):
        self.topic_name = name
        self.localPath = local_path
        self.creationTime = DateTime.utcnow().isoformat() + "Z"

        self.tryPretty = bool(propDict.get("tryPretty", False))

def createTopic(name, localPath):
    if not name or not localPath:
        raise Exception("Topic name and local path are required")
    
    if not localUtil.verifyIfResourcePathExistOrCresteIt(localPath, 'topic'):
        print(f"AVISO: Rescurso TOPIC ignorado: Caminho do recurso deve existir: {localPath}")
        return None
    
    new_topic = TopicMock(name, localPath)
    snsStore.append(new_topic)
    print(f"Topic created: {name} at {localPath}")
    return new_topic

def createTopicMessage(topic: TopicMock, messageBody, originIdentify, dateTimeProducer: DateTime):
    return {
        TopicMessage.P_TOPIC_NAME: topic.topic_name,
        TopicMessage.P_CREATOR_ORIGIN: originIdentify,
        TopicMessage.P_PRODUCER_TIME: dateTimeProducer.strftime('%Y-%m-%dT%H''h''%M''m''%S.%f''s'''),
        TopicMessage.P_BODY: messageBody,
        TopicMessage.P_DELIVERY_LIST: None,
        TopicMessage.P_MESSAGE_ID: str(uuid.uuid4()),
    }

def getTopic(topicName):
    for topic in snsStore:
        if topic.topic_name == topicName:
            return topic
    raise Exception(f"Topic not found '{topicName}'")

def write_file_item(topic:TopicMock, messageFilePath, messageDict):
    
    with open(messageFilePath, 'x') as file:
        file.write("[TOPIC_MESSAGE]\n")
        for mProperty in [TopicMessage.P_TOPIC_NAME, TopicMessage.P_CREATOR_ORIGIN, TopicMessage.P_PRODUCER_TIME, TopicMessage.P_MESSAGE_ID]:
            file.write(f"{mProperty}={messageDict[mProperty]}\n")
        file.write("\n")

        file.write("[DELIVERY]\n")
        file.write("\n")

        shieldComplement = ""
        if(topic.tryPretty): 
            (bodyContent, typeMatched) = localUtil.tryPrettyOrDefault(messageDict[TopicMessage.P_BODY])
            if  typeMatched:
                shieldComplement = f"**{typeMatched} Formated**"
        else:
            bodyContent = messageDict[TopicMessage.P_BODY]

        file.write(f"[BODY] {shieldComplement}\n")
        file.write(bodyContent)

def publish_message_response(topicName, messageBody, originIdentify, response):
    topic = getTopic(topicName)

    dateTimeReceived = DateTime.now()
    publishDict = createTopicMessage(topic, messageBody, originIdentify, dateTimeReceived)
    messageFilePath = os.path.join(topic.localPath, f"TM_{dateTimeReceived.strftime('%Y-%m-%dT%H''h''%M''m''%S.%f''s''')}.{AWSMock_Global.ITEM_DEFAULT_EXTENSION}")
    
    write_file_item(topic, messageFilePath, publishDict)
    
    AWSMock_Global.preencher_base_response_sns(response)
    
    response_body_dict = {
        "PublishResult": {
            "MessageId": publishDict[TopicMessage.P_MESSAGE_ID]
        },
        "ResponseMetadata": {
            "RequestId": response.headers.get("X-amz-request-id")
        }
    }

    AWSMock_Global.insert_response_body(response,
            localUtil.create_response_xml_body("PublishResponse", response_body_dict).encode('utf-8'))
    return response

