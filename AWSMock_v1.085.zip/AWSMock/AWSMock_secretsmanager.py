
import os
import AWSMock.AWSMock_Global as AWSMock_Global

secretsManager = []

def createSecretsManager(recurso):
    secretsDict = recurso.get("secretsDict", {})

    for dictKey in secretsDict:
        secretsManager.append({
            "key": dictKey,
            "value": secretsDict[dictKey]
        })

    print("Secrets Manager: Secrets foram adicionadas")

def get_secret_value_response(SecretId, response):
    secret = next((item for item in secretsManager if item["key"] == SecretId), None)

    if secret is not None:
        response_body_dict = {
            'ARN': f'arn:aws:secretsmanager:us-east-1:000000000000:secret:{SecretId}',
            'Name': SecretId,
            'VersionId': 'EXAMPLE1-90ab-cdef-fedc-ba987SECRET1',
            'SecretString': secret["value"],
            'VersionStages': ['AWSCURRENT'],
            'CreatedDate': 1633036800.0
        }

        return AWSMock_Global.preencher_base_response_json(response, response_dict = response_body_dict)
    else:
        response_body_dict = {
            "__type": "",
            "Message": f"Secrets Manager can't find the specified secret."
        }
        return AWSMock_Global.preencher_base_response_json(response, 400, response_dict = response_body_dict)