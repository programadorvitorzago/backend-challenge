def getValue_xxxV2(texto:str) -> float:
    texto = texto.strip()
    if texto == '':
        return 0    
    return float(texto) / 100

def formatValue_16V2(valor:float) -> str:
    return f"{int(abs(round(valor * 100))):0>18}"
    