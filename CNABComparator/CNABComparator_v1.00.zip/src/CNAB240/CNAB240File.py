from CNAB240 import CNAB240Spec
from CNAB240.CNABLote import CNABLote
import PTIOLib

class CNAB240File:
    
    filePath:str
    isLoad:bool = False

    header:str = None
    CNABLoteList:list = None
    trailer:str = None

    def __init__(self, filePath):
        self.filePath = filePath
        self.CNABLoteList = []

    def getHeader(self):
        return self.header
    
    def getTrailer(self):
        return self.trailer
    
    def getLotes(self):
        return self.CNABLoteList
    
    def countTotalRegistros(self) -> int:
        """ Retorna o número total de registros do arquivo CNAB240 """
        if not self.isLoad:
            raise Exception("Arquivo CNAB240 não carregado. Chame o método load() antes de acessar os dados.")
        
        total = 0
        if self.header is not None:
            total += 1  # Contabiliza o header do arquivo
        if self.trailer is not None:
            total += 1  # Contabiliza o trailer do arquivo

        for lote in self.CNABLoteList:
            total += lote.countTotalRegistros()

        return total

    def load(self):
        with open(self.filePath, 'r') as file:
            linhas = file.readlines()

            self.header = linhas[0].rstrip('\n')
            self.trailer = linhas[-1].rstrip('\n')

            # Processar lotes
            current_lote = None
            for linha in linhas[1:-1]:
                linha = linha.rstrip('\n')
                tipo_registro = PTIOLib.getValue(linha, CNAB240Spec.HEADER_ARQUIVO.TIPO_DE_REGISTRO)
                
                if tipo_registro == '1':  # Início de um novo lote
                    current_lote = CNABLote()
                    current_lote.header = linha
                    self.CNABLoteList.append(current_lote)

                elif tipo_registro == '3':  # Segmento do lote
                    current_lote.segmentoList.append(linha)
                    
                elif tipo_registro == '5':  # Trailer do lote
                    current_lote.trailer = linha
            
        self.isLoad = True
