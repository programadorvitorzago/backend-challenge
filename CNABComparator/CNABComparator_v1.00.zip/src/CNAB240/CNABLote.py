class CNABLote:
    
    header:str = None
    segmentoList:list = None
    trailer:str = None

    def __init__(self):
        self.segmentoList = []
        
    def getHeader(self):
        return self.header
    
    def getTrailer(self):
        return self.trailer
    
    def getSegmentos(self):
        return self.segmentoList
    
    def countTotalRegistros(self) -> int:
        """ Retorna o número total de registros do lote """

        total = 0
        if self.header is not None:
            total += 1  # Contabiliza o header do arquivo
        if self.trailer is not None:
            total += 1  # Contabiliza o trailer do arquivo

        total += len(self.segmentoList)  # Num de Segmentos

        return total