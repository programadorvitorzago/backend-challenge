import PTIOLib
from CNAB240 import CNAB240Spec
from CNAB240.CNAB240File import CNAB240File
import comparadorLib
from CompResult import ResultadoComparacao

resultadoComparacores:list[ResultadoComparacao] = []
showSuccessMessages = True

CNABPath1 = "D:/Desenvolvimento/CNABComparator/BL23037A - Exemplo.TXT"
CNABPath2 = "D:/Desenvolvimento/CNABComparator/BL24037A - Exemplo.TXT"

cnab01 = CNAB240File(CNABPath1)
cnab01.load()

cnab02 = CNAB240File(CNABPath2)
cnab02.load()

# Criterio 01 -  Comparar Campos do Header
resultadoComparacores.append(comparadorLib.camposHeader(cnab01, cnab02))

# Criterio 02 -  Comparacao Interna de SomaCredito e Soma Debitos
resultadoComparacores.append(comparadorLib.testeSomaCreditoSomaDebitoLotes(cnab01))

# Criterio 03 -  Comparacao Interna - Saldo Incial + Lançamentos = Saldo Final
resultadoComparacores.append(comparadorLib.testeSaldoInicialESaldoFinalLotes(cnab01))

# Criterio 04 -  Comparacao Interna - Valida Número de Registros total do arquivo
resultadoComparacores.append(comparadorLib.testeNumeroDeRegistrosTotal(cnab01))

# Criterio 05 -  Comparacao Interna - Valida Número Total de Lotes
resultadoComparacores.append(comparadorLib.testeNumeroTotalDeLotes(cnab01))

# Criterio 06 -  Comparacao Interna - Valida quantidade Total de Registros em cada lote
resultadoComparacores.append(comparadorLib.testeNumeroTotalDeRegistrosEmCadaLote(cnab01))

# Criterio 07 -  Comparacao Interna - Valida sequencial dos lotes
resultadoComparacores.append(comparadorLib.testeNumeroSequencialLotes(cnab01))

# Print Results
for index, resultado in enumerate(resultadoComparacores):
    print(f"Criterio {index + 1:02}: {resultado.criterio}")
    print(f'Resultado: {"✅ OK" if resultado.resultado else "❌ FALHA"}')
    
    if (not resultado.resultado) or showSuccessMessages:
        print(f"Mensagem: {resultado.mensagem}")
    
    print("--------------------------------------------------")




