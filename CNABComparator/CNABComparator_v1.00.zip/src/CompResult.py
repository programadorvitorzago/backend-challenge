class ResultadoComparacao:
    criterio:str
    resultado:bool
    mensagem:str

