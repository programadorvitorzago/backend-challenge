# PTIOLib v1.00

class PositionRef:
    def __init__(self, nome, posIni, posFim = None , tamanho = None):
        self.name = nome
        self.indexIni = posIni - 1
        if posFim is not None:
            self.indexFim = posFim
            self.tamanho = posFim - posIni + 1
        elif tamanho is not None:
            self.tamanho = tamanho
            self.indexFim = posIni + tamanho - 1
        else:
            raise ValueError("Either posFim or tamanho must be provided, but not both.")

def getValue(linhaTexto, posicaoRef: PositionRef):
    return linhaTexto[posicaoRef.indexIni:posicaoRef.indexFim]

def setValue(linhaTexto, posicaoRef: PositionRef, valor):
    if len(valor) > (posicaoRef.tamanho):
        raise ValueError("Value length does not match the position reference length.")
    else:
        valor = valor.ljust(posicaoRef.tamanho)  # Pad with spaces if necessary
    
    return linhaTexto[:posicaoRef.indexIni] + valor + linhaTexto[posicaoRef.indexFim:]
