from CNAB240 import CNAB240Spec, CNABUtils
from CNAB240.CNAB240File import CNAB240File
from CNAB240.CNABLote import CNABLote
import PTIOLib
from CompResult import ResultadoComparacao

def camposHeader(cnab1, cnab2):
    """ Compara os campos do header de 2 CNABS"""

    result = ResultadoComparacao()
    result.criterio = "Campos de HEADER"

    campoList = [CNAB240Spec.HEADER_ARQUIVO.CODIGO_DO_BANCO,
                 CNAB240Spec.HEADER_ARQUIVO.CODIGO_DO_LOTE,
                    CNAB240Spec.HEADER_ARQUIVO.TIPO_DE_REGISTRO,
                    CNAB240Spec.HEADER_ARQUIVO.TIPO_DE_INSCRICAO,
                    CNAB240Spec.HEADER_ARQUIVO.NUMERO_DE_INSCRICAO,
                    CNAB240Spec.HEADER_ARQUIVO.CONVENIO,
                    CNAB240Spec.HEADER_ARQUIVO.AGENCIA,
                    CNAB240Spec.HEADER_ARQUIVO.CONTA,
                    CNAB240Spec.HEADER_ARQUIVO.DAC_AG___CTA,
                    CNAB240Spec.HEADER_ARQUIVO.NOME,
                    CNAB240Spec.HEADER_ARQUIVO.DATA_DA_GERACAO]
    
    for campo in campoList:
        valor1 = PTIOLib.getValue(cnab1.getHeader(), campo)
        valor2 = PTIOLib.getValue(cnab2.getHeader(), campo)

        if valor1 != valor2:
            result.resultado = False
            result.mensagem = f"Campo {campo.name} difere: CNAB1='{valor1}' | CNAB2='{valor2}'"
            return result    
    
    result.resultado = True
    result.mensagem = f"Todos os campos do HEADER são iguais. Comparado {len(campoList)} campos."
    return result   

def testeSomaCreditoSomaDebitoLotes(cnab1:CNAB240File):
    """Testa INTERNAMENTE a Soma Créditos e Soma Débitos dos Lotes """

    result = ResultadoComparacao()
    result.criterio = "INTERNO - Validar Soma de Créditos e Débitos dos Lotes"
    errorMessageList = []
    
    loteList = cnab1.getLotes()

    if loteList and len(loteList) > 0:
        for lote in loteList:
            loteNumero = PTIOLib.getValue(lote.getHeader(), CNAB240Spec.HEADER_LOTE.CODIGO_DO_LOTE)
            totalSomaCreditosTexto = PTIOLib.getValue(lote.getTrailer(), CNAB240Spec.TRAILER_LOTE.TOTAL_VALOR_CREDITO)
            totalSomaDebitosTexto = PTIOLib.getValue(lote.getTrailer(), CNAB240Spec.TRAILER_LOTE.TOTAL_VALOR_DEBITO)

            #Somar Creditos e Débitos de todos os lançamentos contabeis do lote
            somaCreditos, somaDebitos = aux_somaLancamentosCreditosDebitos_Contabeis(lote)
            
            somaCreditoCalculadoTexto = CNABUtils.formatValue_16V2(somaCreditos)
            somaDebitoCalculadoTexto = CNABUtils.formatValue_16V2(somaDebitos)

            if somaCreditoCalculadoTexto != totalSomaCreditosTexto:    
                errorMessageList.append(f"Lote {loteNumero}: Soma de Créditos diverge. Esperado: {totalSomaCreditosTexto}, Calculado: {somaCreditoCalculadoTexto}")
            if somaDebitoCalculadoTexto != totalSomaDebitosTexto:    
                errorMessageList.append(f"Lote {loteNumero}: Soma de Débitos diverge. Esperado: {totalSomaDebitosTexto}, Calculado: {somaDebitoCalculadoTexto}")

        saldoInicialTexto = PTIOLib.getValue(lote.getHeader(), CNAB240Spec.HEADER_LOTE.VALOR_INICIAL)

        if len(errorMessageList) > 0:
            result.resultado = False
            result.mensagem = " | ".join(errorMessageList)
            return result
        
        result.resultado = True
        result.mensagem = f"SomaCredito e SomaDebito OK em todos os lotes"
        return result
    else:
        result.resultado = True
        result.mensagem = "Não há lotes para processar."
        return result
    
def testeSaldoInicialESaldoFinalLotes(cnab1:CNAB240File):
    """Testa INTERNAMENTE se o Saldo Inicial + Créditos - Débitos = Saldo Final dos Lotes """

    result = ResultadoComparacao()
    result.criterio = "INTERNO - Valida Saldo Inicial + Créditos - Débitos = Saldo Final dos Lotes"
    errorMessageList = []
    
    loteList = cnab1.getLotes()

    if loteList and len(loteList) > 0:
        for lote in loteList:
            loteNumero = PTIOLib.getValue(lote.getHeader(), CNAB240Spec.HEADER_LOTE.CODIGO_DO_LOTE)
            saldoInicialTexto = PTIOLib.getValue(lote.getHeader(), CNAB240Spec.HEADER_LOTE.VALOR_INICIAL)
            situacaoSaldoInicial = PTIOLib.getValue(lote.getHeader(), CNAB240Spec.HEADER_LOTE.SITUACAO_INICIAL)
            saldoInicial = CNABUtils.getValue_xxxV2(saldoInicialTexto)
            if situacaoSaldoInicial == 'D':  # Valor negativo
                saldoInicial = -saldoInicial

            saldoFinalTexto = PTIOLib.getValue(lote.getTrailer(), CNAB240Spec.TRAILER_LOTE.SALDO_FINAL)
            situacaoSaldoFinal = PTIOLib.getValue(lote.getTrailer(), CNAB240Spec.TRAILER_LOTE.SITUACAO)

            #Somar Creditos e Débitos de todos os lançamentos contabeis do lote
            somaCreditos, somaDebitos = aux_somaLancamentosCreditosDebitos_Contabeis(lote)
            
            saldoFinalCalculado = saldoInicial + somaCreditos - somaDebitos
            saldoFinalCalculadoTexto = CNABUtils.formatValue_16V2(saldoFinalCalculado)
            situacaoSaldoFinalCalculado = 'C' if saldoFinalCalculado >= 0 else 'D'
            
            if saldoFinalCalculadoTexto != saldoFinalTexto:    
                errorMessageList.append(f"Lote {loteNumero}: Saldo Final diverge. Esperado: {saldoFinalTexto}, Calculado: {saldoFinalCalculadoTexto}")
            if situacaoSaldoFinalCalculado != situacaoSaldoFinal:    
                errorMessageList.append(f"Lote {loteNumero}: Situação do Saldo Final diverge. Esperado: {situacaoSaldoFinal}, Calculado: {situacaoSaldoFinalCalculado}")

        if len(errorMessageList) > 0:
            result.resultado = False
            result.mensagem = " | ".join(errorMessageList)
            return result
        
        result.resultado = True
        result.mensagem = f"Fluxo de SALDO OK en todos os Lotes"
        return result
    else:
        result.resultado = True
        result.mensagem = "Não há lotes para processar."
        return result

def aux_somaLancamentosCreditosDebitos_Contabeis(lote:CNABLote) -> tuple[float, float]:
    somaCreditos = 0.0
    somaDebitos = 0.0
    for segmentoE in lote.getSegmentos():

        tipoLancamento = PTIOLib.getValue(segmentoE, CNAB240Spec.SEGMENTO_E.TIPO_LANCAMENTO)
        if tipoLancamento not in ['1', '2']:
            continue  # Ignorar lançamentos que não sejam contábeis

        # Captura o Valor do Lançamento e o Identificador se é Crédito ou Débito
        valorLancamentoTexto = PTIOLib.getValue(segmentoE, CNAB240Spec.SEGMENTO_E.VALOR)
        valorLancamento = CNABUtils.getValue_xxxV2(valorLancamentoTexto)
        lancamentoCredDeb = PTIOLib.getValue(segmentoE, CNAB240Spec.SEGMENTO_E.LANCAMENTO)

        if lancamentoCredDeb == 'C':  # Crédito
            somaCreditos += valorLancamento
        elif lancamentoCredDeb == 'D':  # Débito
            somaDebitos += valorLancamento
        else:
            raise ValueError(f"Identificador de Lançamento Cred / Deb desconhecido: {lancamentoCredDeb}")
        
    return somaCreditos, somaDebitos

def testeNumeroDeRegistrosTotal(cnab1:CNAB240File):
    """Testa INTERNAMENTE se o Número de Registros Total do Arquivo está correto """

    result = ResultadoComparacao()
    result.criterio = "INTERNO - Validar Número de Registros Total do Arquivo"
    
    numeroRegistrosTotalTexto = PTIOLib.getValue(cnab1.getTrailer(), CNAB240Spec.TRAILER_ARQUIVO.TOTAL_QTDE_REGISTROS)
    numeroRegistrosTotal = int(numeroRegistrosTotalTexto)

    # Calcular o número real de registros no arquivo
    numTotalRegistrosCalculado = cnab1.countTotalRegistros()

    if numTotalRegistrosCalculado != numeroRegistrosTotal:
        result.resultado = False
        result.mensagem = f"Número de Registros Total diverge. Informado: {numeroRegistrosTotal}, Calculado: {numTotalRegistrosCalculado}"
    else:
        result.resultado = True
        result.mensagem = f"Número de Registros Total está correto: {numeroRegistrosTotal}"
    return result

def testeNumeroTotalDeLotes(cnab1:CNAB240File):
    """Testa INTERNAMENTE se o Número de Total de Lotes está correto """

    result = ResultadoComparacao()
    result.criterio = "INTERNO - Validar Número Total de Lotes do Arquivo"
    
    numTotalLotesTexto = PTIOLib.getValue(cnab1.getTrailer(), CNAB240Spec.TRAILER_ARQUIVO.TOTAL_QTDE_DE_LOTES)
    numTotalLotes = int(numTotalLotesTexto)

    # Calcular o número lotes no Arquivo
    numTotalLotesCalculado = len(cnab1.getLotes())

    if numTotalLotesCalculado != numTotalLotes:
        result.resultado = False
        result.mensagem = f"Número Total de Lotes diverge. Informado: {numTotalLotes}, Calculado: {numTotalLotesCalculado}"
    else:
        result.resultado = True
        result.mensagem = f"Número Total de Lotes está correto: {numTotalLotes}"
    return result

def testeNumeroTotalDeRegistrosEmCadaLote(cnab1:CNAB240File):
    """Testa INTERNAMENTE se o Número de Total de Registros (Segmentos) estão corretos em cada lote """

    result = ResultadoComparacao()
    result.criterio = "INTERNO - Validar Número de Total de Registros (Segmentos) em cada lote"

    errorMessageList = []
    
    loteList = cnab1.getLotes()

    if loteList and len(loteList) > 0:
        for lote in loteList:
            loteNumero = PTIOLib.getValue(lote.getHeader(), CNAB240Spec.HEADER_LOTE.CODIGO_DO_LOTE)

            totalRegistroNoLoteTexto = PTIOLib.getValue(lote.getTrailer(), CNAB240Spec.TRAILER_LOTE.TOTAL_QTDE_REGISTROS)
            totalRegistroNoLote = int(totalRegistroNoLoteTexto)
            
            totalRegistroNoLoteCalculado = lote.countTotalRegistros()
            
            if totalRegistroNoLoteCalculado != totalRegistroNoLote:    
                errorMessageList.append(f"Lote {loteNumero}: Qtde total de registros diverge. Esperado: {totalRegistroNoLote}, Calculado: {totalRegistroNoLoteCalculado}")

        if len(errorMessageList) > 0:
            result.resultado = False
            result.mensagem = " | ".join(errorMessageList)
        else:
            result.resultado = True
            result.mensagem = f"Quantidade Total de Registros nos Lotes OK: numLotes testados: {len(loteList)}" 
        return result
    else:
        result.resultado = True
        result.mensagem = "Não há lotes para processar."
        return result
    
def testeNumeroSequencialLotes(cnab1:CNAB240File):
    """Testa INTERNAMENTE se o Número Sequencial dos Lotes está correto
    O número sequencial dos lotes deve começar em 1 e incrementar de 1 em 1 para code novo lote.
    O campo reservado para o número sequencial no HEADER do arquivo deve ser igual a '0000' e no TRAILER de arquivo deve ser igual a '9999'."""

    result = ResultadoComparacao()
    result.criterio = "INTERNO - Validar Número Sequencial dos Lotes no Arquivo"

    errorMessageList = []

    # Teste HEADER e TRAILER do Arquivo
    numeroSequencial = PTIOLib.getValue(cnab1.getHeader(), CNAB240Spec.HEADER_ARQUIVO.CODIGO_DO_LOTE)
    if numeroSequencial != '0000':
        errorMessageList.append(f"HEADER do Arquivo: Código do Lote deve ser '0000'. Encontrado: '{numeroSequencial}'")

    numeroSequencial = PTIOLib.getValue(cnab1.getTrailer(), CNAB240Spec.HEADER_ARQUIVO.CODIGO_DO_LOTE)
    if numeroSequencial != '9999':
        errorMessageList.append(f"TRAILER do Arquivo: Código do Lote deve ser '9999'. Encontrado: '{numeroSequencial}'")
    
    loteList = cnab1.getLotes()
    numeroSequencialInit = 1
    if loteList and len(loteList) > 0:
        for lote in loteList:
            headerLoteNumeroTexto = PTIOLib.getValue(lote.getHeader(), CNAB240Spec.HEADER_LOTE.CODIGO_DO_LOTE)
            headerLoteNumero = int(headerLoteNumeroTexto)

            trailerLoteNumeroTexto = PTIOLib.getValue(lote.getTrailer(), CNAB240Spec.TRAILER_LOTE.CODIGO_DO_LOTE)
            trailerLoteNumero = int(trailerLoteNumeroTexto)

            if numeroSequencialInit != headerLoteNumero:    
                errorMessageList.append(f"Lote {headerLoteNumero} HEADER: deveria ser o lote de número {numeroSequencialInit}.")
            if trailerLoteNumero != headerLoteNumero:    
                errorMessageList.append(f"Lote {trailerLoteNumero} TRAILER: deveria ser o lote de número {numeroSequencialInit}.")


            numeroSequencialInit += 1

    if len(errorMessageList) > 0:
        result.resultado = False
        result.mensagem = " | ".join(errorMessageList)
    else:
        result.resultado = True
        result.mensagem = f"Número sequencial do Lotes OK: numLotes testados: {len(loteList)}" 
    return result
    

    
    