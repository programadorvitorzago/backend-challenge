START_FUNCTION = """
import sys
import os
import json

sys.path.append(os.path.join(os.getcwd()), "${base_path}"))
from ${lambda_location} import ${lambda_name}

# Exemplo de evento simulando uma invocação do Lambda
eventInput = json.loads(${inputBase64}.decode("utf-8"))

# Contexto simulado (pode ser um objeto vazio ou um mock)
context = type('Context', (object,), {
    "function_name": "test_lambda_function",
    "get_remaining_time_in_millis": lambda self: 300000
})()

# Chamar a função Lambda com o evento e contexto simulados
execLambdaResponse = ${lambda_name}(eventInput, context)
"""