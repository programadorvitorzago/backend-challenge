import base64
from datetime import datetime as DateTime, timedelta as TimeDelta
import json
import os
import threading
from AWSMock import AWSMock_queue
import AWSMock.AWSMock_Global as AWSMock_Global
import time as SystemTimer
from string import Template
import AWSMock.AWSMock_lambda_engineFunction as AWSMock_lambda_engineFunction


lambdaStore = [];

class LambdaMock:
    def __init__(self, lambda_name, local_path, **propDict):
        self.lambda_name = lambda_name
        self.localPath = local_path
        self.creationTime = DateTime.now()
        
        self.language = propDict.get("language", "defaultLanguage")
        self.functionHandlerFilePath = propDict.get("functionHandlerFilePath", "")
        self.functionHandlerName = propDict.get("functionHandlerName", "lambda_handler")
        self.envFile = propDict.get("envFile", ".env")

        self.triggerList = propDict.get("triggerList", [])

def createLambda(lambdaName, localPath, propDict):
    if not lambdaName or not localPath:
        raise Exception("LambdaName and local path are required")
    new_lambda = LambdaMock(lambdaName, localPath, **propDict)
    lambdaStore.append(new_lambda)
    print(f"Lambda created: {lambdaName} at {localPath}")
    return new_lambda

def getLambda(lambdaName):
    for item in lambdaStore:
        if item.lambda_name == lambdaName:
            return item
    raise Exception(f"Lambda not found: {lambdaName}")

def write_file_item(messageFilePath, logDict, lambdaResquet, lambdaResponse):
    with open(messageFilePath, 'x', encoding="utf-8") as file:
        file.write("[LAMBDA_EXECUTION]\n")
        for mProperty in logDict:
            propValue = logDict.get(mProperty, "")
            if propValue:
                file.write(f"{mProperty}={logDict[mProperty]}\n")
        file.write("\n")

        file.write("[LAMBDA_RESQUETS]\n")
        file.write(lambdaResquet)
        file.write("\n\n")

        file.write("[LAMBDA_RESPONSE]\n")
        file.write(lambdaResponse)


def execLambda(lambdaName, eventStr):
    dateTimeNow = DateTime.now()
    lambdaObj = getLambda(lambdaName)

    startEngineTmpl = Template(AWSMock_lambda_engineFunction.START_FUNCTION)
    keyWords = {
        "lambda_location": lambdaObj.functionHandlerFilePath.replace("/","."),
        "lambda_name": lambdaObj.functionHandlerName,
        "inputBase64": eventStr.encode('utf-8')
    }
    
    startEngine = startEngineTmpl.substitute(keyWords)
    
    executionLocal = {}
    execLambdaResponse = ''
    try:
        exec(startEngine, globals(), executionLocal)
    except Exception as e:
        print(f"Error executing Lambda function '{lambdaName}': {e}")

    execLambdaResponse = str(executionLocal.get('execLambdaResponse', ''))
    logDict = {
        "execution-date": dateTimeNow.strftime('%Y-%m-%dT%H:%M:%S.%f'),
        "source-trigger": "sqs",
        "lambda-name": lambdaObj.lambda_name,
        "base_path": lambdaObj.localPath
    }

    messageFilePath = os.path.join(lambdaObj.localPath, f"LAMBDA_{dateTimeNow.strftime('%Y-%m-%dT%H''h''%M''m''%S.%f''s''')}.{AWSMock_Global.ITEM_DEFAULT_EXTENSION}")
    write_file_item(messageFilePath, logDict, eventStr, execLambdaResponse);
    
    # execFilePath = localUtil.createTempFile(startEngine, prefix="AWSMock_lambda_engineFunction_", suffix=".py")
    # localUtil.writeJsonToFile(event, "lambdaQueueEvent.json")
    # print(f"Executing Lambda function '{lambdaName}' from '{execFilePath}'")
    # localUtil.execPythonFile(execFilePath)

def execLambda_newProcess(lambdaName, eventStr):
    import tempfile

    (_, tempFilePath) = tempfile.mkstemp(suffix=".RAW")
    with open(tempFilePath, "wb") as file:
        file.write(eventStr.encode("utf-8"))

    dateTimeNow = DateTime.now()
    lambdaObj = getLambda(lambdaName)

    startFilePath = os.path.join(lambdaObj.localPath, ".engine.py")
    moduleName = os.path.basename(lambdaObj.functionHandlerFilePath).replace(".py", "")
    addPath = os.path.join(os.getcwd(), os.path.dirname(lambdaObj.functionHandlerFilePath))

    print("Startirg new Process ...")
    executionLocal = {}
    execLambdaResponse = ''
    try:
        os.system(f"python {startFilePath} {addPath} {moduleName} {lambdaObj.functionHandlerName} {lambdaObj.envFile} {tempFilePath}")
    except Exception as e:
        print(f"Error executing Lambda function '{lambdaName}': {e}")

    execLambdaResponse = str(executionLocal.get('execLambdaResponse', ''))
    logDict = {
        "execution-date": dateTimeNow.strftime('%Y-%m-%dT%H:%M:%S.%f'),
        "source-trigger": "sqs",
        "lambda-name": lambdaObj.lambda_name,
        "base_path": lambdaObj.localPath
    }

    messageFilePath = os.path.join(lambdaObj.localPath, f"LAMBDA_{dateTimeNow.strftime('%Y-%m-%dT%H''h''%M''m''%S.%f''s''')}.{AWSMock_Global.ITEM_DEFAULT_EXTENSION}")
    write_file_item(messageFilePath, logDict, eventStr, execLambdaResponse);
    
    # execFilePath = localUtil.createTempFile(startEngine, prefix="AWSMock_lambda_engineFunction_", suffix=".py")
    # localUtil.writeJsonToFile(event, "lambdaQueueEvent.json")
    # print(f"Executing Lambda function '{lambdaName}' from '{execFilePath}'")
    # localUtil.execPythonFile(execFilePath)    

def process_trigger_sqs(lambdaObj, triggerPropDict):
    queueObj = AWSMock_queue.getQueue(triggerPropDict["triggerSourceName"])
    
    (queueMessage, request_inf) = AWSMock_queue.receive_message_peek(queueObj)
    
    if queueMessage:
        messageId = queueMessage[AWSMock_queue.QueueMessage.P_MESSAGE_ID]
        response_body_dict = {
            "messageId": messageId,
            "md5OfBody": queueMessage[AWSMock_queue.QueueMessage.P_MD5_OF_BODY],
            "body": queueMessage[AWSMock_queue.QueueMessage.P_BODY],
            "attributes": queueMessage["Attributes"],
        }
        execSuccess = False
        try:
            execLambda_newProcess(lambdaObj.lambda_name, json.dumps({"Records": [response_body_dict]}))
            execSuccess = True
        except Exception as ex:
            print("Exception calling Lambda from SQS: ", ex)
        
        if execSuccess and triggerPropDict.get("deleteMessageAfterExec", False):
            AWSMock_queue.delete_message_by_handlerId(queueObj, request_inf["handlerId"])
            print(f"Lambda '{lambdaObj.lambda_name}' executed successfully for message ID '{messageId}'. Message deleted from queue.")

def monitorMainLoop():
    while True:
        # verificar as filas e invocar as lambdas
        SystemTimer.sleep(5)
        
        # Iterar todos os Trigguers de Todos as Lambdas
        for lambdaObj in lambdaStore:
            for lambdaTrigger in lambdaObj.triggerList:
                if lambdaTrigger.get("triggerType", "") == "sqs":
                    process_trigger_sqs(lambdaObj, lambdaTrigger)
           
def startMonitorLambda():
    # criar uma thread para monitorar as filas e invocar as lambdas

    thread1 = threading.Thread(target=monitorMainLoop)
    thread1.start()
    print("Lambda MONITOR started.")




