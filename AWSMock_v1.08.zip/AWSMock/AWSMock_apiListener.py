import base64
from datetime import datetime as DateTime, timedelta as TimeDelta
import json
import os
import threading
from AWSMock import AWSMock_queue
import AWSMock.AWSMock_Global as AWSMock_Global
import time as SystemTimer
from string import Template
import AWSMock.AWSMock_lambda_engineFunction as AWSMock_lambda_engineFunction


apiListenerStore = [];

class ApiListenerMock:
    def __init__(self, apiName, local_path, **propDict):
        self.api_name = apiName
        self.localPath = local_path
        self.creationTime = DateTime.now()
        
        self.rootPath = propDict.get("rootPath", "")

def createApiListener(apiName, localPath, propDict):
    if not apiName or not localPath:
        raise Exception("ApiName and local path are required")
    new_lambda = ApiListenerMock(apiName, localPath, **propDict)
    
    apiListenerStore.append(new_lambda)
    print(f"ApiListener created: {apiName} at {localPath}")
    return new_lambda

def getApiListener(apiName):
    for item in apiListenerStore:
        if item.api_name == apiName:
            return item
    raise Exception(f"ApiListener not found: {apiName}")

def write_file_item(messageFilePath, logDict, lambdaResquet, lambdaResponse):
    with open(messageFilePath, 'x', encoding="utf-8") as file:
        file.write("[API_LISTENER_RECEIVED_REQUEST]\n")
        for mProperty in logDict:
            propValue = logDict.get(mProperty, "")
            if propValue:
                file.write(f"{mProperty}={logDict[mProperty]}\n")
        file.write("\n")

        file.write("[RESQUETS_BODY]\n")
        file.write(lambdaResquet)
        file.write("\n\n")
        
        file.write("[RESPONSE]\n")
        file.write(lambdaResponse)

def getApiByRequestPath(requestPath):
    for api in apiListenerStore:
        if requestPath.startswith(api.rootPath):
            return api
    return None

def log_and_get_default_response(apiObj, request, response, bodyContent: bytes):
    dateTimeReceived = DateTime.now()
    
    logDict = {}
    logDict["API_NAME"] = apiObj.api_name
    logDict["REQUEST_TIME"] = dateTimeReceived.strftime("%Y-%m-%d %H:%M:%S")
    logDict["REQUEST_PATH"] = request.url.path
    logDict["REQUEST_METHOD"] = request.method
    logDict["REQUEST_PARAMS"] = json.dumps(dict(request.query_params))
    logDict["REQUEST_HEADERS"] = json.dumps(dict(request.headers))
    
    try:
        requestData = bodyContent.decode("utf-8")
    except Exception as e:
        logDict["REQUEST_DATA_ERROR"] = str(e)
        requestData = ""
       
    default_response = json.dumps({
        "statusCode": 200,
        "headers": {
            "Content-Type": "application/json"
        },
        "body": json.dumps({"message": "Default response"}),
        "isBase64Encoded": False
    })
    
    messageFilePath = os.path.join(apiObj.localPath, f"API_{dateTimeReceived.strftime('%Y-%m-%dT%H''h''%M''m''%S.%f''s''')}.{AWSMock_Global.ITEM_DEFAULT_EXTENSION}")
    write_file_item(messageFilePath, logDict, requestData, default_response)

    AWSMock_Global.preencher_base_response_json(response)
    response.headers["Connection"] = "close"
    
    bodyBytes = json.dumps({"message": "defaultResponse"}).encode("utf-8")
    response.headers["Content-length"] = str(len(bodyBytes))
    response.body = bodyBytes

    return response
    
