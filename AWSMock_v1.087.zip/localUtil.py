import xml.etree.ElementTree as ET
from xml.etree.ElementTree import Element
from datetime import datetime as DateTime
import hashlib
from urllib.parse import unquote, unquote_plus
import json
import os

from AWSMock import AWSMock_Global

def create_xml_element(key, val):
    xmlElement = ET.Element(key)
    if isinstance(val, dict):
        for subkey, subvalue in val.items():
            xmlElement.append(create_xml_element(subkey, subvalue))
    elif isinstance(val, list):
        for item in val:
            xmlElement.append(create_xml_element(key, item))
    else:
        if val is not None:
            xmlElement.text = str(val)
    return xmlElement

def elementXML_ToString(element: Element):
    return ET.tostring(element, encoding='utf-8').decode('utf-8')

def dict_to_xml_element_str(rootElementTagName, contentDict):
    rootElement = create_xml_element(rootElementTagName, contentDict)
    return elementXML_ToString(rootElement)

def create_response_xml_body(rootElementTagName, contentDict):
    return f"<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n{dict_to_xml_element_str(rootElementTagName, contentDict)}"

def create_response_xml_body_fromElementClass(rootElementRoot: Element):
    return f"<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n{elementXML_ToString(rootElementRoot)}"

def md5_hash(text):
    return hashlib.md5(text.encode('utf-8')).hexdigest()

def urlDecode(text):
    return unquote_plus(text)

def decode_aws_chunked(chunkedData: bytes) -> str:
    decodedBytes = bytearray()
    index = 0
    length = len(chunkedData)

    while index < length:
        # Find the position of the next CRLF
        crlf_pos = chunkedData.find(b'\r\n', index)
        if crlf_pos == -1:
            break  # No more chunks

        # Get the chunk size in hex and convert to int
        chunk_str = chunk_size_hex = chunkedData[index:crlf_pos].decode('utf-8').strip()
        if chunk_str.find(';') != -1:
            chunk_size_hex = chunk_str.split(';')[0]
        chunk_size = int(chunk_size_hex, 16)

        if chunk_size == 0:
            break  # Last chunk

        # Move index to the start of the chunk data
        index = crlf_pos + 2

        # Append the chunk data to the decoded bytes
        decodedBytes.extend(chunkedData[index:index + chunk_size])

        # Move index to the end of the chunk data plus the trailing CRLF
        index += chunk_size + 2

    return decodedBytes #.decode('iso-8859-1') # Usando iso-8859-1 para manter os bytes originais

def verifyIfResourcePathExistOrCresteIt(localPath, resourceName):
    if not os.path.exists(localPath):
        if os.path.isabs(localPath) or not AWSMock_Global.CREATE_DIR:
            return False
        else:
            os.makedirs(localPath, exist_ok=True)
            return True
    return True

def tryPrettyOrDefault(data):
    try:
        jsonResult = json.loads(data)
        return json.dumps(jsonResult, indent=4), "Json"
    except ValueError:
        return data, None
        