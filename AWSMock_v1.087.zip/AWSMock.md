# Apresentamos o
```
    ___        ______  __  __            _    
   / \ \      / / ___||  \/  | ___   ___| | __
  / _ \ \ /\ / /\___ \| |\/| |/ _ \ / __| |/ /
 / ___ \ V  V /  ___) | |  | | (_) | (__|   < 
/_/   \_\_/\_/  |____/|_|  |_|\___/ \___|_|\_\
```

## O que é
O AWSMock é uma solução prática que permite ao programador desenvolver soluções mais velocidade e eficiencia principalmente quando o projeto envolve utilziação de artefatos AWS.

## Configurando o AWSMock
Para confirgurar o AWSMock é necessário apresentar na pasta de execução da aplicação, um arquivo de nome awsmock.json com os seguintes parâmetros em sua raiz:
- port: porta de execução do AWSMock. Padrão é 9958;
- createRelativeDirectory: 
- resourceList: 


## Recursos Emulados

### Bucket
A emulação de um Bucket 


### Fila / SQS Queue

### Topic / SNS

### SecretsManager

### apiLIstener

### Lambda BETA


### Vantagens e Desvantagens
A Emulação via AWSMock permite desenver rapidamente aplicações que dependem de recursos e elementos AWS, sem a necessidade de ficar acessando efetivamente um conta AWS e tendo que configurar os artefatos e permissões de acesso para fazer um prova de conceito.

