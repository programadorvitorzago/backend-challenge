import sys
import os
import json
import sys
from dotenv import load_dotenv
import importlib

# ARG 01 - PATH
# ARG 02 - MODULE NAME
# ARG 03 - FUNCTION
# ARG 04 - ENV FILE
# ARG 05 - INPUT ENVT

addPath = sys.argv[1]
moduleName = sys.argv[2]
functionName = sys.argv[3]
envFilePath = sys.argv[4]
eventInputFilePath = sys.argv[5]

sys.path.append(addPath)

load_dotenv(envFilePath)

mainModule = importlib.import_module(moduleName)

# Exemplo de evento simulando uma invocação do Lambda
eventInput = json.load(open(eventInputFilePath))
# Contexto simulado (pode ser um objeto vazio ou um mock)
context = type('Context', (object,), {
    "function_name": "test_lambda_function",
    "get_remaining_time_in_millis": lambda self: 300000
})()

# Chamar a função Lambda com o evento e contexto simulados
my_function = getattr(mainModule, functionName)
execLambdaResponse = my_function(eventInput, context)

