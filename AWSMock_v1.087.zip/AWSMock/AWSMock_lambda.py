from datetime import datetime as DateTime, timedelta as TimeDelta
import json5
import json
import os
import threading
import AWSMock.AWSMock_queue as AWSMock_queue
import AWSMock.AWSMock_Global as AWSMock_Global
import time as SystemTimer
from string import Template
import AWSMock.AWSMock_lambda_engineFunction as AWSMock_lambda_engineFunction
import AWSMock.AWSMock_apiCaller as AWSMock_apiCaller
import localUtil

lambdaStore = [];

class LambdaMock:
    def __init__(self, lambda_name, local_path, **propDict):
        self.lambda_name = lambda_name
        self.localPath = local_path
        self.creationTime = DateTime.now()
        
        self.language = propDict.get("language", "defaultLanguage")
        self.functionHandlerFilePath = propDict.get("functionHandlerFilePath", "")
        self.functionHandlerName = propDict.get("functionHandlerName", "lambda_handler")
        self.envFile = propDict.get("envFile", ".env")
        self.overrideExecutor = propDict.get("overrideExecutor", "")

        self.triggerList = propDict.get("triggerList", [])

        self.vscodeLaunchFile = propDict.get("vscodeLaunchFile", ".vscode/launch.json")

def createLambda(lambdaName, localPath, propDict):
    if not lambdaName or not localPath:
        raise Exception("LambdaName and local path are required")

    if not localUtil.verifyIfResourcePathExistOrCresteIt(localPath, 'queue'):
        print(f"AVISO: Rescurso Lambda ignorado: Caminho do recurso deve existir: {localPath}")
        return None
        
    new_lambda = LambdaMock(lambdaName, localPath, **propDict)
    lambdaStore.append(new_lambda)
    print(f"Lambda created: {lambdaName} at {localPath}")
    return new_lambda

def getLambda(lambdaName):
    for item in lambdaStore:
        if item.lambda_name == lambdaName:
            return item
    raise Exception(f"Lambda not found: {lambdaName}")

def write_file_item(messageFilePath, logDict, lambdaResquet, lambdaResponse):
    with open(messageFilePath, 'x', encoding="utf-8") as file:
        file.write("[LAMBDA_EXECUTION]\n")
        for mProperty in logDict:
            propValue = logDict.get(mProperty, "")
            if propValue:
                file.write(f"{mProperty}={logDict[mProperty]}\n")
        file.write("\n")

        file.write("[LAMBDA_RESQUETS]\n")
        file.write(lambdaResquet)
        file.write("\n\n")

        file.write("[LAMBDA_RESPONSE]\n")
        file.write(lambdaResponse)


def execLambda(lambdaName, eventStr):
    dateTimeNow = DateTime.now()
    lambdaObj = getLambda(lambdaName)

    startEngineTmpl = Template(AWSMock_lambda_engineFunction.OFFLINE_START_FUNCTION)
    keyWords = {
        "lambda_location": lambdaObj.functionHandlerFilePath.replace("/","."),
        "lambda_name": lambdaObj.functionHandlerName,
        "inputBase64": eventStr.encode('utf-8')
    }
    
    startEngine = startEngineTmpl.substitute(keyWords)
    
    executionLocal = {}
    execLambdaResponse = ''
    try:
        exec(startEngine, globals(), executionLocal)
    except Exception as e:
        print(f"Error executing Lambda function '{lambdaName}': {e}")

    execLambdaResponse = str(executionLocal.get('execLambdaResponse', ''))
    logDict = {
        "execution-date": dateTimeNow.strftime('%Y-%m-%dT%H:%M:%S.%f'),
        "source-trigger": "sqs",
        "lambda-name": lambdaObj.lambda_name,
        "base_path": lambdaObj.localPath
    }

    messageFilePath = os.path.join(lambdaObj.localPath, f"LAMBDA_{dateTimeNow.strftime('%Y-%m-%dT%H''h''%M''m''%S.%f''s''')}.{AWSMock_Global.ITEM_DEFAULT_EXTENSION}")
    write_file_item(messageFilePath, logDict, eventStr, execLambdaResponse);
    
    # execFilePath = localUtil.createTempFile(startEngine, prefix="AWSMock_lambda_engineFunction_", suffix=".py")
    # localUtil.writeJsonToFile(event, "lambdaQueueEvent.json")
    # print(f"Executing Lambda function '{lambdaName}' from '{execFilePath}'")
    # localUtil.execPythonFile(execFilePath)

def execLambda_newProcess(lambdaName, eventStr):
    import tempfile

    (_, tempFilePath) = tempfile.mkstemp(suffix=".RAW")
    with open(tempFilePath, "wb") as file:
        file.write(eventStr.encode("utf-8"))

    dateTimeNow = DateTime.now()
    lambdaObj = getLambda(lambdaName)

    startFilePath = os.path.join(lambdaObj.localPath, ".engine.py")
    moduleName = os.path.basename(lambdaObj.functionHandlerFilePath).replace(".py", "")
    addPath = os.path.join(os.getcwd(), os.path.dirname(lambdaObj.functionHandlerFilePath))

    print("Startirg new Process ...")
    executionLocal = {}
    execLambdaResponse = ''
    try:
        command = lambdaObj.overrideExecutor if lambdaObj.overrideExecutor else "python"
        finalCommand = f"{command} {startFilePath} {addPath} {moduleName} {lambdaObj.functionHandlerName} {lambdaObj.envFile} {tempFilePath}"
        print(f"Executing COMMAND: {finalCommand}")
        os.system(finalCommand)
    except Exception as e:
        print(f"Error executing Lambda function '{lambdaName}': {e}")

    execLambdaResponse = str(executionLocal.get('execLambdaResponse', ''))
    logDict = {
        "execution-date": dateTimeNow.strftime('%Y-%m-%dT%H:%M:%S.%f'),
        "source-trigger": "sqs",
        "lambda-name": lambdaObj.lambda_name,
        "base_path": lambdaObj.localPath
    }

    messageFilePath = os.path.join(lambdaObj.localPath, f"LAMBDA_{dateTimeNow.strftime('%Y-%m-%dT%H''h''%M''m''%S.%f''s''')}.{AWSMock_Global.ITEM_DEFAULT_EXTENSION}")
    write_file_item(messageFilePath, logDict, eventStr, execLambdaResponse);

def process_trigger_sqs(lambdaObj, triggerPropDict):
    queueObj = AWSMock_queue.getQueue(triggerPropDict["triggerSourceName"])
    
    (queueMessage, request_inf) = AWSMock_queue.receive_message_peek(queueObj)
    
    if queueMessage:
        messageId = queueMessage[AWSMock_queue.QueueMessage.P_MESSAGE_ID]
        response_body_dict = {
            "messageId": messageId,
            "md5OfBody": queueMessage[AWSMock_queue.QueueMessage.P_MD5_OF_BODY],
            "body": queueMessage[AWSMock_queue.QueueMessage.P_BODY],
            "attributes": queueMessage["Attributes"],
        }
        execSuccess = False
        try:
            execLambda_newProcess(lambdaObj.lambda_name, json.dumps({"Records": [response_body_dict]}))
            execSuccess = True
        except Exception as ex:
            print("Exception calling Lambda from SQS: ", ex)
        
        if execSuccess and triggerPropDict.get("deleteMessageAfterExec", True):
            AWSMock_queue.delete_message_by_handlerId(queueObj, request_inf["handlerId"])
            # print(f"Lambda '{lambdaObj.lambda_name}' executed successfully for message ID '{messageId}'. Message deleted from queue.")

def monitorMainLoop():
    while True:
        # verificar as filas e invocar as lambdas
        SystemTimer.sleep(5)
        
        # Iterar todos os Trigguers de Todos as Lambdas
        for lambdaObj in lambdaStore:
            for lambdaTrigger in lambdaObj.triggerList:
                if lambdaTrigger.get("triggerType", "") == "sqs":
                    process_trigger_sqs(lambdaObj, lambdaTrigger)

        # Iterar todos os Caller
        for apiCaller in AWSMock_apiCaller.apiCallerStore:
            AWSMock_apiCaller.tryRequest(apiCaller)
           
def startMonitorLambda():
    # criar uma thread para monitorar as filas e invocar as lambdas
    thread1 = threading.Thread(target=monitorMainLoop)
    thread1.start()
    print("Lambda MONITOR started.")

def prepareEngineStart():
    for lambdaObj in lambdaStore:
        
        if len(lambdaObj.triggerList) > 0:
            startFilePath = os.path.join(lambdaObj.localPath, ".engine.py")

            # Def Common variables to tamplating
            awsmock_port = AWSMock_Global.SERVER_PORT
            base_path = os.path.dirname(lambdaObj.functionHandlerFilePath)
            root_module_name = os.path.basename(lambdaObj.functionHandlerFilePath).replace(".py", "")
            lambda_name = lambdaObj.functionHandlerName
            env_file = lambdaObj.envFile
            resource_trigger_identifies = f"http://localhost:{AWSMock_Global.SERVER_PORT}/000000000000/{lambdaObj.triggerList[0]['triggerSourceName']}"

            keyWords = {
                "awsmock_port": awsmock_port,
                "base_path": base_path,
                "root_module_name": root_module_name,
                "lambda_name": lambda_name,
                "env_file": env_file,
                "resource_trigger_identifies": resource_trigger_identifies
            }
            startEngineTmpl = Template(AWSMock_lambda_engineFunction.PYTHON_DEBUG_FUNCTION)
            startEngine = startEngineTmpl.substitute(keyWords)  
            
            # Write the engine file if not exists
            with open(startFilePath, "w", encoding="utf-8") as file:
                file.write(startEngine)

            # Create vscode launch.json
            vscodeLaunchDir = os.path.dirname(lambdaObj.vscodeLaunchFile)
            if not os.path.exists(vscodeLaunchDir):
                os.makedirs(vscodeLaunchDir)
            
            if os.path.exists(lambdaObj.vscodeLaunchFile):
                vscodeLaunchDict = json5.load(open(lambdaObj.vscodeLaunchFile, "r", encoding="utf-8"))
            else:
                vscodeLaunchDict = {}
                
            configName = f"AWSMock {lambdaObj.lambda_name} Python Debug"
            existConfig = next((filter(lambda x: x.get("name", "") == configName, vscodeLaunchDict.get("configurations", []))), None)
            if not existConfig:
                if not vscodeLaunchDict.get("version", ""):
                    vscodeLaunchDict["version"] = "0.2.0"
                if not vscodeLaunchDict.get("configurations", None):
                    vscodeLaunchDict["configurations"] = []

                newConfig = {
                    "name": configName,
                    "type": "debugpy",
                    "request": "launch",
                    "program": startFilePath,
                    "console": "integratedTerminal"
                    # "justMyCode": False
                    # "cwd": lambdaObj.localPath,
                    # "envFile": env_file,
                    # "args": []
                }
                vscodeLaunchDict["configurations"].append(newConfig)

                vscodeLaunch = json.dumps(vscodeLaunchDict, indent=4)
                
                with open(lambdaObj.vscodeLaunchFile, "w", encoding="utf-8") as file:
                    file.write(vscodeLaunch)




