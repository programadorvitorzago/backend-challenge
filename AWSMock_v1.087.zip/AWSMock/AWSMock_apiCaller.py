from datetime import datetime as DateTime, timedelta as TimeDelta
import json
import os
import AWSMock.AWSMock_Global as AWSMock_Global
import localUtil
import re
import http.client
from urllib.parse import urlparse


apiCallerStore = [];

class ApiCallerMock:
    def __init__(self, apiName, local_path, **propDict):
        self.api_name = apiName
        self.localPath = local_path
        self.creationTime = DateTime.now()
        
        self.tryPretty = bool(propDict.get("tryPretty", False))
        self.basePath = propDict.get("basePath", "")

def createApiCaller(apiName, localPath, propDict):
    if not apiName or not localPath:
        raise Exception("ApiName and local path are required")
    
    if not localUtil.verifyIfResourcePathExistOrCresteIt(localPath, 'apiListener'):
        print(f"AVISO: Rescurso 'apiCaller' ignorado: Caminho do recurso deve existir: {localPath}")
        return None
    
    new_apiCaller = ApiCallerMock(apiName, localPath, **propDict)
    
    apiCallerStore.append(new_apiCaller)
    print(f"ApiCaller created: {apiName} at {localPath}")
    return new_apiCaller

def getApiCaller(apiName):  
    for item in apiCallerStore:
        if item.api_name == apiName:
            return item
    raise Exception(f"ApiCaller not found: {apiName}")

def write_file_item(apiCaller:ApiCallerMock, messageFilePath, awsMockMessage):
    with open(messageFilePath, 'w', encoding="utf-8") as file:
        for block in awsMockMessage:
            file.write(f"[{block['name']}] {block.get('shieldComplement', '')}\n")

            if block["type"] == "RAW":
                file.write(block["content"])
                file.write("\n")
            elif block["type"] == "PROP":
                for key, value in block["content"].items():
                    file.write(f"{key}={value}\n")
            
            file.write("\n")

def load_awsmock_item(filePath):
    awsMockMessage = []
    messageBlock = None
    loadingStep = "GET_SECTION_NAME" # or "READING_SECTION"
    pattern = "^\\[(?P<name>[A-Z_]+)\\].*"

    with open(filePath, "r", encoding="utf-8") as fileItem:
        line = fileItem.readline()
        
        while line:
            match = re.match(pattern, line)
            if loadingStep == "GET_SECTION_NAME":
                if match:
                    #Identificado um nome de seção
                    messegeBlock = {}
                    messegeBlock["name"] = match.group("name")

                    #Agora identificao o TIPO
                    if messegeBlock["name"] in ["REQUEST", "HEADERS", "HTML_PARAMS"]:
                        messegeBlock["type"] = "PROP"
                        messegeBlock["content"] = {}
                    else:
                        messegeBlock["type"] = "RAW"
                        messegeBlock["content"] = ""
                    
                    awsMockMessage.append(messegeBlock)
                    loadingStep = "READING_SECTION"
                    line = fileItem.readline()

                else:
                    #Não identificado Inicio de secao considerar como secao generica
                    messegeBlock = {}
                    messegeBlock["name"] = "GENERIC"
                    messegeBlock["type"] = "RAW"
                    messegeBlock["content"] = line

                    awsMockMessage.append(messegeBlock)
                    loadingStep = "READING_SECTION"
                    line = fileItem.readline()
            else:
                #READING SECTION
                # Verificar se não terminou se ler a seção
                if match:
                    # Finalizado a captura de conteúdo
                    # Reprocessa a linha
                    loadingStep = "GET_SECTION_NAME"
                    continue

                if messegeBlock["type"] == "RAW":
                    messegeBlock["content"] += line
                elif messegeBlock["type"] == "PROP":
                    line = line.strip()
                    if line:
                        if "=" in line:
                            propName, propValue = line.split("=", 1)
                            messegeBlock["content"][propName] = propValue
                        else:
                            messegeBlock["content"][line] = ""
                
                line = fileItem.readline()
                
        return awsMockMessage

def findFirstFileForRequest(apiCaller):
    for root, _, files in os.walk(apiCaller.localPath):
        for file in files:
            if not file.startswith((".","_")):
                messageFilePath = os.path.join(apiCaller.localPath, file)
                requestItem = load_awsmock_item(messageFilePath)
                if not next(filter(lambda x: x.get("name") == "RESPONSE", requestItem), None):
                    return (messageFilePath, requestItem)
        break # Only check the top directory
    return (None, None)

def doRequest(apiCaller:ApiCallerMock, awsMockMessage):
    
    block = next(filter(lambda x: x.get("name") == "REQUEST", awsMockMessage), None)
    blockContent = block.get("content", {}) if block else {}
    urlAddress = blockContent.get("url", "http://localhost:8080/")
    httpMethod = blockContent.get("method", "GET").upper()

    parsed_url = urlparse(urlAddress)
    host = parsed_url.netloc
    resource = parsed_url.path
    conn = http.client.HTTPConnection(host)
    
    requestHeaders = {}
    block = next(filter(lambda x: x.get("name") == "HEADERS", awsMockMessage), None)
    blockContent = block.get("content", {}) if block else {}
    for key, value in blockContent.items():
        requestHeaders[key] = value

    block = next(filter(lambda x: x.get("name") == "BODY", awsMockMessage), None)
    body = block.get("content", None) if block else None    

    conn.request(httpMethod, resource, headers=requestHeaders, body=body if body else None)
    response = conn.getresponse()

    block = {
        "name": "RESPONSE",
        "type": "PROP",
        "content": {
            "reponse-time": str(DateTime.now().strftime('%Y-%m-%d %H''h''%M''m''%S.%f''s''')),
            "status-code": str(response.status)
        }
    }
    awsMockMessage.insert(0, block)
    
    responsePayload = response.read()
    block = {
        "name": "RESPONSE_BODY",
        "type": "RAW",
        "content": ""
    }
    if responsePayload:
        shieldComplement = ""
        (bodyContent, typeMatched) = localUtil.tryPrettyOrDefault(responsePayload.decode(encoding="utf-8"))
        if  typeMatched:
            shieldComplement = f"**{typeMatched} Formated**"
        block["content"] = bodyContent
        block["shieldComplement"] = shieldComplement
    awsMockMessage.insert(1, block)
    conn.close()

    return awsMockMessage


def tryRequest(apiCaller:ApiCallerMock):
    (messageFilePath, awsMockMessage) = findFirstFileForRequest(apiCaller)
    if messageFilePath:
        print(f"ApiCaller '{apiCaller.api_name}' executing request from file: {messageFilePath}")
        awsMockMessage = list(filter(lambda x: x.get("name") and x.get("name") != "GENERIC" and not x.get("name").startswith("RESPONSE"), awsMockMessage))
        awsMockMessage = doRequest(apiCaller, awsMockMessage)
        # Remover conteúdo GENERICO
        awsMockMessage = list(filter(lambda x: x.get("name") != "GENERIC", awsMockMessage))
        write_file_item(apiCaller, messageFilePath, awsMockMessage)