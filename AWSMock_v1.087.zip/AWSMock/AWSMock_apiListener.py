from datetime import datetime as DateTime, timedelta as TimeDelta
import json
import json5
import os
from AWSMock import AWSMock_queue
import AWSMock.AWSMock_Global as AWSMock_Global
import localUtil

apiListenerStore = [];

baseResponseManifest = {
    "headers":{ 
        "awsMock": True
    }
}

defaultResponseManifest = {
    "method": "*",
    "path": "/",
    "statusCode": 404,
    "headers":{ 
        "aws-mock-response": "default-resonse"
    },
    "body": {
        "message": "NÃO existe retorno especificado!!"
    }
}

class ApiListenerMock:
    def __init__(self, apiName, local_path, **propDict):
        self.api_name = apiName
        self.localPath = local_path
        self.creationTime = DateTime.now()
        
        self.tryPretty = bool(propDict.get("tryPretty", False))
        self.rootPath = propDict.get("rootPath", "/awsmock")
        if not self.rootPath.startswith("/"):
            self.rootPath = f"/{self.rootPath}"

        # Pode ser:
        # auto = o AWSMock vai varrer pelos arquivos na pasta do recurso
        #   se a pasta do recurso estiver vazia... devolve a resposta padrão
        #   se não ele pega o arquivo válido e:
        #      teste se for é um JSON e tem um propriedade chamado body ele retorna o conteúdo desta propriedade
        #   se não ele retorna o conteúdo inteiro do arquivo
        #   se ele rotnar a resposta padrão
        self.responseMode = propDict.get("responseMode", "auto")
        self.defaultResponse = propDict.get("defaultResponse", defaultResponseManifest)

def createApiListener(apiName, localPath, propDict):
    if not apiName or not localPath:
        raise Exception("ApiName and local path are required")
    
    if not localUtil.verifyIfResourcePathExistOrCresteIt(localPath, 'apiListener'):
        print(f"AVISO: Rescurso 'apiListener' ignorado: Caminho do recurso deve existir: {localPath}")
        return None
    
    new_apiListener = ApiListenerMock(apiName, localPath, **propDict)
    
    apiListenerStore.append(new_apiListener)
    print(f"ApiListener created: {apiName} at {localPath}")
    return new_apiListener

def getApiListener(apiName):
    for item in apiListenerStore:
        if item.api_name == apiName:
            return item
    raise Exception(f"ApiListener not found: {apiName}")

def getApiByRequestPath(requestPath):
    for api in apiListenerStore:
        if requestPath.startswith(api.rootPath):
            return api
    return None

def write_file_item(apiListener:ApiListenerMock, messageFilePath, logDict, apiRequest, apiResponse):
    os.makedirs(os.path.dirname(messageFilePath), exist_ok=True)
    with open(messageFilePath, 'x', encoding="utf-8") as file:
        file.write("[API_LISTENER_RECEIVED_REQUEST]\n")
        for mProperty in logDict:
            propValue = logDict.get(mProperty, "")
            if propValue:
                file.write(f"{mProperty}={logDict[mProperty]}\n")
        file.write("\n")

        shieldComplement = ""
        if(apiListener.tryPretty): 
            (bodyContent, typeMatched) = localUtil.tryPrettyOrDefault(apiRequest)
            if  typeMatched:
                shieldComplement = f"**{typeMatched} Formated**"
        else:
            bodyContent = apiRequest

        file.write(f"[REQUEST_BODY] {shieldComplement}\n")
        file.write(bodyContent)
        file.write("\n\n")
        
        file.write("[RESPONSE]\n")
        file.write(apiResponse)

def tryGetResponse(apiListener:ApiListenerMock, request, responseFile):
    with open(responseFile, 'r', encoding="utf-8") as file:
        loadRawString = file.read()

    # Tentar carregar como JSON
    try:
        jsonResult = json5.loads(loadRawString)

        ## Se for modo auto, verificar se tem a propriedade body
        ##  se sim ele considera com o manifesto de resposta
        if apiListener.responseMode == "auto" and "body" in jsonResult:
            return jsonResult
        loadRawString = json.dumps(jsonResult)

    except ValueError:
        pass

    # Devoler como texto puro
    returnManifest = dict(baseResponseManifest)
    returnManifest["statusCode"] = 200
    returnManifest["body"] = loadRawString
    return returnManifest

def findManifestResponse(apiListener:ApiListenerMock, request):
    for _, _, files in os.walk(apiListener.localPath):
        for file in files:
            if not file.startswith((".","_")):
                responseFile = os.path.join(apiListener.localPath, file)
                responseManifest = tryGetResponse(apiListener, request, responseFile)
                if responseManifest:
                    return responseManifest
        break # Only check the top directory
    return None

def getContentBytes(content):
    if isinstance(content, bytes):
        return content
    elif isinstance(content, str):
        return content.encode("utf-8")
    elif isinstance(content, dict) or isinstance(content, list):
        return json.dumps(content).encode("utf-8")
    else:
        return str(content).encode("utf-8")
    
def log_and_get_response(apiObj, request, response, bodyContent: bytes):
    dateTimeReceived = DateTime.now()
    
    logDict = {}
    logDict["API_NAME"] = apiObj.api_name
    logDict["REQUEST_TIME"] = dateTimeReceived.strftime("%Y-%m-%d %H:%M:%S")
    logDict["REQUEST_PATH"] = request.url.path
    logDict["REQUEST_METHOD"] = request.method
    logDict["REQUEST_PARAMS"] = json.dumps(dict(request.query_params))
    logDict["REQUEST_HEADERS"] = json.dumps(dict(request.headers))
    
    try:
        requestData = bodyContent.decode("utf-8")
    except Exception as e:
        logDict["REQUEST_DATA_ERROR"] = str(e)
        requestData = ""
       
    default_response_manifest = findManifestResponse(apiObj, request)
    if not default_response_manifest:
        default_response_manifest = apiObj.defaultResponse
    
    messageFilePath = os.path.join(apiObj.localPath, "log", f"API_{dateTimeReceived.strftime('%Y-%m-%dT%H''h''%M''m''%S.%f''s''')}.{AWSMock_Global.ITEM_DEFAULT_EXTENSION}")
    write_file_item(apiObj, messageFilePath, logDict, requestData, json.dumps(default_response_manifest))

    AWSMock_Global.preencher_base_response_json(response, default_response_manifest.get("statusCode", 200))
    response.headers["Connection"] = "close"
    for headerKey, headerValue in default_response_manifest.get("headers", {}).items():
        response.headers[headerKey] = str(headerValue)
    
    bodyBytes = getContentBytes(default_response_manifest.get("body", ""))
    response.headers["Content-length"] = str(len(bodyBytes))
    response.body = bodyBytes

    return response
    
