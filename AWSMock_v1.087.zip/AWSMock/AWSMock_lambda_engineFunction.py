OFFLINE_START_FUNCTION = """
import sys
import os
import json

sys.path.append(os.path.join(os.getcwd()), "${base_path}"))
from ${lambda_location} import ${lambda_name}

# Exemplo de evento simulando uma invocação do Lambda
eventInput = json.loads(${inputBase64}.decode("utf-8"))

# Contexto simulado (pode ser um objeto vazio ou um mock)
context = type('Context', (object,), {
    "function_name": "test_lambda_function",
    "get_remaining_time_in_millis": lambda self: 300000
})()

# Chamar a função Lambda com o evento e contexto simulados
execLambdaResponse = ${lambda_name}(eventInput, context)
"""

PYTHON_DEBUG_FUNCTION = """
import sys
import os
import json
import sys
from dotenv import load_dotenv
import importlib
import http.client

# Common Variable
awsMockPort = ${awsmock_port}
addPath = os.path.join(os.getcwd(), r"${base_path}")
moduleName = "${root_module_name}"
functionName = "${lambda_name}"
envFilePath = r"${env_file}"
resourceTriggerIdentifies = "${resource_trigger_identifies}"

# INITS
sys.path.append(addPath)
load_dotenv(envFilePath)

mainModule = importlib.import_module(moduleName)

def ExecLambdaFunction(eventInput, contextMock):
    # Contexto simulado (pode ser um objeto vazio ou um mock)
    context = type('Context', (object,), {
        "function_name": "test_lambda_function",
        "get_remaining_time_in_millis": lambda self: 300000
    })()

    my_function = getattr(mainModule, functionName)

    execLambdaResponse = my_function(eventInput, context)
    print("\\nLAMBDA RESULT")
    print(execLambdaResponse)

    if isinstance(execLambdaResponse, dict):
        return execLambdaResponse and execLambdaResponse.get("statusCode") and execLambdaResponse.get("statusCode") >= 200 and execLambdaResponse.get("statusCode") < 300
    return execLambdaResponse != None

def firstLetterLowercase(keyword):
    if len(keyword) > 1:
        return keyword[0:1].lower() + keyword[1:]
    return keyword.lower()

def createSqsEventList(messageSqsList):
    eventList = []
    for messageSqs in messageSqsList:
        newEvent = {}
        for k in messageSqs:
            newEvent[firstLetterLowercase(k)] = messageSqs[k]
        eventList.append(newEvent)
    return eventList

def removeMessageFromQueue(receiptHandle):
    conn = http.client.HTTPConnection("127.0.0.1", port=awsMockPort)
    sqsHeaders = {"X-amz-target": "AmazonSQS.DeleteMessage"}
    sqsBody = {"QueueUrl": resourceTriggerIdentifies, "ReceiptHandle": receiptHandle}
    conn.request("POST", "/", headers=sqsHeaders, body=json.dumps(sqsBody))
    conn.getresponse()
    conn.close()
    
while True:
    conn = http.client.HTTPConnection("127.0.0.1", port=awsMockPort)
    sqsHeaders = {"X-amz-target": "AmazonSQS.ReceiveMessage"}
    sqsBody = {"QueueUrl": resourceTriggerIdentifies}

    conn.request("POST", "/", headers=sqsHeaders, body=json.dumps(sqsBody))
    response = conn.getresponse()

    statusCode = response.status
    if statusCode >= 200 and statusCode < 300:
        responsePayload = response.read().decode(encoding="utf-8")
        responseDict = json.loads(responsePayload)
        if responseDict.get("Messages") and len(responseDict.get("Messages")) > 0:
            handlerId = responseDict["Messages"][0]["ReceiptHandle"]
            if ExecLambdaFunction({"Records": createSqsEventList(responseDict["Messages"])}, ()):
                removeMessageFromQueue(handlerId)
    else:
        print(f"Connection Failure: {statusCode}")

    conn.close()

"""