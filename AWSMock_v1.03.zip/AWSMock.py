
import uuid
from datetime import datetime as DateTime

def preencher_base_response(response, status_code = 200):
    response.status_code = status_code
    response.headers["X-amz-id-2"] = "s9lzHYrFp76ZVxRcpX9+5cjAnEH2ROuNkd2BHfIa6UkFVdtjf5mKR3/eTPFvsiP/XV/VLi31234="
    response.headers["X-amz-request-id"] = str(uuid.uuid4())
    response.headers["X-awsmock"] = "true"
    return response

def preencher_base_response_json(response, status_code = 200):
    preencher_base_response(response, status_code)
    response.headers["Content-Type"] = "application/x-amz-json-1.0"
    return response
