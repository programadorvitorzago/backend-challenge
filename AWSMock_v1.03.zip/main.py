from fastapi import FastAPI, Request, Response
import uvicorn
import AWSMock
import AWSMock_bucket
import AWSMock_queue
import json

app = FastAPI()

@app.get("/{anyPath:path}")
@app.post("/{anyPath:path}")
@app.put("/{anyPath:path}")
@app.head("/{anyPath:path}")
@app.delete("/{anyPath:path}")
@app.api_route("/{anyPath:path}")
async def main_api_entrace(request: Request, response: Response):
    urn = request.url.path
    method = request.method

    print(f"Received request {method} from url: {urn}")
    
    urnPartList = urn.split("/")
    filteredUrlPartList = list(filter(lambda x: x > "", urnPartList))

    hederUserAgent = request.headers.get("User-Agent")

    recurso = filteredUrlPartList[0] if len(filteredUrlPartList) > 0 else None
    recursoParametro = "/".join(filteredUrlPartList[1:]) if len(filteredUrlPartList) > 1 else None
    
    if method == "GET":

        if len(filteredUrlPartList) < 1:
            response.status_code = 400
            response.body = b"Bad Request"
            return response
        
        if recursoParametro is None:
            # Lista funcao lista objetos do bucket
            prefix = request.query_params.get("prefix")
            return AWSMock_bucket.list_objects_response(recurso, prefix, response)

        bucketName = recurso
        itemKey = recursoParametro
        
        bucketObject = AWSMock_bucket.getObjectEspec(bucketName, itemKey)
        if not bucketObject:
            return AWSMock_bucket.file_does_not_exist_response(bucketName, itemKey, response);
        
        bytesFileContent = AWSMock_bucket.downloadFile(bucketName, itemKey)
        AWSMock.preencher_base_response(response)
        response.body = bytesFileContent
        response.headers["Accept-ranges"] = "bytes"
        response.headers["Connection"] = "close"
        response.headers["Content-Length"] = str(bucketObject.bytesLen)
        response.headers["Content-Type"] = "application/octet-stream"
        response.headers["Etag"] = "e7dc5f9f5a8ca0a8fa88163df45dbbd8" # TODO

    elif method == "PUT":
        bucketName = recurso
        itemKey = recursoParametro
    
        print(f"UPLOAD")
        print(f"bucketName: {bucketName}")
        print(f"itemKey: {itemKey}")
        
        AWSMock_bucket.uploadFile(bucketName, itemKey, str(await request.body(), encoding='utf-8'))
    
        AWSMock.preencher_base_response(response)
        response.headers["Connection"] = "close"
        response.headers["Last-modified"] = "Mon, 18 Aug 2025 01:59:14 GMT"

    elif method == "HEAD":
        bucketName = recurso
        itemKey = recursoParametro
        
        print(f"HEAD")
        print(f"bucketName: {bucketName}")
        print(f"itemKey: {itemKey}")
        
        if itemKey is not None:
            bucketObject = AWSMock_bucket.getObjectEspec(bucketName, itemKey)
            if not bucketObject:
                return AWSMock_bucket.file_does_not_exist_response(bucketName, itemKey, response);
        else:
            AWSMock_bucket.getBucket(bucketName) # Apenas para validar se o bucket existe
            
        AWSMock.preencher_base_response(response)
        response.headers["Connection"] = "close"
        if bucketObject:
            response.headers["Content-Length"] = str(bucketObject.bytesLen)
        response.headers["Content-Type"] = "application/octet-stream"
        response.headers["Last-modified"] = "Mon, 18 Aug 2025 01:59:14 GMT" # TODO
        response.headers["server"] = "AwsMockServer/1.0"

    elif method == "POST":

        jsonBody = await request.json()    
        
        action = request.headers.get("X-amz-target")
       
        if action == "AmazonSQS.SendMessage":
            queueUrl = jsonBody.get("QueueUrl")
            queueName = queueUrl.split("/")[-1]
            messageBody = jsonBody.get("MessageBody")
            return AWSMock_queue.send_message_response(queueName, messageBody, response)
        
        elif action == "AmazonSQS.ReceiveMessage":
            queueUrl = jsonBody.get("QueueUrl")
            queueName = queueUrl.split("/")[-1]
            return AWSMock_queue.receive_message_response(queueName, response)
        
        elif action == "AmazonSQS.DeleteMessage":
            queueUrl = jsonBody.get("QueueUrl")
            queueName = queueUrl.split("/")[-1]
            receiptHandle = jsonBody.get("ReceiptHandle")
            return AWSMock_queue.delete_message_response(queueName, receiptHandle, response)
        
        elif action == "AmazonSQS.PurgeQueue":
            queueUrl = jsonBody.get("QueueUrl")
            queueName = queueUrl.split("/")[-1]
            return AWSMock_queue.purge_queue_response(queueName, response)
            
        else:
            response.status_code = 400
            response.body = b"Bad Request"
    
    elif method == "DELETE":
        bucketName = recurso
        itemKey = recursoParametro
        
        print(f"DELETE")
        print(f"bucketName: {bucketName}")
        print(f"itemKey: {itemKey}")
        
        return AWSMock_bucket.delete_object_response(bucketName, itemKey, response)

    else:
        response.status_code = 405
        response.body = b"Method Not Implemented"
    
    return response

# Starting resources
resources = json.loads(open('awsmock.json').read())
if resources.get("resourceList"):
    for resouce in resources.get("resourceList"):
        match resouce.get("resourceType"):
            case "queue":
                AWSMock_queue.createQueue(resouce.get('resourceName'), resouce.get('localPath'))
            case "bucket":
                AWSMock_bucket.createBucket(resouce.get('resourceName'), resouce.get('localPath'))

if __name__ == "__main__":
    uvicorn.run("main:app", port=8080, log_level="info", reload=True)

