from helper import DateTimeHelper
from repository.DataBaseEntityCollection import ContaRaw, LancamentoRaw, PosicaoContaRaw
from repository import DataBaseRepository
from service import TipoContaService, ContaService
import json

lancamentoRepository = DataBaseRepository.LancamentoRepository()
contaRepository = DataBaseRepository.ContaRepository()
posicaoContaRepository = DataBaseRepository.PosicaoContaRepository()

def loadJsonOrDefault(jsonStr:str, defaultValue=None):
    if jsonStr is None or jsonStr == "":
        return defaultValue
    try:
        return json.loads(jsonStr)
    except:
        return "failed_to_load_json"

def mapPosicaoContaRawToDto(posicaoContaRaw:PosicaoContaRaw, tipo_evento="saldo", descricao:str="SALDO"):
    return {
        "tipo_evento": tipo_evento,
        "data_evento": posicaoContaRaw.data_evento,
        "descricao_curta": descricao,
        "descricao_completa": descricao,
        "valor": posicaoContaRaw.valor,
        "codigo_moeda_transacao": posicaoContaRaw.codigo_moeda_transacao
    }

def mapLancamentoRawToDto(lancamentoRaw:LancamentoRaw):
    return {
        "tipo_evento": "lancamento",
        "data_evento": lancamentoRaw.data_evento,
        "descricao_curta": lancamentoRaw.descricao_curta,
        "descricao_completa": lancamentoRaw.descricao_completa,
        "dica": "",
        "valor": lancamentoRaw.valor,
        "codigo_moeda_transacao": lancamentoRaw.codigo_moeda_transacao,
        "contraparte_transacao": loadJsonOrDefault(lancamentoRaw.contraparte_transacao),
        "acao": "",
        "impacto": "",
        "familia": "",
        "id_unico_evento": lancamentoRaw.uuid_evento,
        "codigo_motivo_lancamento": lancamentoRaw.codigo_motivo_lancamento,
        "legenda": "",
        "descricao_legenda": "",
        "indicador_tipo_operacao": lancamentoRaw.indicador_tipo_operacao,
        "data_hora_processamento_lancamento": "2025-12-18T07:58:57.046-03:00",
        "estorno_lancamento": False,
        "datelhes": {},
        "possui_detalhes": True,
        "descricao_complementar_cliente": "",
        "origem_transacao": {},
        "indicador_lancamento_final_oito": bool(lancamentoRaw.indicador_lancamento_final_oito),
        "indicador_lancamento_visivel_cliente": bool(lancamentoRaw.indicador_lancamento_visivel_cliente),
        "indicador_anotacao": bool(lancamentoRaw.indicador_anotacao)
    }

def getDataIniAnterior(dateIni):
    return DateTimeHelper.addDays(dateIni, -1)

def getLancamentoResult(conta_id_raw_from_api:str, tipo_conta_api:str, dataIniStr:str, dataFimStr:str):
    """Esta função retorna o resultado do extrato de lançamentos para uma conta específica 
    dentro de um intervalo de datas. A exibição padrão é intercalar cada data com as posições da conta.
    Se não encontrar uma posição de conta para a data especifica. Definir 0.0 como valor.
    """

    uuid_conta = ContaService.getUuidContaByContaIdApi(conta_id_raw_from_api)
    tipo_conta = TipoContaService.getMnoByTipoContaApi(tipo_conta_api)
    dateIni = DateTimeHelper.parseNullableDate(dataIniStr)
    dataIniAnterior = getDataIniAnterior(dateIni)
    dataIniAnteriorStr = DateTimeHelper.toIsoDateString(dataIniAnterior)

    posicaoDataAnterior:PosicaoContaRaw = posicaoContaRepository.get(data_evento=dataIniAnterior, uuid_conta=uuid_conta, tipo_conta="CONS", tipo_posicao="F")
    if posicaoDataAnterior is None:
        # criar uma posição de conta fictícia com valor 0.0
        posicaoDataAnterior = PosicaoContaRaw(
            data_evento = dataIniAnteriorStr,
            uuid_conta = uuid_conta,
            tipo_conta = "CC",
            tipo_posicao = "F",
            valor = 0.0,
            codigo_moeda_transacao = "BRL",
            data_hora_atualizacao = DateTimeHelper.getNowIsoString(),
        )

    lancamentoRawList = lancamentoRepository.filter(uuid_conta=uuid_conta, dataIni=dataIniStr, dataFim=dataFimStr)
    contaRaw:ContaRaw = contaRepository.get(uuid_conta=uuid_conta, tipo_conta=tipo_conta)

    ### Preparando os eventos com as posições intercaladas entre datas
    eventoList = []
    # adicionar a posição da data anterior
    saldoAnteriorEvento = mapPosicaoContaRawToDto(posicaoDataAnterior, tipo_evento="saldo_disponivel", descricao="SALDO ANTERIOR")
    eventoList.append(saldoAnteriorEvento)
    eventoList.extend([mapLancamentoRawToDto(lancamentoRaw) for lancamentoRaw in lancamentoRawList])

    response_body_dict = {
        "data": [
            {
                "eventos": eventoList,
                "pagination": {},
                "conta": {
                    "numero_unico_conta": contaRaw.uuid_conta,
                    "numero_agencia": f"{contaRaw.agencia:04d}",
                    "numero_conta": f"{contaRaw.conta:07d}",
                    "numero_dv": f"{contaRaw.dac}",
                    "codigo_sufixo_conta": contaRaw.codigo_sufixo_conta,
                    "tipo_conta": TipoContaService.getTipoContaApiByMno(contaRaw.tipo_conta),
                },
                "agregacoes": {}
            }
        ]
    }

    return response_body_dict
    
    

    
    