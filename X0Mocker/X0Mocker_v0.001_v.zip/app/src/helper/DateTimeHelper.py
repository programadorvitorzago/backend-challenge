from datetime import datetime as DateTime, timedelta as TimeDelta

def parseNullableDate(input):
    if not input:
        return None
    return DateTime.fromisoformat(input).date()

def parseNullableDateTime(input):
    if not input:
        return None
    return DateTime.fromisoformat(input)

def addDays(dateType, days):
    if not dateType:
        return None
    return dateType + TimeDelta(days=days)

def getNowIsoString():
    return DateTime.now().isoformat()

def toIsoDateString(dateType: DateTime.date):
    # return date in ISO format (YYYY-MM-DD)
    if not dateType:
        return None
    return dateType.strftime("%Y-%m-%d")