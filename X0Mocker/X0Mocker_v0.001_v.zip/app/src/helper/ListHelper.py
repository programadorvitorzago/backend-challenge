from email.policy import default


def firstOrDefault(lst, function=None, default=None):
    """Returns the first element of the list or a default value if the list is empty."""
    if lst:
        if function:
            for item in lst:
                if function(item):
                    return item
            return default
        return lst[0]
    return default