from helper import ListHelper
from repository import DataBaseMain
from repository.DataBaseEntityCollection import *
import sqlite3

_connection = None

def getConnection():
    global _connection
    if _connection is None:
        _connection = DataBaseMain.getConnection()
    return _connection

def genericGetAll(tableName:str, entityClass):
    query = f"SELECT * FROM {tableName}"
    return genericQueryExecute(query, entityClass, ())

def genericSelect(tableName:str, entityClass, **params):
    where_clause = " AND ".join([f"{key} = ?" for key in params.keys()])
    query = f"SELECT * FROM {tableName} WHERE {where_clause}"
    return genericQueryExecute(query, entityClass, tuple(params.values()))

def genericInsert(tableName:str, entity):
    entityDict = asdict(entity)
    columns = ', '.join(entityDict.keys())
    placeholders = ', '.join(['?'] * len(entityDict))
    query = f"INSERT INTO {tableName} ({columns}) VALUES ({placeholders})"
    
    conn = getConnection()
    cursor = conn.execute(query, tuple(entityDict.values()))
    conn.commit()
    return cursor.lastrowid

def geneticUpdate(tableName:str, entity, keyArray):
    entityDict = asdict(entity)
    entityDictKey = {}
    for key in keyArray:
        entityDictKey[key] = entityDict[key]
        del entityDict[key]

    set_clause = ', '.join([f"{key} = ?" for key in entityDict.keys()])
    where_clause = ' AND '.join([f"{key} = ?" for key in entityDictKey.keys()])
    query = f"UPDATE {tableName} SET {set_clause} WHERE {where_clause}"
    
    conn = getConnection()
    cursor = conn.execute(query, tuple(entityDict.values()) + tuple(entityDictKey.values()))
    conn.commit()
    return cursor.rowcount

def genericQueryExecute(query:str, entityClass, paramValueTuple):
    entityList = []

    conn = getConnection()
    conn.row_factory = sqlite3.Row
    cursor = conn.execute(query, paramValueTuple)
    rowList = cursor.fetchall()
    for row in rowList:
        entityList.append(entityClass(**dict(row)))

    return entityList        

class LancamentoRepository:

    tableName = "LancamentoTbl"
    primaryKeyArray = ["data_evento", "uuid_evento"]

    def __init__(self):
        pass

    def get(self, data_evento:str, uuid_evento:str):
       return ListHelper.firstOrDefault(self.select(data_evento=data_evento, uuid_evento=uuid_evento))

    def select(self, **params):
        return genericSelect(self.tableName, LancamentoRaw, **params)

    def getAll(self):
        return genericGetAll(self.tableName, LancamentoRaw)
    
    def insert(self, lancamentoRaw:LancamentoRaw):
        return genericInsert(self.tableName, lancamentoRaw)
   
    def filter(self, uuid_conta:str, dataIni:str, dataFim:str):
        query = f"SELECT * FROM {self.tableName} WHERE uuid_conta = ? AND data_evento BETWEEN ? AND ? ORDER BY data_evento ASC"
        return genericQueryExecute(query, LancamentoRaw, (uuid_conta, dataIni, dataFim))


class ContaRepository:

    tableName = "ContaTbl"
    primaryKeyArray = ["uuid_conta", "tipo_conta"]

    def __init__(self):
        pass

    def get(self, uuid_conta:str, tipo_conta:str):
       return ListHelper.firstOrDefault(self.select(uuid_conta=uuid_conta, tipo_conta=tipo_conta))

    def select(self, **params):
        return genericSelect(self.tableName, ContaRaw, **params)
    
    def insert(self, contaRaw:ContaRaw):
        return genericInsert(self.tableName, contaRaw)
    
    def insertOrUpdate(self, contaRaw:ContaRaw):
        entityTest = self.get(uuid_conta=contaRaw.uuid_conta, tipo_conta=contaRaw.tipo_conta)
        if not entityTest:
            return genericInsert(self.tableName, contaRaw)
        else:
            return geneticUpdate(self.tableName, contaRaw, self.primaryKeyArray)

    def getAll(self):
        return genericGetAll(self.tableName, ContaRaw)


class PosicaoContaRepository:

    tableName = "PosicaoContaTbl"
    primaryKeyArray = ["data_evento", "uuid_conta", "tipo_conta", "tipo_posicao"]

    def __init__(self):
        pass

    def get(self, data_evento:str, uuid_conta:str, tipo_conta:str, tipo_posicao:str):
       return ListHelper.firstOrDefault(self.select(data_evento=data_evento, uuid_conta=uuid_conta, tipo_conta=tipo_conta, tipo_posicao=tipo_posicao))

    def select(self, **params):
        return genericSelect(self.tableName, PosicaoContaRaw, **params)
    
    def insert(self, posicaoContaRaw:PosicaoContaRaw):
        return genericInsert(self.tableName, posicaoContaRaw)
    
    def insertOrUpdate(self, posicaoContaRaw:PosicaoContaRaw):
        entityTest = self.get(data_evento=posicaoContaRaw.data_evento, uuid_conta=posicaoContaRaw.uuid_conta, tipo_conta=posicaoContaRaw.tipo_conta, tipo_posicao=posicaoContaRaw.tipo_posicao)
        if not entityTest:
            return genericInsert(self.tableName, posicaoContaRaw)
        else:
            return geneticUpdate(self.tableName, posicaoContaRaw, self.primaryKeyArray)

    def getAll(self):
        return genericGetAll(self.tableName, PosicaoContaRaw)    