import os
from flask import json
import uvicorn
from repository import DataBaseMain

debugMode = bool(os.getenv("X0MOCK_DEBUGMODE", "false").lower())

# Preparando a base de dados
dataBasePath = os.getenv("X0MOCK_DATABASE_PATH", "X0MockerDataBase.db")
DataBaseMain.createDataBaseIfNotExists(dataBasePath)

# if __name__ == "__main__":
#     uvicorn.run("X0Mocker:app", port=8085, log_level="info", reload=debugMode)

# RAPID Debug
import X0Mocker
from service import ExtratosLancamentoService
from helper import DateTimeHelper
from service import DataPumpService

# print(json.dumps(ExtratosLancamentoService.getLancamentoResult("712da26b-b7f6-343b-a19f-5e258801e603"
#                                                                , "conta_corrente"
#                                                                , "2025-12-18"
#                                                                , "2025-12-18"), indent=3))

# ## DATA PUMP
# fileName = "result01.json"
# DataPumpService.importFromX0File(fileName)

print(json.dumps(ExtratosLancamentoService.getLancamentoResult("712da26b-b7f6-343b-a19f-5e258801e603"
                                                               , "conta_corrente"
                                                               , "2025-12-18"
                                                               , "2025-12-18"), indent=3))




# dateStr = "2026-01-07"
# date = DateTimeHelper.parseNullableDateTime(dateStr)
# print(date)
# # data de ontem
# dataOntem = DateTimeHelper.addDays(date, -.5)
# print(dataOntem)





    