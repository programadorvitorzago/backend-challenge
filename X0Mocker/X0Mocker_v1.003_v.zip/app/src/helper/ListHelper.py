from email.policy import default

def firstItemOrDefault(lst, default=None):
    """Returns the first element of the list or a default value if the list is empty."""
    if lst:
        return lst[0]
    return default

def findFirstOrDefault(lst, function=None, default=None):
    """Returns the first element of the list testing with a lambda or a default value if the list is empty."""
    if lst:
        if function:
            for item in lst:
                if function(item):
                    return item
            return default        
        return lst[0]
    return default

def findAll(listIterator, customLambda):
    return list(filter(customLambda, listIterator))