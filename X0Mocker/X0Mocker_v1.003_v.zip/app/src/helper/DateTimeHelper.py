from datetime import datetime as DateTime, timedelta as TimeDelta

def parseNullableDate(input):
    if not input:
        return None
    return DateTime.fromisoformat(input)

def parseNullableDateTime(input):
    if not input:
        return None
    return DateTime.fromisoformat(input)

def addDays(dateType, days):
    if not dateType:
        return None
    return dateType + TimeDelta(days=days)

def getNowIsoString():
    return DateTime.now().isoformat()

def getToday():
    return DateTime.today()

def getTodayIsoString():
    return toIsoDateString(DateTime.now())

def toIsoDateString(dateType):
    # return date in ISO format (YYYY-MM-DD)
    if not dateType:
        return None
    return dateType.strftime("%Y-%m-%d")

def getDiaUtilAnterior(dateType):
    """Retorna o último dia útil do mês da data fornecida"""
    if not dateType:
        return None
    dateType = addDays(dateType, -1)
    while dateType.weekday() >= 5:
        dateType = addDays(dateType, -1)
    return dateType