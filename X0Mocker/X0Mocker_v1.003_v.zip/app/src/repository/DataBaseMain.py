import sqlite3
from repository import DataBaseSpec

DATABASE_PATH:str = "X0MockerDataBase.db"

def createDataBaseIfNotExists(dataBasePath: str):
    import os
    
    global DATABASE_PATH
    DATABASE_PATH = dataBasePath

    if not os.path.exists(dataBasePath):
        with sqlite3.connect(dataBasePath) as conn:
            # # Create a cursor object to execute SQL commands
            cursor = conn.cursor()
            
            cursor.executescript(DataBaseSpec.DATA_BASE_SPEC)
            conn.commit() 

def getConnection():
    return sqlite3.connect(DATABASE_PATH)

                
        