from dataclasses import dataclass, asdict
from typing import Optional

@dataclass
class LancamentoRaw:
    """Representação dos dados de um Lançamento."""
    data_evento: str
    uuid_evento: str
    
    uuid_conta: str
    tipo_conta: str

    tipo_evento: str
    descricao_curta: str
    descricao_completa: str
    valor: float
    indicador_tipo_operacao: str
    codigo_moeda_transacao: str

    codigo_motivo_lancamento: str

    data_hora_real_cadastro_lancamento: str
    data_hora_processamento_lancamento: str

    propriedade_root_dict: str
    contraparte_transacao: str
    origem_transacao: str
    detalhe: str

    indicador_lancamento_final_oito: int
    indicador_lancamento_visivel_cliente: int
    indicador_anotacao: int

@dataclass
class ContaRaw:
    uuid_conta: str
    tipo_conta: str

    codigo_sufixo_conta: str
    
    agencia: int
    conta: int
    dac: int

    uuid_cliente: str
    data_hora_cadastro: str
    detalhe: Optional[str] = None  

@dataclass
class PosicaoContaRaw:
    data_evento: str
    
    uuid_conta: str
    tipo_conta: str
    
    tipo_posicao: str  # Sugestão: Usar "F" para Final ou "P" para Parcial

    valor: float
    codigo_moeda_transacao: str
    data_hora_atualizacao: str
    detalhe: Optional[str] = None