DATA_BASE_SPEC = """
CREATE TABLE IF NOT EXISTS LancamentoTbl (
    data_evento TEXT,
    uuid_evento TEXT,

    uuid_conta TEXT NOT NULL,
    tipo_conta TEXT NOT NULL,

    tipo_evento TEXT NOT NULL, 
    descricao_curta TEXT,
    descricao_completa TEXT,
    valor FLOAT NOT NULL,
    indicador_tipo_operacao TEXT NOT NULL,
    codigo_moeda_transacao TEXT,

    codigo_motivo_lancamento TEXT,

    data_hora_real_cadastro_lancamento TEXT,
    data_hora_processamento_lancamento TEXT,

    propriedade_root_dict TEXT,
    contraparte_transacao TEXT,
    origem_transacao TEXT,
    detalhe TEXT,
    
    indicador_lancamento_final_oito INTEGER,
    indicador_lancamento_visivel_cliente INTEGER,
    indicador_anotacao INTEGER,

    PRIMARY KEY (data_evento, uuid_evento)
);

CREATE TABLE ContaTbl (
    uuid_conta TEXT NOT NULL,
    tipo_conta TEXT NOT NULL,

    codigo_sufixo_conta TEXT,
    agencia INTEGER NOT NULL,
    conta INTEGER NOT NULL,
    dac INTEGER NOT NULL,
    
    uuid_cliente TEXT,
    
    data_hora_cadastro TEXT NOT NULL,
    detalhe TEXT,

    PRIMARY KEY (uuid_conta, tipo_conta)
);

CREATE TABLE PosicaoContaTbl (
    data_evento TEXT NOT NULL,
    uuid_conta TEXT NOT NULL,
    tipo_conta TEXT NOT NULL,
    tipo_posicao TEXT NOT NULL CHECK(tipo_posicao IN ('F', 'P')), 

    valor REAL NOT NULL DEFAULT 0.0,
    codigo_moeda_transacao TEXT NOT NULL DEFAULT 'BRL',
    data_hora_atualizacao TEXT NOT NULL,
    detalhe TEXT,

    PRIMARY KEY (data_evento, uuid_conta, tipo_conta, tipo_posicao)
);

CREATE TABLE SaldoAtualTbl (
    
    uuid_conta TEXT NOT NULL,
    tipo_conta TEXT NOT NULL,
    tipo_saldo_atual TEXT NOT NULL,

    valor REAL NOT NULL DEFAULT 0.0,
    codigo_moeda_transacao TEXT NOT NULL DEFAULT 'BRL',
    data_hora_atualizacao TEXT NOT NULL,
    detalhe TEXT,

    PRIMARY KEY (uuid_conta, tipo_conta, tipo_saldo_atual)
);
"""