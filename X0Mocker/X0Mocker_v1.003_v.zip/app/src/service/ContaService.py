from repository import DataBaseRepository
from helper import ListHelper

contaRepository = DataBaseRepository.ContaRepository()

def getUuidContaByContaIdApi(conta_id_api:str) -> str:
    lenContaIdApi = len(conta_id_api)
    if lenContaIdApi == 12:
        # Conta ID AAAA CCCCCCC D de 12 caracteres (sem hífen)
        codAgencia = int(conta_id_api[0:4])
        codConta = int(conta_id_api[4:11])
        dvConta = int(conta_id_api[11:12])

        contaRawObj = ListHelper.findFirstOrDefault(contaRepository.select(
            agencia=codAgencia,
            conta=codConta,
            dac=dvConta
        ))

        if contaRawObj is None:
            raise ValueError(f"Conta com ID API '{conta_id_api}' não encontrada.")
        
        return contaRawObj.uuid_conta

    elif lenContaIdApi == 36:
        # Provavelmente já é um UUID
        return conta_id_api
    raise ValueError(f"Conta ID API '{conta_id_api}' inválido.")