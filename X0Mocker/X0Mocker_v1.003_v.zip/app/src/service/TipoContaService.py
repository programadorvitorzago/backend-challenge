from helper import ListHelper

# Tipo de conta:
# CC =  Conta Corrente
TIPO_CONTA_DICT = [
    {
        "mno": "CC",
        "nome": "Conta Corrente",
        "tipo_conta_api": "conta_corrente",
        "sufixo_tipo_conta": "100000",
        "saldo_tipo_evento": ["saldo_conta"]
    },
    {
        "mno": "AA",
        "nome": "Conta de Aplicação AplicAut",
        "tipo_conta_api": "aplic_aut",
        "sufixo_tipo_conta": "100202",
        "saldo_tipo_evento": ["saldo_aplic_aut"]
    },
    {
        "mno": "CONS",
        "nome": "Conta Fictícia de Consolidação Final", #Usado em posição de Saldo
        "tipo_conta_api": "disponivel",
        "sufixo_tipo_conta": "999999",
        "saldo_tipo_evento": ["saldo_disponivel"]
    }
]

def getTipoContaDictByMno(mno:str):
    dictResult = ListHelper.findFirstOrDefault(TIPO_CONTA_DICT, lambda x: x["mno"] == mno)
    if dictResult is None:
        raise ValueError(f"Tipo de conta com mno '{mno}' não encontrado.")
    return dictResult

def getTipoContaDictByTipoContaApi(tipo_conta_api:str):
    dictResult = ListHelper.findFirstOrDefault(TIPO_CONTA_DICT, lambda x: x["tipo_conta_api"] == tipo_conta_api)
    if dictResult is None:
        raise ValueError(f"Tipo de conta com tipo_conta_api '{tipo_conta_api}' não encontrado.")
    return dictResult

def getTipoContaDictBySaldoTipoEvento(saldo_tipo_evento:str):
    dictResult = ListHelper.findFirstOrDefault(TIPO_CONTA_DICT, lambda x: saldo_tipo_evento in x["saldo_tipo_evento"])
    if dictResult is None:
        raise ValueError(f"Tipo de conta com saldo_tipo_evento '{saldo_tipo_evento}' não encontrado.")
    return dictResult

def getTipoContaApiByMno(mno:str):
    dictResult = getTipoContaDictByMno(mno)
    return dictResult["tipo_conta_api"]

def getSufixoContaByMno(mno:str):
    dictResult = getTipoContaDictByMno(mno)
    return dictResult["sufixo_tipo_conta"]

def getMnoByTipoContaApi(tipo_conta_api:str):
    dictResult = getTipoContaDictByTipoContaApi(tipo_conta_api)
    return dictResult["mno"]

def getTipoContaBySaldoTipoEvento(saldo_tipo_evento:str):
    dictResult = getTipoContaDictBySaldoTipoEvento(saldo_tipo_evento)
    return dictResult["mno"]

