import os
from helper import DateTimeHelper
from repository.DataBaseEntityCollection import ContaRaw, LancamentoRaw, PosicaoContaRaw
from repository import DataBaseRepository
from service import TipoContaService, ContaService, ExtratroCore
import json

lancamentoRepository = DataBaseRepository.LancamentoRepository()
contaRepository = DataBaseRepository.ContaRepository()
posicaoContaRepository = DataBaseRepository.PosicaoContaRepository()

def loadJsonOrDefault(jsonStr:str, defaultValue=None):
    if jsonStr is None or jsonStr == "":
        return defaultValue
    try:
        return json.loads(jsonStr)
    except:
        return "failed_to_load_json"

def mapPosicaoContaRawToDto(posicaoContaRaw:PosicaoContaRaw, tipo_evento="saldo", descricao:str="SALDO"):
    return {
        "tipo_evento": tipo_evento,
        "data_evento": posicaoContaRaw.data_evento,
        "descricao_curta": descricao,
        "descricao_completa": descricao,
        "valor": round(posicaoContaRaw.valor, 2),
        "codigo_moeda_transacao": posicaoContaRaw.codigo_moeda_transacao
    }

def mapLancamentoRawToDto(lancamentoRaw:LancamentoRaw):
    propriedade_root_dict = loadJsonOrDefault(lancamentoRaw.propriedade_root_dict, {})
    return {
        "tipo_evento": "lancamento",
        "data_evento": lancamentoRaw.data_evento,
        "descricao_curta": lancamentoRaw.descricao_curta,
        "descricao_completa": lancamentoRaw.descricao_completa,
        "dica": propriedade_root_dict.get("dica", ""),
        "valor": round(lancamentoRaw.valor, 2),
        "codigo_moeda_transacao": lancamentoRaw.codigo_moeda_transacao,
        "contraparte_transacao": loadJsonOrDefault(lancamentoRaw.contraparte_transacao),
        "acao": propriedade_root_dict.get("acao", ""),
        "impacto": propriedade_root_dict.get("impacto", ""),
        "familia": propriedade_root_dict.get("familia", ""),
        "id_unico_evento": lancamentoRaw.uuid_evento,
        "codigo_motivo_lancamento": lancamentoRaw.codigo_motivo_lancamento,
        "legenda": propriedade_root_dict.get("legenda", ""),
        "descricao_legenda": propriedade_root_dict.get("descricao_legenda", ""),
        "indicador_tipo_operacao": lancamentoRaw.indicador_tipo_operacao,
        "data_hora_processamento_lancamento": lancamentoRaw.data_hora_processamento_lancamento,
        "estorno_lancamento": False,
        "datelhes": loadJsonOrDefault(lancamentoRaw.detalhe),
        "possui_detalhes": True,
        "descricao_complementar_cliente": propriedade_root_dict.get("descricao_complementar_cliente", ""),
        "origem_transacao": loadJsonOrDefault(lancamentoRaw.origem_transacao),
        "indicador_lancamento_final_oito": bool(lancamentoRaw.indicador_lancamento_final_oito),
        "indicador_lancamento_visivel_cliente": bool(lancamentoRaw.indicador_lancamento_visivel_cliente),
        "indicador_anotacao": bool(lancamentoRaw.indicador_anotacao)
    }

def getDataIniAnterior(dateIni):
    return DateTimeHelper.addDays(dateIni, -1)

def getSaldoAnteriorPadrao(uuid_conta:str, tipo_conta:str, dateIni):
    """Este retornaráo Saldo Imediatamente anterior Consolicado da conta
       Por experiência percebe-se que o saldo anterior vem datado como domingo quando se procura LANÇAMENTOS na SEGUNDA"""
    dataIniAnterior = getDataIniAnterior(dateIni)
    dataIniAnteriorStr = DateTimeHelper.toIsoDateString(dataIniAnterior)

    posicaoAnterior:PosicaoContaRaw|None = posicaoContaRepository.getPosicaoSaldoDataIgualOuAnterior(data_evento=dataIniAnteriorStr, uuid_conta=uuid_conta, tipo_conta="CONS", tipo_posicao="F")
    if not posicaoAnterior:
        posicaoAnterior = posicaoContaRepository.getPosicaoSaldoDataIgualOuAnterior(data_evento=dataIniAnteriorStr, uuid_conta=uuid_conta, tipo_conta="CONS", tipo_posicao="P")
   
    if not posicaoAnterior:
        # criar uma posição de conta fictícia com valor 0.0
        posicaoAnterior = PosicaoContaRaw(
            data_evento = dataIniAnteriorStr,
            uuid_conta = uuid_conta,
            tipo_conta = "CC",
            tipo_posicao = "F",
            valor = 0.0,
            codigo_moeda_transacao = "BRL",
            data_hora_atualizacao = DateTimeHelper.getNowIsoString(),
        )
    else:
        posicaoAnterior.data_evento = dataIniAnteriorStr # ajustar a data para a dataIniAnterior

    return posicaoAnterior

def getLancamentoResult(conta_id_raw_from_api:str, tipo_conta_api:str, dataIniStr:str, dataFimStr:str, paramDict={}):
    """Esta função retorna o resultado do extrato de lançamentos para uma conta específica 
    dentro de um intervalo de datas. A exibição padrão é intercalar cada data com as posições da conta.
    Se não encontrar uma posição de conta para a data especifica. Definir 0.0 como valor.
    """

    uuid_conta = ContaService.getUuidContaByContaIdApi(conta_id_raw_from_api)
    tipo_conta = TipoContaService.getMnoByTipoContaApi(tipo_conta_api)
    
    dataIni = DateTimeHelper.parseNullableDate(dataIniStr)
    dataFim = DateTimeHelper.parseNullableDate(dataFimStr)
    if not dataFim:
        dataFim = DateTimeHelper.getToday()
    dataIniAnterior = getDataIniAnterior(dataIni)
    dataIniAnteriorStr = DateTimeHelper.toIsoDateString(dataIniAnterior)
    contarSaldoIntermediarioEFinalComoItemDeLancamento = os.getenv("X0MOCKER_CONTAR_SALDO_COMO_LANCAMENTO", True)
    pageBusca = paramDict.get("page", 1)
    pageSize = paramDict.get("page_size", 10)

    lancamentoRawList = lancamentoRepository.filterLancamento(uuid_conta=uuid_conta, tipo_conta=tipo_conta, dataIni=dataIniStr, dataFim=dataFimStr)
    contaRaw:ContaRaw = contaRepository.get(uuid_conta=uuid_conta, tipo_conta=tipo_conta)

    ### Preparando os eventos com as posições intercaladas entre datas
    eventoList = []
    totalEventos = 0
    # adicionar a posição da data anterior (SALDO_ANTERIOR)
    posicaoDataAnterior = getSaldoAnteriorPadrao(uuid_conta, tipo_conta, dataIni)
    saldoAnteriorEvento = mapPosicaoContaRawToDto(posicaoDataAnterior, tipo_evento="saldo_disponivel", descricao="SALDO ANTERIOR")
    eventoList.append(saldoAnteriorEvento)
    # Contar posição SALDO_ANTERIOR como lançamento
    if contarSaldoIntermediarioEFinalComoItemDeLancamento:
        totalEventos = totalEventos + 1

    # Loop de Datas
    diaHoje = DateTimeHelper.getToday()
    ultimoDiaUtil = DateTimeHelper.getDiaUtilAnterior(diaHoje)

    dataPivo = dataIni
    while dataPivo <= dataFim:
        dataPivoStr = DateTimeHelper.toIsoDateString(dataPivo)
        lancamentoRawList_CC = lancamentoRepository.filterLancamento(uuid_conta=uuid_conta, tipo_conta=tipo_conta, dataIni=dataPivoStr, dataFim=dataPivoStr)
        lancamentoRawList = ExtratroCore.filterLancamentoParaSaldoConsolidado(lancamentoRawList_CC)

        if len(lancamentoRawList) > 0:
            eventoList.extend([mapLancamentoRawToDto(lancamentoRaw) for lancamentoRaw in lancamentoRawList])
            totalEventos = totalEventos + len(lancamentoRawList)

            # Não existe Saldo para o dia de Hoje
            if dataPivo < diaHoje:
                posicaoConta:PosicaoContaRaw|None = posicaoContaRepository.get(data_evento=dataPivoStr, uuid_conta=uuid_conta, tipo_conta="CONS", tipo_posicao="F")      
                if not posicaoConta:
                    print(f"Não encontrado posicao de Conta ao final do dia {dataPivo}. Vamos calcular...")
                    posicaoConta = ExtratroCore.calcularSaldoFinalParaAData(dataPivo, uuid_conta, tipo_conta)
            
            posicaoContaEventoFinalData = mapPosicaoContaRawToDto(posicaoContaRaw=posicaoConta, tipo_evento="saldo_disponivel", descricao="SALDO TOTAL DISPONÍVEL DIA")
            eventoList.append(posicaoContaEventoFinalData)
            if contarSaldoIntermediarioEFinalComoItemDeLancamento:
                totalEventos = totalEventos + 1

        dataPivo = DateTimeHelper.addDays(dataPivo, 1)

    response_body_dict = {
        "data": [
            {
                "eventos": eventoList,
                "pagination": {
                    "links": {},
                    "page": pageBusca,
                    "total_pages": 1,
                    "total_elements": totalEventos,
                    "page_size": pageSize
                },
                "conta": {
                    "numero_unico_conta": contaRaw.uuid_conta,
                    "numero_agencia": f"{contaRaw.agencia:04d}",
                    "numero_conta": f"{contaRaw.conta:07d}",
                    "numero_dv": f"{contaRaw.dac}",
                    "codigo_sufixo_conta": contaRaw.codigo_sufixo_conta,
                    "tipo_conta": TipoContaService.getTipoContaApiByMno(contaRaw.tipo_conta),
                },
                "agregacoes": {}
            }
        ]
    }

    return response_body_dict
    
    

    
    