from helper import DateTimeHelper, ListHelper
from repository.DataBaseEntityCollection import ContaRaw, LancamentoRaw, PosicaoContaRaw
from repository import DataBaseRepository
from service import TipoContaService, ContaService
import json

lancamentoRepository = DataBaseRepository.LancamentoRepository()
contaRepository = DataBaseRepository.ContaRepository()
posicaoContaRepository = DataBaseRepository.PosicaoContaRepository()

def calcularSaldoFinalParaAData(dataAlvo, uuid_conta:str, tipo_conta:str) -> PosicaoContaRaw|None:
    """Calcula o saldo final para a data alvo considerando apenas dias úteis.
    Para executar este cálculo, é necessário ter o saldo do dia útil anterior e somar os lançamentos do dia alvo.
    """
    dataHoje = DateTimeHelper.getToday()
    dataUtilAnterior = DateTimeHelper.getDiaUtilAnterior(dataHoje)

    if dataAlvo == dataHoje:
        raise Exception("Não é possível calcular o saldo final para a data de hoje.")
    # Calcular saldo Parcial
    dataUtilAnterior_a_dataAlvo = DateTimeHelper.getDiaUtilAnterior(dataAlvo)
    posicaoConta:PosicaoContaRaw|None = posicaoContaRepository.get(data_evento=DateTimeHelper.toIsoDateString(dataUtilAnterior_a_dataAlvo), uuid_conta=uuid_conta, tipo_conta="CONS", tipo_posicao="F")
    if not posicaoConta:
        raise Exception(f"Não encontrado posicao de Conta ao final do dia {dataUtilAnterior_a_dataAlvo}")
    
    lancamentoRawList = lancamentoRepository.filterLancamento(uuid_conta=uuid_conta, tipo_conta=tipo_conta, dataIni=DateTimeHelper.toIsoDateString(dataAlvo), dataFim=DateTimeHelper.toIsoDateString(dataAlvo))
    lancamentoRawListParaSaldo = filterLancamentoParaSaldoConsolidado(lancamentoRawList)
    saldoDia = sum([lancamento.valor for lancamento in lancamentoRawListParaSaldo])
    saldoConsolidadoFinal = posicaoConta.valor + saldoDia
    posicaoContaConsolidadoFinal = PosicaoContaRaw(
        data_evento=DateTimeHelper.toIsoDateString(dataAlvo),
        uuid_conta=uuid_conta,
        tipo_conta="CONS",
        tipo_posicao="F",
        valor=round(saldoConsolidadoFinal, 2),
        codigo_moeda_transacao=posicaoConta.codigo_moeda_transacao,
        data_hora_atualizacao=DateTimeHelper.getNowIsoString(),
        detalhe=f"Saldo Final Calculado pelo X0Mocker"
    )
    posicaoContaRepository.insertOrUpdate(posicaoContaConsolidadoFinal)
    return posicaoContaConsolidadoFinal

def filterLancamentoParaSaldoConsolidado(lancamentoList):
    return ListHelper.findAll(lancamentoList, lambda lancamento: lancamento.indicador_anotacao == 0 and lancamento.codigo_motivo_lancamento not in ["8512","8516"])
    