from datetime import datetime
from helper import DateTimeHelper
from repository.DataBaseEntityCollection import ContaRaw, LancamentoRaw, PosicaoContaRaw
from repository import DataBaseRepository
from service import TipoContaService
import json
import json5

lancamentoRepository = DataBaseRepository.LancamentoRepository()
contaRepository = DataBaseRepository.ContaRepository()
posicaoContaRepository = DataBaseRepository.PosicaoContaRepository()

def toJsonOrNone(obj):
    if obj is None:
        return None
    return json.dumps(obj)

def getPropertyOrSame(dataDict:dict, key:str):
    if key in dataDict:
        return dataDict[key]
    return dataDict

def getFirstOrSame(dataDict):
    if isinstance(dataDict, list):
        return dataDict[0] if dataDict else None
    return dataDict

def importFromX0File(fileName:str):
    with open(fileName, 'r', encoding='utf-8') as file:
        loadedFileDict = json5.load(file)
    
    # preparar mainContent
    main_value = getFirstOrSame(getPropertyOrSame(loadedFileDict, "data"))
    
    # preparar infos de conta
    conta_dict = main_value.get("conta", {})
    if conta_dict:
        contaRawObj = ContaRaw(
            uuid_conta = conta_dict["numero_unico_conta"],
            tipo_conta = TipoContaService.getMnoByTipoContaApi(conta_dict["tipo_conta"]),

            codigo_sufixo_conta = conta_dict.get("codigo_sufixo_conta"),
            agencia = conta_dict["numero_agencia"],
            conta = conta_dict["numero_conta"],
            dac = conta_dict["numero_dv"],
            uuid_cliente = None,
            data_hora_cadastro = datetime.now().isoformat(),
            detalhe = None
        )
        contaRepository.insertOrUpdate(contaRawObj)
    
    evento_list = getPropertyOrSame(main_value, "eventos")


    # Processar os dados conforme necessário
    if isinstance(evento_list, list):
        for lancamento in evento_list:
            if not isinstance(lancamento, dict):
                continue
            
            if lancamento.get("tipo_evento") == "lancamento":
                lancamentoRaw = LancamentoRaw(
                    data_evento = lancamento["data_evento"],
                    uuid_evento = lancamento["id_unico_evento"],
                    
                    uuid_conta = contaRawObj.uuid_conta if conta_dict else "unknown",
                    tipo_conta = contaRawObj.tipo_conta if conta_dict else "unknown",

                    tipo_evento = lancamento["tipo_evento"],
                    descricao_curta = lancamento.get("descricao_curta"),
                    descricao_completa = lancamento.get("descricao_completa"),
                    valor = lancamento["valor"],
                    indicador_tipo_operacao = lancamento["indicador_tipo_operacao"],
                    codigo_moeda_transacao = lancamento["codigo_moeda_transacao"],
                    
                    codigo_motivo_lancamento = lancamento["codigo_motivo_lancamento"],
                    
                    data_hora_real_cadastro_lancamento = datetime.now().isoformat(),
                    data_hora_processamento_lancamento = lancamento.get("data_hora_processamento_lancamento"),
                    contraparte_transacao = toJsonOrNone(lancamento.get("contraparte_transacao")),
                    origem_transacao = toJsonOrNone(lancamento.get("origem_transacao")),
                    detalhe = toJsonOrNone(lancamento.get("detalhes")),
                
                    indicador_lancamento_final_oito = int(lancamento.get("indicador_lancamento_final_oito",0)),
                    indicador_lancamento_visivel_cliente = int(lancamento.get("indicador_lancamento_visivel_cliente",0)),
                    indicador_anotacao = int(lancamento.get("indicador_anotacao",0)),

                    propriedade_root_dict = toJsonOrNone({
                        "dica": lancamento.get("dica"),
                        "acao": lancamento.get("acao"),
                        "impacto": lancamento.get("impacto"),
                        "familia": lancamento.get("familia"),
                        "legenda": lancamento.get("legenda"),
                        "descricao_legenda": lancamento.get("descricao_legenda"),
                        "descricao_complementar_cliente": lancamento.get("descricao_complementar_cliente")
                    })
                )
                lancamentoRepository.insert(lancamentoRaw)
            
            elif lancamento.get("tipo_evento", "").startswith("saldo"):
                posicaoContaRaw = PosicaoContaRaw(
                    data_evento = lancamento["data_evento"],
                    uuid_conta = contaRawObj.uuid_conta if conta_dict else "unknown",
                    tipo_conta = TipoContaService.getTipoContaBySaldoTipoEvento(lancamento["tipo_evento"]),
                    tipo_posicao = "F",
                    
                    valor = lancamento["valor"],
                    codigo_moeda_transacao = lancamento.get("codigo_moeda_transacao","BRL"),
                    data_hora_atualizacao = datetime.now().isoformat(),
                    detalhe = None
                )
                posicaoContaRepository.insertOrUpdate(posicaoContaRaw)


    
