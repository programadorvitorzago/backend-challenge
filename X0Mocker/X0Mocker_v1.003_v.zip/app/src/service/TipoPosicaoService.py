from helper import ListHelper

# Tipo de conta:
# CC =  Conta Corrente
TIPO_POSICAO_DICT = [
    {
        "mno": "P",
        "nome": "Posição Parcial",
    },
    {
        "mno": "F",
        "nome": "Posição Final",
    }
]




