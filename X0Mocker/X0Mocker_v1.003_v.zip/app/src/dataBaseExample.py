import sqlite3

def run_sqlite_example():
    # Connect to the database (creates the file if it doesn't exist)
    # Using a context manager ensures the connection is closed automatically
    with sqlite3.connect('todo.db') as conn:
        # # Create a cursor object to execute SQL commands
        cursor = conn.cursor()

        # # Create a table (IF NOT EXISTS prevents errors if it already exists)
        # cursor.execute('''
        #     CREATE TABLE IF NOT EXISTS tasks (
        #         id INTEGER PRIMARY KEY AUTOINCREMENT,
        #         name TEXT NOT NULL,
        #         priority INTEGER
        #     )
        # ''')
        
        # # Insert a record using a parameterized query (prevents SQL injection)
        # task_name = 'Learn Python and SQLite'
        # task_priority = 1
        # cursor.execute("INSERT INTO tasks (name, priority) VALUES (?, ?)", (task_name, task_priority))
        # cursor.execute("INSERT INTO tasks (name, priority) VALUES (?, ?)", ("teste2", 2))

        # Commit the changes (required for data modification)
        # The 'with' statement handles this automatically upon successful exit
        # conn.commit() 

        # Select data from the table
        cursor.execute("SELECT * priority FROM tasks")
        
        # Fetch the results (fetchone() for a single row, fetchall() for all)
        rowList = cursor.fetchall()
        for row in rowList:
            if row:
                print(f"Fetched Task: ID={row[0]} Name={row[1]}, Priority={row[2]}")
            else:
                print("No task found.")

    # Connection is closed automatically here

if __name__ == "__main__":
    run_sqlite_example()
