from fastapi import FastAPI, Request, Response
import json
import logging

VERSION = "0.0.1"
print(f"Iniciando X0Mocker {VERSION}")

logger = logging.getLogger()

app = FastAPI()

@app.get("/contas/v1/contas/{id_conta}/tipo_subcontas/{tipo_subconta}/extratos_lancamentos")
async def extrato_lancamento(id_conta:str, tipo_subconta:str, request: Request, response: Response):
    urn = request.url.path
    method = request.method

    print(f"Received request {method} from url: {urn}")
    
    urnPartList = urn.split("/")
    filteredUrlPartList = list(filter(lambda x: x > "", urnPartList))

    headerUserAgent = request.headers.get("User-Agent")
    headerAuthorization = request.headers.get("Authorization")

    recurso = filteredUrlPartList[0] if len(filteredUrlPartList) > 0 else None
    recursoParametro = "/".join(filteredUrlPartList[1:]) if len(filteredUrlPartList) > 1 else None

    dataIni = request.query_params.get("data_inicial")
    dataFim = request.query_params.get("data_final")

    print(f"Params: DataIni: {dataIni} DataFim: {dataFim}")
    print(f"Paths: idConya: {id_conta} TipoSubConta: {tipo_subconta}")


    response_body_dict = {
        "data": [
            {
                "eventos":[],
                "pagination": [],
            }
        ]
    }

    response.body = json.dumps(response_body_dict).encode('utf-8')
    response.status_code = 200
    return response     

    # print(f"urn: {urn}")
    # apiObj = AWSMock_apiListener.getApiByRequestPath(urn)
    # if apiObj:
    #     return AWSMock_apiListener.log_and_get_response(apiObj, request, response, await request.body())


    # if method == "GET":

    #     if len(filteredUrlPartList) < 1:
    #         # Lista os Buckets
    #         print(f"Resource: Bucket - Action: ListBuckets")
    #         return AWSMock_bucket.list_buckets_response(response)

    #     if recursoParametro is None:
    #         if not AWSMock_bucket.existsBucket(recurso):
    #             return AWSMock_bucket.bucket_does_not_exist_response(recurso, response)
            
    #         # Lista funcao lista objetos do bucket
    #         prefix = request.query_params.get("prefix")
    #         delimiter = request.query_params.get("delimiter")
    #         return AWSMock_bucket.list_objects_response(recurso, response, prefix=prefix, delimiter=delimiter)

    #     bucketName = recurso
    #     itemKey = recursoParametro
        
    #     bucketObject = AWSMock_bucket.getObjectEspec(bucketName, itemKey)
    #     if not bucketObject:
    #         return AWSMock_bucket.file_does_not_exist_response(bucketName, itemKey, response);
        
    #     bytesFileContent = AWSMock_bucket.downloadFile(bucketName, itemKey)
    #     AWSMock_Global.preencher_base_response(response)
    #     response.body = bytesFileContent
    #     response.headers["Accept-ranges"] = "bytes"
    #     response.headers["Connection"] = "close"
    #     response.headers["Content-Length"] = str(bucketObject.bytesLen)
    #     response.headers["Content-Type"] = "application/octet-stream"
    #     response.headers["Etag"] = "e7dc5f9f5a8ca0a8fa88163df45dbbd8" # TODO

    # elif method == "PUT":
    #     bucketName = recurso
    #     itemKey = recursoParametro
    #     contentEncoding = request.headers.get("Content-Encoding")

    #     print(f"UPLOAD")
    #     print(f"bucketName: {bucketName}")
    #     print(f"itemKey: {itemKey}")
        
    #     AWSMock_bucket.uploadFile(bucketName, itemKey, contentEncoding, await request.body())
    
    #     AWSMock_Global.preencher_base_response(response)
    #     response.headers["Connection"] = "close"
    #     response.headers["Last-modified"] = "Mon, 18 Aug 2025 01:59:14 GMT"

    # elif method == "HEAD":
    #     bucketName = recurso
    #     itemKey = recursoParametro
        
    #     print(f"HEAD")
    #     print(f"bucketName: {bucketName}")
    #     print(f"itemKey: {itemKey}")
        
    #     bucketObject = None
    #     if itemKey is not None:
    #         bucketObject = AWSMock_bucket.getObjectEspec(bucketName, itemKey)
    #         if not bucketObject:
    #             return AWSMock_bucket.file_does_not_exist_response(bucketName, itemKey, response);
    #     else:
    #         AWSMock_bucket.getBucket(bucketName) # Apenas para validar se o bucket existe
            
    #     AWSMock_Global.preencher_base_response(response)
    #     response.headers["Connection"] = "close"
    #     if bucketObject:
    #         response.headers["Content-Length"] = str(bucketObject.bytesLen)
    #     response.headers["Content-Type"] = "application/octet-stream"
    #     response.headers["Last-modified"] = "Mon, 18 Aug 2025 01:59:14 GMT" # TODO
    #     response.headers["server"] = "AwsMockServer/1.0"

    # elif method == "POST":

    #     ## pode ser SQS, SNS ou SecretesManager
    #     ## Percebe-se que SNS não vem com X-amz-target

    #     bodyBytes = await request.body()
    #     action = request.headers.get("X-amz-target")
        
    #     if action:
    #         #SQS ou SecretesManager
    #         jsonBody = json.loads(bodyBytes) if bodyBytes else {}

    #         if action.startswith("AmazonSQS"):
    #             try:
    #                 queueUrl = jsonBody.get("QueueUrl", "")
    #                 if queueUrl:
    #                     queueName = queueUrl.split("/")[-1]
    #                 else:
    #                     queueName = jsonBody.get("QueueName", "defaultQueue")

    #                 if action == "AmazonSQS.SendMessage":
    #                     messageBody = jsonBody.get("MessageBody")
    #                     return AWSMock_queue.send_message_response(queueName, messageBody, response)
                    
    #                 elif action == "AmazonSQS.ReceiveMessage":
    #                     return AWSMock_queue.receive_message_response(queueName, response)
                    
    #                 elif action == "AmazonSQS.DeleteMessage":
    #                     receiptHandle = jsonBody.get("ReceiptHandle")
    #                     return AWSMock_queue.delete_message_response(queueName, receiptHandle, response)
                    
    #                 elif action == "AmazonSQS.PurgeQueue":
    #                     return AWSMock_queue.purge_queue_response(queueName, response)
                    
    #                 elif action == "AmazonSQS.DeleteMessageBatch":
    #                     return AWSMock_queue.delete_message_response_batch(queueName, jsonBody, response)

    #                 elif action == "AmazonSQS.GetQueueAttributes":
    #                     return AWSMock_Global.preencher_base_response_json(response)

    #                 elif action == "AmazonSQS.GetQueueUrl":
    #                     return AWSMock_queue.get_queue_url_response(queueName, response)

    #                 else:
    #                     response.status_code = 400
    #                     response.body = f"Bad Request - {action}: Action not implemented ".encode('utf-8')
                
    #             except AWSMock_Global.ElementNotFoundError as e:
    #                 AWSMock_Global.print_for_internal_controler(e)
    #                 response_body_dict = {
    #                     "__type": "QueueDoesNotExist",
    #                     "message": "The specified queue does not exist."
    #                 }
    #                 AWSMock_Global.preencher_base_response_json(response, 400, response_body=response_body_dict)
    #                 response.headers["x-amzn-query-error"] = "AWS.SimpleQueueService.NonExistentQueue"
    #                 response.headers["Connection"] = "close"
            
    #         elif action.startswith("secretsmanager"):
    #             if action == "secretsmanager.GetSecretValue":
    #                 secretId = str(jsonBody.get("SecretId"))
    #                 return AWSMock_secretsmanager.get_secret_value_response(secretId, response)

    #             else:
    #                 response.status_code = 400
    #                 response.body = f"Bad Request - {action}: Action not implemented ".encode('utf-8')

    #     else:
    #         # Provavelmente SNS
    #         formBodyDict = AWSMock_Global.convert_body_form_urlencoded_to_dict(bodyBytes)
    #         action = formBodyDict.get("Action")
    #         topicArn = formBodyDict.get("TopicArn", "")
    #         topicName = topicArn.split(":")[-1]
    #         messageBody = formBodyDict.get("Message")
    #         creatorOrigin = AWSMock_Global.get_authorization_identify(headerAuthorization)
            
    #         if action == "Publish":
    #             return AWSMock_topic.publish_message_response(topicName, messageBody, creatorOrigin, response)
    #         else:
    #             response.status_code = 400
    #             response.body = f"Bad Request - {action}: Action not implemented ".encode('utf-8')

    # elif method == "DELETE":
    #     bucketName = recurso
    #     itemKey = recursoParametro
        
    #     print(f"DELETE")
    #     print(f"bucketName: {bucketName}")
    #     print(f"itemKey: {itemKey}")
        
    #     return AWSMock_bucket.delete_object_response(bucketName, itemKey, response)

    # else:
    #     response.status_code = 405
    #     response.body = b"Method Not Implemented"
    
    # return response





