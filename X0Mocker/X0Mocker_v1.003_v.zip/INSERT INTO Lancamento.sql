-- INSERT INTO PosicaoContaTbl
-- (data_evento, uuid_conta, tipo_posicao, valor, codigo_moeda_transacao, data_hora_atualizacao)
-- VALUES ('2026-01-17', 'abc-123', 'F', 1500.50, 'BRL', '2026-01-17 10:00:00');

INSERT INTO ContaTbl
(uuid_conta, tipo_conta, codigo_sufixo_conta, agencia, conta, dac, data_hora_cadastro, detalhe)
VALUES('00000000-0000-0000-0000-000000000001', 'CC', '100000', 1500, 1109, 1, "2026-01-01T00:00:00", NULL);

INSERT INTO ContaTbl
(uuid_conta, tipo_conta, agencia, conta, dac, data_hora_cadastro, detalhe)
VALUES('00000000-0000-0000-0000-000000000002', 'CC', '100000', 1529, 8881, 5, "2026-01-01T00:00:00", NULL);

INSERT INTO ContaTbl
(uuid_conta, tipo_conta, agencia, conta, dac, data_hora_cadastro, detalhe)
VALUES('00000000-0000-0000-0000-000000000003', 'CC', '100000', 3790, 10775, 3, "2026-01-01T00:00:00", NULL);

INSERT INTO LancamentoTbl
(data_evento, uuid_evento, uuid_conta, tipo_conta, tipo_evento, descricao_curta, descricao_completa, valor, indicador_tipo_operacao, codigo_moeda_transacao, codigo_motivo_lancamento, data_hora_real_cadastro_lancamento, data_hora_processamento_lancamento, propriedade_root_dict, contraparte_transacao, origem_transacao, detalhe, indicador_lancamento_final_oito, indicador_lancamento_visivel_cliente, indicador_anotacao)
VALUES('2026-01-05', 'b2ace7ff-b503-4055-bf50-730a0e90fd94', '00000000-0000-0000-0000-000000000001', 'CC', 'lancamento', 'PIX TRANSF ELISANG18/12', 'PIX TRANSF ELISANG18/12', 10.0, 'C', 'BRL', '9958', '2026-01-01T00:00:00', '2026-01-01T00:00:00', NULL, NULL, NULL, NULL, 0, 1, 0);
INSERT INTO LancamentoTbl
(data_evento, uuid_evento, uuid_conta, tipo_evento, descricao_curta, descricao_completa, valor, indicador_tipo_operacao, codigo_moeda_transacao, codigo_motivo_lancamento, data_hora_real_cadastro_lancamento, data_hora_processamento_lancamento, propriedade_root_dict, contraparte_transacao, origem_transacao, detalhe, indicador_lancamento_final_oito, indicador_lancamento_visivel_cliente, indicador_anotacao)
VALUES('2026-01-05', 'b2ace7ff-b503-4055-bf50-730a0e90fd95', '00000000-0000-0000-0000-000000000001', 'CC', 'lancamento', 'PIX TRANSF ELISANG18/12', 'PIX TRANSF ELISANG18/12', 20.0, 'C', 'BRL', '9958', '2026-01-01T00:00:00', '2026-01-01T00:00:00', NULL, NULL, NULL, NULL, 0, 1, 0);
INSERT INTO LancamentoTbl
(data_evento, uuid_evento, uuid_conta, tipo_evento, descricao_curta, descricao_completa, valor, indicador_tipo_operacao, codigo_moeda_transacao, codigo_motivo_lancamento, data_hora_real_cadastro_lancamento, data_hora_processamento_lancamento, propriedade_root_dict, contraparte_transacao, origem_transacao, detalhe, indicador_lancamento_final_oito, indicador_lancamento_visivel_cliente, indicador_anotacao)
VALUES('2026-01-05', 'b2ace7ff-b503-4055-bf50-730a0e90fd96', '00000000-0000-0000-0000-000000000001', 'CC', 'lancamento', 'PIX TRANSF ELISANG18/12', 'PIX TRANSF ELISANG18/12', 30.0, 'C', 'BRL', '9958', '2026-01-01T00:00:00', '2026-01-01T00:00:00', NULL, NULL, NULL, NULL, 0, 1, 0);