import locale
from jinja2 import Environment, FileSystemLoader
import json5
from datetime import datetime

currentLocale = locale.getlocale()
print("Linguagem do sistema: ", currentLocale) 
locale.setlocale(locale.LC_ALL, currentLocale)

# Configurar o ambiente Jinja2
file_loader = FileSystemLoader('.')
env = Environment(loader=file_loader)

def parseDate(valor):
    if len(valor) > 10:
        datetime_object = datetime.strptime(valor, '''%Y-%m-%dT%H:%M:%S''')
    else: 
        datetime_object = datetime.strptime(valor, '''%Y-%m-%d''')
    return datetime_object

def formatData(valor):
    datetime_object = parseDate(valor)
    return datetime_object.strftime("%d/%m/%Y")

def formatHora(valor):
    datetime_object = parseDate(valor)
    return datetime_object.strftime("%H:%M:%S")

def formatDataHora(valor):
    datetime_object = parseDate(valor)
    return datetime_object.strftime("%d/%m/%Y %H:%M:%S")

def formatDiaSemana(valor):
    datetime_object = parseDate(valor)
    weekDayEnum = datetime_object.weekday()
    print("Weekday: ", weekDayEnum)
    if weekDayEnum < 5:
        return datetime_object.strftime("%A") + "-feira"
    return datetime_object.strftime("%A")

def formalJoin(valor):
    itemNum = len(valor)
    if itemNum == 1:
        return valor[0]
    elif itemNum == 2:
        return valor[0] + " e " + valor[1]
    else:
        return ', '.join(valor[:-1]) + " e " + valor[-1]

# Carregar o template
env.filters['formatData'] = formatData
env.filters['formatHora'] = formatHora
env.filters['formatDataHora'] = formatDataHora
env.filters['formalJoin'] = formalJoin
env.filters['formatDiaSemana'] = formatDiaSemana
template = env.get_template('template.jinja')

data = {}

#Preparando funções Uteis:
data["Utils"] = {}
data["Utils"]["format"] = format

# Ler dados do arquivo JSON
with open('itemTrabalhoInput.jsonc', 'r') as f:
    data["Model"] = json5.load(f)

# Renderizar o template com os dados
output = template.render(data)

# Exibir o resultado
# print(output)

# Opcional: Salvar o resultado em um arquivo
with open('output.html', 'w') as f:
    f.write(output)