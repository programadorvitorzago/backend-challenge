import os
import uvicorn
import AWSMock.AWSMock_Global as AWSMock_Global

debugMode = os.getenv("AWSMOCK_DEBUGMODE", "false").lower() == "true"

AWSMock_Global.load_config_file(os.getenv("AWSMOCK_CONFIGFILE", "awsmock.json"))

if __name__ == "__main__":
    uvicorn.run("AWSMock.AWSMock_Main:app", port=AWSMock_Global.SERVER_PORT, log_level="info", reload=debugMode)

# TESTE
#queueMessage = AWSMock_queue.createQueueMessage("123456789789", "sç~kfas~dçlkfsd~f")
# AWSMock_queue.writeQueueMessage("QM_MESSAGE_001.ami", queueMessage)
# queueMessage = AWSMock_queue.load_file_item("QM_MESSAGE_005.ami")
# print(queueMessage)

