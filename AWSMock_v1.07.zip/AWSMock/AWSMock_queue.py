import json
import os
import uuid
from datetime import datetime as DateTime, timedelta as TimeDelta
import localUtil
import AWSMock.AWSMock_Global as AWSMock_Global
import time as SystemTimer

sqsStore = [];

class QueueMessage:
    P_MESSAGE_ID = "message-id"
    P_CREATOR_ORIGIN = "creator-origin"
    P_PRODUCER_TIME = "producer-time"
    P_MD5_OF_BODY = "md5-of-body"
    P_BODY = "body"
    P_INTERNAL_MESSAGE_ID = "INTERNAL_MESSAGE_ID"
    P_FILE_PATH = "FILE_PATH"

    ACCEPTED_PROPERTIES = [P_MESSAGE_ID, P_CREATOR_ORIGIN, P_PRODUCER_TIME, P_MD5_OF_BODY, P_BODY]

class QueueMock:
    def __init__(self, queue_name, local_path, **propDict):
        self.queue_name = queue_name
        self.localPath = local_path
        self.creationTime = DateTime.now()
        self.visibilityTimeout = propDict.get("visibilityTimeout", 30) # seconds
        self.moveConsumed = propDict.get("moveConsumed", False)
        self.recalculateMd5 = bool(propDict.get("moveConsumed", True))

        self.messageCount = 0
        self.requestControl = {}

def createQueue(queueName, localPath, propDict):
    if not queueName or not localPath:
        raise Exception("Queue name and local path are required")
    new_queue = QueueMock(queueName, localPath, **propDict)
    sqsStore.append(new_queue)
    print(f"Queue created: {queueName} at {localPath}")
    return new_queue

def createQueueMessage(messageId, messageBody):
    dateTimeNow = DateTime.now()
    return {
        QueueMessage.P_MESSAGE_ID: messageId,
        QueueMessage.P_MD5_OF_BODY: localUtil.md5_hash(messageBody),
        QueueMessage.P_BODY: messageBody,
        QueueMessage.P_PRODUCER_TIME: dateTimeNow.strftime('%Y-%m-%dT%H''h''%M''m''%S.%f''s'''),
        "internalProducerTime": dateTimeNow,
        "Attributes": {
            "SenderId": "000000000000",
            "SentTimestamp": int(SystemTimer.time() * 1000)
        },
        QueueMessage.P_INTERNAL_MESSAGE_ID: messageId
    }

def createMessageHandler(messageId, handlerId = None):
    dateTimeNow = DateTime.now()
    if not handlerId:
        handlerId = dateTimeNow.strftime('%Y%m%dT%H%M%S.') + messageId[QueueMessage.P_MESSAGE_ID]

    return {
        "messageId": messageId[QueueMessage.P_MESSAGE_ID],
        "internalMessageId": messageId[QueueMessage.P_INTERNAL_MESSAGE_ID],
        "handlerId": handlerId,
        "requestTimeStamp": dateTimeNow,
        "filePath": messageId[QueueMessage.P_FILE_PATH],
    }

def getQueue(queueName):
    for queue in sqsStore:
        if queue.queue_name == queueName:
            return queue
    raise Exception(f"Queue not found: {queueName}")

def write_file_item(messageFilePath, messageDict):
    with open(messageFilePath, 'x', encoding="utf-8") as file:
        file.write("[QUEUE_MESSAGE]\n")
        for mProperty in [QueueMessage.P_MESSAGE_ID, QueueMessage.P_CREATOR_ORIGIN, QueueMessage.P_PRODUCER_TIME, QueueMessage.P_MD5_OF_BODY]:
            propValue = messageDict.get(mProperty, "")
            if propValue:
                file.write(f"{mProperty}={messageDict[mProperty]}\n")
        file.write("\n")

        file.write("[BODY]\n")
        file.write(messageDict[QueueMessage.P_BODY])

def load_file_item(filePath):
    queueMessage = createQueueMessage("", "")

    with open(filePath, "r", encoding="utf-8") as fileItem:
        line = fileItem.readline()
        if line.startswith("[QUEUE_MESSAGE]") or line.startswith("[BODY]"):
            ## Aquivo de está seccionado
            if line.startswith("[QUEUE_MESSAGE]"):
                line = fileItem.readline()
                while not line.startswith("[BODY]"):
                    line = line.strip()
                    if line:
                        if "=" in line:
                            propName, propValue = line.split("=", 1)
                            if propName in QueueMessage.ACCEPTED_PROPERTIES:
                                queueMessage[propName] = propValue
                    line = fileItem.readline()
            
            if line.startswith("[BODY]"):
                # Ler o corpo da mensagem
                queueMessage[QueueMessage.P_BODY] = fileItem.read()

        else:
            # O arquivo é body puro
            fileItem.seek(0)
            queueMessage[QueueMessage.P_BODY] = fileItem.read()

        
        if not queueMessage[QueueMessage.P_MESSAGE_ID]:
            # queueMessage[QueueMessage.P_MESSAGE_ID] = str(uuid.UUID(bytes=queueMessage[QueueMessage.P_BODY].encode("utf-8")))
            queueMessage[QueueMessage.P_MESSAGE_ID] = str(uuid.uuid3(uuid.NAMESPACE_DNS, queueMessage[QueueMessage.P_BODY]))

        queueMessage[QueueMessage.P_INTERNAL_MESSAGE_ID] = queueMessage[QueueMessage.P_MESSAGE_ID]
        queueMessage[QueueMessage.P_FILE_PATH] = filePath
        return queueMessage

def send_message_response(queueName, messageBody, response):
    queue = getQueue(queueName)
    
    queueMessage = createQueueMessage(str(uuid.uuid4()), messageBody)
    queue.messageCount += 1
    dateTimeReceived = queueMessage["internalProducerTime"]
    messageFilePath = os.path.join(queue.localPath, f"QM_{dateTimeReceived.strftime('%Y-%m-%dT%H''h''%M''m''%S.%f''s''')}.{AWSMock_Global.ITEM_DEFAULT_EXTENSION}")
    
    write_file_item(messageFilePath, queueMessage)

    AWSMock_Global.preencher_base_response_json(response)
    response.headers["Connection"] = "close"
    
    response_body_dict = {
        "MessageId": queueMessage[QueueMessage.P_MESSAGE_ID],
        "MD5OfMessageBody": queueMessage[QueueMessage.P_MD5_OF_BODY],
    }
    
    response.body = json.dumps(response_body_dict).encode('utf-8')
    
    return response

def nextMessage(queue):
    for root, _, files in os.walk(queue.localPath):
        for file in files:
            if not file.startswith((".","_")):
                messageFilePath = os.path.join(queue.localPath, file)
                queueMessage = load_file_item(messageFilePath)
                
                if queueMessage[QueueMessage.P_INTERNAL_MESSAGE_ID] in queue.requestControl:
                    if (queue.requestControl[queueMessage[QueueMessage.P_INTERNAL_MESSAGE_ID]]["requestTimeStamp"] +  
                            TimeDelta(seconds=queue.visibilityTimeout)) > DateTime.now():
                        continue
                
                return queueMessage
        break # Only check the top directory
    return None

def receive_message_response(queueName, response):
    queue = getQueue(queueName)
    
    queueMessage = nextMessage(queue)

    if queueMessage:
        
        messageId = queueMessage[QueueMessage.P_MESSAGE_ID]
        requestInf = createMessageHandler(queueMessage)
        queue.requestControl[queueMessage[QueueMessage.P_INTERNAL_MESSAGE_ID]] = requestInf

        AWSMock_Global.preencher_base_response_json(response)
        response.headers["Connection"] = "close"
        
        if not queueMessage[QueueMessage.P_MD5_OF_BODY]:
            queueMessage[QueueMessage.P_MD5_OF_BODY] = localUtil.md5_hash(queueMessage[QueueMessage.P_BODY])
        else:
            if queue.recalculateMd5:
                queueMessage[QueueMessage.P_MD5_OF_BODY] = localUtil.md5_hash(queueMessage[QueueMessage.P_BODY])

        response_body_dict = {
            "MessageId": messageId,
            "MD5OfBody": queueMessage[QueueMessage.P_MD5_OF_BODY],
            "Body": queueMessage[QueueMessage.P_BODY],
            "Attributes": queueMessage["Attributes"],
            "ReceiptHandle": requestInf["handlerId"],
        }
        
        bodyBytes = json.dumps({"Messages": [response_body_dict]}).encode("utf-8")
        response.headers["Content-length"] = str(len(bodyBytes))
        response.body = bodyBytes
        return response

    else:

        AWSMock_Global.preencher_base_response_json(response)
        response.headers["Connection"] = "close"
        
        bodyBytes = json.dumps({}).encode("utf-8")
        response.headers["Content-length"] = str(len(bodyBytes))
        response.body = bodyBytes

        SystemTimer.sleep(5)

        return response

def delete_message_by_handlerId(queue: QueueMock, receiptHandle) -> bool:
    messageHandler = None
    for messageId in queue.requestControl:
        if queue.requestControl[messageId]["handlerId"] == receiptHandle:
            messageHandler = queue.requestControl[messageId]
            break

    if messageHandler:
        del queue.requestControl[messageHandler["internalMessageId"]]
        filePath = messageHandler["filePath"]
        if os.path.exists(filePath):
            if queue.moveConsumed:
                consumedDir = os.path.join(queue.localPath, "__consumed__")
                if not os.path.exists(consumedDir):
                    os.makedirs(consumedDir)
                newFilePath = os.path.join(consumedDir, os.path.basename(filePath))
                os.rename(filePath, newFilePath)
            else:
                os.remove(filePath)

        return True, messageHandler
    
    return False, messageHandler

def delete_message_response(queueName, receiptHandle, response):
    queue = getQueue(queueName)
    
    itemWasDeleted , _ = delete_message_by_handlerId(queue, receiptHandle)

    if itemWasDeleted:
        AWSMock_Global.preencher_base_response_json(response)
        response.headers["Connection"] = "close"
        response.body = json.dumps({}).encode('utf-8')
        return response
    
    else:
        AWSMock_Global.preencher_base_response_json(response, 400)
        response.headers["Connection"] = "close"
        response.headers["X-amzn-errortype"] = "ReceiptHandleIsInvalid"
        response.body = json.dumps({}).encode('utf-8')

        response_body_dict = {
            "__type": "ReceiptHandleIsInvalid",
            "message":f"The input receipt handle \"{receiptHandle}\" is not a valid receipt handle.",
        }
        response.body = json.dumps(response_body_dict).encode('utf-8')
        
        return response

def delete_message_response_batch(queueName, jsonBody, response):
    queue = getQueue(queueName)
    
    successful = []
    failed = []
    
    for entry in jsonBody.get("Entries", []):
        receiptHandle = entry.get("ReceiptHandle")

        itemWasDeleted, messageHandler = delete_message_by_handlerId(queue, receiptHandle)

        if itemWasDeleted:
            successful.append({
                "Id": messageHandler["messageId"]
            })
        else:
            failed.append({
                "Id": messageHandler["messageId"],
                "SenderFault": False,
                "Code": "ReceiptHandleIsInvalid",
                "Message": f"The input receipt handle \"{receiptHandle}\" is not a valid receipt handle."
            })
    
    AWSMock_Global.preencher_base_response_json(response)
    response.headers["Connection"] = "close"
    
    response_body_dict = {
        "Successful": successful,
        "Failed": failed
    }
    
    bodyBytes = json.dumps({"Messages": [response_body_dict]}).encode("utf-8")
    response.headers["Content-length"] = str(len(bodyBytes))
    response.body = bodyBytes
    return response

def purge_queue_response(queueName, response):
    queue = getQueue(queueName)
    
    for root, _, files in os.walk(queue.localPath):
        for file in files:
            if not file.startswith((".","_")):
                messageFilePath = os.path.join(queue.localPath, file)
                if os.path.exists(messageFilePath):
                    os.remove(messageFilePath)
        break 
    
    queue.requestControl.clear()
    
    AWSMock_Global.preencher_base_response_json(response)

    response.headers["Connection"] = "close"
    response.body = json.dumps({}).encode('utf-8')
    return response


    