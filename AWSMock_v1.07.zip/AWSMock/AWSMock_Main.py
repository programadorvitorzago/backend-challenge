from fastapi import FastAPI, Request, Response
import AWSMock.AWSMock_Global as AWSMock_Global
import AWSMock.AWSMock_bucket as AWSMock_bucket
import AWSMock.AWSMock_queue as AWSMock_queue
import AWSMock.AWSMock_topic as AWSMock_topic
import json

print(f"Iniciando AWSMock v{AWSMock_Global.AWSMOCK_VERSION} ...")

# Starting resources
for resouce in AWSMock_Global.RECURSO_LIST:
    match resouce.get("resourceType"):
        case "queue":
            AWSMock_queue.createQueue(resouce.get('resourceName'), resouce.get('localPath'), resouce)
        case "bucket":
            AWSMock_bucket.createBucket(resouce.get('resourceName'), resouce.get('localPath'))
        case "topic":
            AWSMock_topic.createTopic(resouce.get('resourceName'), resouce.get('localPath'))
        case _:
            print(f"O recurso tipo {resouce.get('resourceType')} não implementado")

app = FastAPI()

@app.get("/{anyPath:path}")
@app.post("/{anyPath:path}")
@app.put("/{anyPath:path}")
@app.head("/{anyPath:path}")
@app.delete("/{anyPath:path}")
@app.api_route("/{anyPath:path}")
async def main_api_entrace(request: Request, response: Response):
    urn = request.url.path
    method = request.method

    print(f"Received request {method} from url: {urn}")
    
    urnPartList = urn.split("/")
    filteredUrlPartList = list(filter(lambda x: x > "", urnPartList))

    headerUserAgent = request.headers.get("User-Agent")
    headerAuthorization = request.headers.get("Authorization")

    recurso = filteredUrlPartList[0] if len(filteredUrlPartList) > 0 else None
    recursoParametro = "/".join(filteredUrlPartList[1:]) if len(filteredUrlPartList) > 1 else None
    
    if method == "GET":

        if len(filteredUrlPartList) < 1:
            response.status_code = 400
            response.body = b"Bad Request"
            return response
        
        if recursoParametro is None:
            # Lista funcao lista objetos do bucket
            prefix = request.query_params.get("prefix")
            return AWSMock_bucket.list_objects_response(recurso, prefix, response)

        bucketName = recurso
        itemKey = recursoParametro
        
        bucketObject = AWSMock_bucket.getObjectEspec(bucketName, itemKey)
        if not bucketObject:
            return AWSMock_bucket.file_does_not_exist_response(bucketName, itemKey, response);
        
        bytesFileContent = AWSMock_bucket.downloadFile(bucketName, itemKey)
        AWSMock_Global.preencher_base_response(response)
        response.body = bytesFileContent
        response.headers["Accept-ranges"] = "bytes"
        response.headers["Connection"] = "close"
        response.headers["Content-Length"] = str(bucketObject.bytesLen)
        response.headers["Content-Type"] = "application/octet-stream"
        response.headers["Etag"] = "e7dc5f9f5a8ca0a8fa88163df45dbbd8" # TODO

    elif method == "PUT":
        bucketName = recurso
        itemKey = recursoParametro
        contentEncoding = request.headers.get("Content-Encoding")

        print(f"UPLOAD")
        print(f"bucketName: {bucketName}")
        print(f"itemKey: {itemKey}")
        
        AWSMock_bucket.uploadFile(bucketName, itemKey, contentEncoding, await request.body())
    
        AWSMock_Global.preencher_base_response(response)
        response.headers["Connection"] = "close"
        response.headers["Last-modified"] = "Mon, 18 Aug 2025 01:59:14 GMT"

    elif method == "HEAD":
        bucketName = recurso
        itemKey = recursoParametro
        
        print(f"HEAD")
        print(f"bucketName: {bucketName}")
        print(f"itemKey: {itemKey}")
        
        bucketObject = None
        if itemKey is not None:
            bucketObject = AWSMock_bucket.getObjectEspec(bucketName, itemKey)
            if not bucketObject:
                return AWSMock_bucket.file_does_not_exist_response(bucketName, itemKey, response);
        else:
            AWSMock_bucket.getBucket(bucketName) # Apenas para validar se o bucket existe
            
        AWSMock_Global.preencher_base_response(response)
        response.headers["Connection"] = "close"
        if bucketObject:
            response.headers["Content-Length"] = str(bucketObject.bytesLen)
        response.headers["Content-Type"] = "application/octet-stream"
        response.headers["Last-modified"] = "Mon, 18 Aug 2025 01:59:14 GMT" # TODO
        response.headers["server"] = "AwsMockServer/1.0"

    elif method == "POST":

        ## pode ser SQS ou SNS
        ## Percebe-se qu SNS não vem com X-amz-target

        bodyBytes = await request.body()
        action = request.headers.get("X-amz-target")
        if action:
            #SQS
            jsonBody = json.loads(bodyBytes) if bodyBytes else {}
            queueUrl = str(jsonBody.get("QueueUrl"))
            queueName = queueUrl.split("/")[-1]
            if action == "AmazonSQS.SendMessage":
                messageBody = jsonBody.get("MessageBody")
                return AWSMock_queue.send_message_response(queueName, messageBody, response)
            
            elif action == "AmazonSQS.ReceiveMessage":
                return AWSMock_queue.receive_message_response(queueName, response)
            
            elif action == "AmazonSQS.DeleteMessage":
                receiptHandle = jsonBody.get("ReceiptHandle")
                return AWSMock_queue.delete_message_response(queueName, receiptHandle, response)
            
            elif action == "AmazonSQS.PurgeQueue":
                return AWSMock_queue.purge_queue_response(queueName, response)
            
            elif action == "AmazonSQS.DeleteMessageBatch":
                return AWSMock_queue.delete_message_response_batch(queueName, jsonBody, response)

            elif action == "AmazonSQS.GetQueueAttributes":
                return AWSMock_Global.preencher_base_response_json(response)
          
            else:
                response.status_code = 400
                response.body = f"Bad Request - {action}: Action not implemented ".encode('utf-8')
        else:
            # Provavelmente SNS
            formBodyDict = AWSMock_Global.convert_body_form_urlencoded_to_dict(bodyBytes)
            action = formBodyDict.get("Action")
            topicArn = formBodyDict.get("TopicArn", "")
            topicName = topicArn.split(":")[-1]
            messageBody = formBodyDict.get("Message")
            creatorOrigin = AWSMock_Global.get_authorization_identify(headerAuthorization)
            
            if action == "Publish":
                return AWSMock_topic.publish_message_response(topicName, messageBody, creatorOrigin, response)
            else:
                response.status_code = 400
                response.body = f"Bad Request - {action}: Action not implemented ".encode('utf-8')

    elif method == "DELETE":
        bucketName = recurso
        itemKey = recursoParametro
        
        print(f"DELETE")
        print(f"bucketName: {bucketName}")
        print(f"itemKey: {itemKey}")
        
        return AWSMock_bucket.delete_object_response(bucketName, itemKey, response)

    else:
        response.status_code = 405
        response.body = b"Method Not Implemented"
    
    return response






