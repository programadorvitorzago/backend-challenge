import os
import uuid
from datetime import datetime as DateTime
import localUtil
import AWSMock.AWSMock_Global as AWSMock_Global

bucketStore = [];

objectDoesNotExistBase = { "Code": "NoSuchKey", "Message": "The specified key does not exist." }

class BucketMock:
    def __init__(self, bucket_name, local_path):
        self.bucket_name = bucket_name
        self.localPath = local_path

class BucketObject:
    def __init__(self, object_key, bytesLen, lastModified):
        self.object_key = object_key
        self.bytesLen = bytesLen
        self.lastModified = lastModified

def createBucket(bucketName, localPath):
    if not bucketName or not localPath:
        raise Exception("Bucket name and local path are required")
    if not os.path.exists(localPath):
        if os.path.isabs(localPath) or not AWSMock_Global.CREATE_DIR:
            print(f"AVISO: Rescurso BUCKET ignorado: Caminho do recurso deve existir: {localPath}")
            return None
        else:
            os.makedirs(localPath, exist_ok=True)

    new_bucket = BucketMock(bucketName, localPath)
    bucketStore.append(new_bucket)
    print(f"Bucket created: {bucketName} at {localPath}")
    return new_bucket

def getBucket(bucketName):
    for bucket in bucketStore:
        if bucket.bucket_name == bucketName:
            return bucket
    raise Exception(f"Bucket not found {bucketName}")

def writeFile(localPath, objectKey, fileContent: bytes):
    fullPath = f"{localPath}/{objectKey}"
    directory_path = os.path.dirname(fullPath)
    os.makedirs(directory_path, exist_ok=True)
    if os.path.exists(fullPath):
        os.remove(fullPath)
    with open(fullPath, 'xb') as file:
        file.write(fileContent)

def getObjectEspec(bucketName, objectKey):
    bucket = getBucket(bucketName)
    fullPath = f"{bucket.localPath}/{objectKey}"
    
    if os.path.exists(fullPath):
        bytesLen = os.path.getsize(fullPath)
        lastModified = os.path.getmtime(fullPath)
        return BucketObject(objectKey, bytesLen, lastModified)
    
    return None

def downloadFile(bucketName, objectKey) -> bytes:
    bucket = getBucket(bucketName)
    fullPath = f"{bucket.localPath}/{objectKey}"
    with open(fullPath, 'rb') as file:
        return file.read()

def uploadFile(bucketName, filePath, contentEncondig, fileContent: bytes):
    bucket = getBucket(bucketName)
    if contentEncondig == "aws-chunked":
        # Processa o conteudo em partes
        bytesContent = localUtil.decode_aws_chunked(fileContent)
        writeFile(bucket.localPath, filePath, bytesContent)
    else:
        writeFile(bucket.localPath, filePath, fileContent)

def file_does_not_exist_response(bucketName, itemKey, response):
    response.status_code = 404
    response.headers["Content-Type"] = "application/xml"
    response.headers["Connection"] = "close"
    response.headers["server"] = "AwsMockServer/1.0"
    response.headers["X-amz-request-id"] = uuid.uuid4().hex

    errorBody = dict(objectDoesNotExistBase)
    errorBody["Key"] = itemKey
    errorBody["RequestId"] = response.headers["X-amz-request-id"]

    response.body = localUtil.create_response_xml_body("Error", errorBody).encode('utf-8')

    return response

def delete_object_response(bucketName, itemKey, response):
    bucket = getBucket(bucketName)
    fullPath = f"{bucket.localPath}/{itemKey}"
    
    if os.path.exists(fullPath):
        os.remove(fullPath)
    
    AWSMock_Global.preencher_base_response(response, 204)
    response.headers["Connection"] = "close"
    
    return response

def list_objects_response(bucketName, prefix, response):
    bucket = getBucket(bucketName)
    
    response.status_code = 200
    response.headers["Content-Type"] = "application/xml"
    response.headers["Connection"] = "close"
    response.headers["X-amz-request-id"] = uuid.uuid4().hex

    contentsList = []
    for root, _, files in os.walk(bucket.localPath):
        for file in files:
            fullPath = os.path.join(root, file)
            relativePath = os.path.relpath(fullPath, bucket.localPath).replace("\\", "/")
            
            if prefix and not relativePath.startswith(prefix):
                continue

            bytesLen = os.path.getsize(fullPath)
            lastModified = os.path.getmtime(fullPath)
            
            contentsList.append({
                "Key": relativePath,
                "ETag": "\"5eff03c49d5ff0e6775d201e4e833f72\"",
                "Owner": {
                    "ID": "arn:aws:iam::000000000000:user/awsmock-user",
                    "DisplayName": "awsmock-user"
                },
                "Size": bytesLen,
                "LastModified": DateTime.utcfromtimestamp(lastModified).strftime("%Y-%m-%dT%H:%M:%S.000Z"),
                "StorageClass": "STANDARD",
                "ChecksumAlgorithm": "CRC32C",
                "ChecksumType": "FULL_OBJECT"
            })

    response_body_dict = {
        "IsTruncated": False,
        "Marker": None,
        "Name": bucketName,
        "Prefix": prefix,
        "MaxKeys": 1000,
        "EncodingType": "url",
    }
    xmlRoot = localUtil.create_xml_element("ListBucketResult", response_body_dict)
    for item in contentsList:
        xmlRoot.append(localUtil.create_xml_element("Contents", item))
    
    response.body = localUtil.create_response_xml_body_fromElementClass(xmlRoot).encode('utf-8')
    return response

            




    