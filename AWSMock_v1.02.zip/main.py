from datetime import datetime as DateTime
from fastapi import FastAPI, Request, Response
import uvicorn
import AWSMock_bucket
import json
import localUtil

app = FastAPI()

@app.head("/{anyPath:path}")
@app.put("/{anyPath:path}")
@app.api_route("/{anyPath:path}")
async def main_api_entrace(request: Request, response: Response):
    urn = request.url.path
    method = request.method

    print(f"Received request {method} from url: {urn}")
    
    urnPartList = urn.split("/")
    filteredUrlPartList = list(filter(lambda x: x > "", urnPartList))
    if len(filteredUrlPartList) < 1:
        response.status_code = 400
        response.body = b"Bad Request"
        return response

    hederUserAgent = request.headers.get("User-Agent")

    recurso = filteredUrlPartList[0]
    recursoParametro = "/".join(filteredUrlPartList[1:]) if len(filteredUrlPartList) > 1 else None
    
    if method == "GET":
        
        if recursoParametro is None:
            # Lista funcao lista objetos do bucket
            prefix = request.query_params.get("prefix")
            return AWSMock_bucket.list_objects_response(recurso, prefix, response)

        bucketName = recurso
        itemKey = recursoParametro
        
        bucketObject = AWSMock_bucket.getObjectEspec(bucketName, itemKey)
        if not bucketObject:
            return AWSMock_bucket.file_does_not_exist_response(bucketName, itemKey, response);
        
        bytesFileContent = AWSMock_bucket.downloadFile(bucketName, itemKey)
        localUtil.preencher_base_respose(response, 200)
        response.body = bytesFileContent
        response.headers["Accept-ranges"] = "bytes"
        response.headers["Connection"] = "close"
        response.headers["Content-Length"] = str(bucketObject.bytesLen)
        response.headers["Content-Type"] = "application/octet-stream"

    elif method == "PUT":
        bucketName = recurso
        itemKey = recursoParametro
    
        print(f"UPLOAD")
        print(f"bucketName: {bucketName}")
        print(f"itemKey: {itemKey}")
        
        AWSMock_bucket.uploadFile(bucketName, itemKey, str(await request.body(), encoding='utf-8'))
    
        localUtil.preencher_base_respose(response, 200)
        response.headers["Connection"] = "close"
        response.headers["Last-modified"] = "Mon, 18 Aug 2025 01:59:14 GMT"
        response.headers["server"] = "AwsMockServer/1.0"

    elif method == "HEAD":
        bucketName = recurso
        itemKey = recursoParametro
        
        print(f"HEAD")
        print(f"bucketName: {bucketName}")
        print(f"itemKey: {itemKey}")
        
        bucketObject = AWSMock_bucket.getObjectEspec(bucketName, itemKey)
        if not bucketObject:
            return AWSMock_bucket.file_does_not_exist_response(bucketName, itemKey, response);

        localUtil.preencher_base_respose(response, 200)
        response.headers["Connection"] = "close"
        response.headers["Content-Length"] = str(bucketObject.bytesLen)
        response.headers["Content-Type"] = "application/octet-stream"
        response.headers["Last-modified"] = "Mon, 18 Aug 2025 01:59:14 GMT" # TODO
        response.headers["server"] = "AwsMockServer/1.0"
    
    else:
        response.status_code = 405
        response.body = b"Method Not Implemented"
    
    return response

resources = json.loads(open('awsmock.json').read())

# Starting resources
if resources.get("resourceList"):
    for resouce in resources.get("resourceList"):
        if resouce.get("resourceType") == "bucket":
            print(f"Creating resource {resouce.get('resourceType')} -> {resouce.get('resourceName')}")
        AWSMock_bucket.createBucket(resouce.get('resourceName'), resouce.get('localPath'))

if __name__ == "__main__":
    uvicorn.run("main:app", port=8080, log_level="info", reload=True)

