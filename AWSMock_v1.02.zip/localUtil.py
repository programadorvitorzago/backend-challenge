import xml.etree.ElementTree as ET
from xml.etree.ElementTree import Element
from datetime import datetime as DateTime

def preencher_base_respose(response, status_code):
    response.status_code = status_code
    response.headers["Date"] = DateTime.utcnow().strftime("%a, %d %b %Y %H:%M:%S GMT")
    response.headers["Etag"] = "5eff03c49d5ff0e6775d201e4e833f72"
    return response

def create_xml_element(key, val):
    xmlElement = ET.Element(key)
    
    if isinstance(val, dict):
        for subkey, subvalue in val.items():
            xmlElement.append(create_xml_element(subkey, subvalue))
    else:
        if val is not None:
            xmlElement.text = str(val)
    return xmlElement

def elementXML_ToString(element: Element):
    return ET.tostring(element, encoding='utf-8').decode('utf-8')

def dict_to_xml_element_str(rootElementTagName, contentDict):
    rootElement = create_xml_element(rootElementTagName, contentDict)
    return elementXML_ToString(rootElement)

def create_response_xml_body(rootElementTagName, contentDict):
    return f"<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n{dict_to_xml_element_str(rootElementTagName, contentDict)}"

def create_response_xml_body_fromElementClass(rootElementRoot: Element):
    return f"<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n{elementXML_ToString(rootElementRoot)}"

